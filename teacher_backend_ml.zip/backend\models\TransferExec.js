const mongoose = require('mongoose');

/**
 * TransferExec Model
 * Tracks execution of approved transfer recommendations
 */
const transferExecSchema = new mongoose.Schema({
  execId: {
    type: String,
    required: true,
    unique: true,
    match: /^T\d{4,}$/  // Format: Txxxx
  },
  candidateId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Recommendation',
    required: false  // May reference recommendations collection
  },
  recommendationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Recommendation',
    required: false
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  fromLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  toLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  },
  status: {
    type: String,
    enum: ['planned', 'in_transit', 'completed', 'cancelled'],
    default: 'planned'
  },
  // Timestamps
  approvedAt: {
    type: Date,
    default: Date.now
  },
  startedAt: {
    type: Date
  },
  completedAt: {
    type: Date
  },
  // Additional metadata
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  notes: {
    type: String
  },
  // Cost tracking
  estimatedCost: {
    type: Number,
    default: 0
  },
  actualCost: {
    type: Number
  },
  distanceKm: {
    type: Number
  },
  // Stock snapshots for UI (best-effort, may be null for legacy records)
  fromQtyBefore: {
    type: Number
  },
  fromQtyAfter: {
    type: Number
  },
  toQtyBefore: {
    type: Number
  },
  toQtyAfter: {
    type: Number
  }
}, {
  timestamps: true  // Adds createdAt and updatedAt automatically
});

// Index for efficient queries
transferExecSchema.index({ status: 1 });
transferExecSchema.index({ productId: 1, status: 1 });
transferExecSchema.index({ fromLocationId: 1 });
transferExecSchema.index({ toLocationId: 1 });
transferExecSchema.index({ approvedAt: -1 });

// Static method to generate next execId
transferExecSchema.statics.generateExecId = async function() {
  const lastExec = await this.findOne({}, { execId: 1 })
    .sort({ execId: -1 })
    .lean();
  
  if (!lastExec || !lastExec.execId) {
    return 'T0001';
  }
  
  const lastNum = parseInt(lastExec.execId.substring(1), 10);
  const nextNum = lastNum + 1;
  return `T${nextNum.toString().padStart(4, '0')}`;
};

module.exports = mongoose.model('TransferExec', transferExecSchema);

