from pymongo import MongoClient
from datetime import datetime, timedelta, timezone
import numpy as np

db = MongoClient('mongodb://localhost:27017')['supply-demand']

# Stock distribution
stocks = list(db['stocks'].find({}, {'quantity': 1}))
qtys = [s['quantity'] for s in stocks]
print('Stock quantities:')
print(f'  Min: {min(qtys)}, Max: {max(qtys)}, Mean: {np.mean(qtys):.1f}')
print(f'  Stocks >= 50: {len([q for q in qtys if q >= 50])}')
print(f'  Stocks >= 30: {len([q for q in qtys if q >= 30])}')
print(f'  Stocks <= 10: {len([q for q in qtys if q <= 10])}')
print(f'  Stocks <= 5: {len([q for q in qtys if q <= 5])}')

# Sales rates
cutoff = datetime.now(timezone.utc) - timedelta(days=30)
pipeline = [
    {"$match": {"status": "purchased", "timestamp": {"$gte": cutoff}}},
    {"$group": {"_id": {"pid": "$productId", "lid": "$locationId"}, "total": {"$sum": "$quantity"}}}
]
sales = list(db['orders'].aggregate(pipeline))
rates = [s['total']/30 for s in sales]
print()
print('Sales rates (per day):')
if rates:
    print(f'  Min: {min(rates):.2f}, Max: {max(rates):.2f}, Mean: {np.mean(rates):.2f}')
    print(f'  Rates >= 2.0: {len([r for r in rates if r >= 2.0])}')
    print(f'  Rates >= 1.0: {len([r for r in rates if r >= 1.0])}')
    print(f'  Rates >= 0.5: {len([r for r in rates if r >= 0.5])}')
    print(f'  Rates <= 0.5: {len([r for r in rates if r <= 0.5])}')
    print(f'  Rates <= 0.2: {len([r for r in rates if r <= 0.2])}')
else:
    print('  No sales in last 30 days')

