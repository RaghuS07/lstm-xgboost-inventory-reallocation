#!/usr/bin/env python3
"""
ml/run_transfer_xgb.py

Score transfer candidates using the trained XGBoost model and create recommendations.

Usage:
    python ml/run_transfer_xgb.py

Outputs:
    - Inserts recommendations into `recommendations` collection
    - Saves top 20 preview to ml/models/recommendation_preview.json
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from pymongo import MongoClient
from bson import ObjectId
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb

# ---------- CONFIG ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

MODELS_DIR = Path("ml/models")
MODEL_FILE = MODELS_DIR / "xgb_transfer.json"
FEATURES_FILE = MODELS_DIR / "xgb_features.json"
PREVIEW_FILE = MODELS_DIR / "recommendation_preview.json"

BATCH_INSERT = int(os.getenv("BATCH_INSERT", "200"))


def load_model_and_metadata():
    """Load trained model and feature metadata."""
    if not MODEL_FILE.exists():
        raise FileNotFoundError(f"Model not found: {MODEL_FILE}")
    if not FEATURES_FILE.exists():
        raise FileNotFoundError(f"Features file not found: {FEATURES_FILE}")
    
    model = xgb.XGBRegressor()
    model.load_model(str(MODEL_FILE))
    
    with open(FEATURES_FILE, "r") as f:
        metadata = json.load(f)
    
    return model, metadata


def load_candidates(db):
    """Load merged candidates, fallback to regular."""
    merged_col = db["transfer_candidates_merged"]
    candidates = list(merged_col.find({}))
    
    if candidates:
        return candidates, "merged"
    
    candidates_col = db["transfer_candidates"]
    candidates = list(candidates_col.find({}))
    return candidates, "original"


def load_products(db):
    """Load products indexed by ObjectId string."""
    products = {}
    for p in db["products"].find({}, {"_id": 1, "productId": 1, "name": 1, "price": 1, "category": 1}):
        products[str(p["_id"])] = {
            "productId": p.get("productId"),
            "name": p.get("name", "Unknown"),
            "price": float(p.get("price", 0)),
            "category": p.get("category", "Unknown")
        }
    return products


def load_locations(db):
    """Load locations indexed by ObjectId string."""
    locations = {}
    for loc in db["locations"].find({}, {"_id": 1, "locationId": 1, "name": 1, "tier": 1, "city": 1}):
        locations[str(loc["_id"])] = {
            "locationId": loc.get("locationId"),
            "name": loc.get("name", "Unknown"),
            "tier": loc.get("tier", "unknown"),
            "city": loc.get("city", "Unknown")
        }
    return locations


def build_features_for_scoring(candidates, products, locations, feature_cols, label_encoder_classes):
    """
    Build feature matrix for scoring (must match training features).
    """
    # Rebuild label encoders from saved classes
    label_encoders = {}
    for col, classes in label_encoder_classes.items():
        le = LabelEncoder()
        le.classes_ = np.array(classes)
        label_encoders[col] = le
    
    records = []
    candidate_info = []
    
    for c in candidates:
        pid = str(c.get("productId", ""))
        from_lid = str(c.get("fromLocationId", ""))
        to_lid = str(c.get("toLocationId", ""))
        
        prod = products.get(pid, {})
        from_loc = locations.get(from_lid, {})
        to_loc = locations.get(to_lid, {})
        
        quantity = float(c.get("quantity", 0))
        distance_km = float(c.get("distance_km", 0))
        stock_source = float(c.get("stock_source", 0))
        stock_target = float(c.get("stock_target", 0))
        forecast_source = float(c.get("forecast_source") or 0)
        forecast_target = float(c.get("forecast_target") or 0)
        sales_rate_source = float(c.get("sales_rate_source", 0))
        sales_rate_target = float(c.get("sales_rate_target", 0))
        
        product_price = prod.get("price", 0)
        category = prod.get("category", "Unknown")
        
        rules = c.get("rules_applied", [c.get("rule", "unknown")])
        is_forecast_rule = 1 if "forecast" in rules else 0
        is_demand_rule = 1 if "demand_vs_stock" in rules else 0
        
        from_tier = from_loc.get("tier", "unknown")
        to_tier = to_loc.get("tier", "unknown")
        
        stock_to_sales_source = stock_source / sales_rate_source if sales_rate_source > 0 else 999
        stock_to_sales_target = stock_target / sales_rate_target if sales_rate_target > 0 else 999
        
        # Encode categories (handle unseen labels)
        def safe_encode(le, value):
            try:
                return le.transform([str(value)])[0]
            except ValueError:
                return 0  # Default for unseen
        
        category_encoded = safe_encode(label_encoders.get("category", LabelEncoder()), category)
        from_tier_encoded = safe_encode(label_encoders.get("from_tier", LabelEncoder()), from_tier)
        to_tier_encoded = safe_encode(label_encoders.get("to_tier", LabelEncoder()), to_tier)
        
        records.append({
            "quantity": quantity,
            "distance_km": distance_km,
            "stock_source": stock_source,
            "stock_target": stock_target,
            "forecast_source": forecast_source,
            "forecast_target": forecast_target,
            "sales_rate_source": sales_rate_source,
            "sales_rate_target": sales_rate_target,
            "stock_to_sales_source": min(stock_to_sales_source, 999),
            "stock_to_sales_target": min(stock_to_sales_target, 999),
            "product_price": product_price,
            "category_encoded": category_encoded,
            "is_forecast_rule": is_forecast_rule,
            "is_demand_rule": is_demand_rule,
            "from_tier_encoded": from_tier_encoded,
            "to_tier_encoded": to_tier_encoded
        })
        
        candidate_info.append({
            "candidate_id": c.get("_id"),
            "productId": c.get("productId"),
            "fromLocationId": c.get("fromLocationId"),
            "toLocationId": c.get("toLocationId"),
            "product_name": prod.get("name", "Unknown"),
            "from_name": from_loc.get("name", "Unknown"),
            "to_name": to_loc.get("name", "Unknown"),
            "quantity": quantity,
            "distance_km": distance_km,
            "product_price": product_price,
            "rules_applied": rules
        })
    
    df = pd.DataFrame(records)
    return df[feature_cols], candidate_info


def compute_scores(profit_estimates):
    """
    Convert profit estimates to normalized scores (0-100).
    Uses sigmoid-like transformation.
    """
    profits = np.array(profit_estimates)
    
    # Normalize to 0-100 using percentile-based approach
    min_p, max_p = np.percentile(profits, [5, 95])
    range_p = max_p - min_p if max_p > min_p else 1
    
    scores = ((profits - min_p) / range_p) * 100
    scores = np.clip(scores, 0, 100)
    
    return scores.tolist()


def assign_priority(scores):
    """Assign priority based on score quantiles."""
    scores_arr = np.array(scores)
    priorities = []
    
    q75 = np.percentile(scores_arr, 75)
    q50 = np.percentile(scores_arr, 50)
    q25 = np.percentile(scores_arr, 25)
    
    for s in scores:
        if s >= q75:
            priorities.append("high")
        elif s >= q50:
            priorities.append("medium")
        elif s >= q25:
            priorities.append("low")
        else:
            priorities.append("very_low")
    
    return priorities


def main():
    print("=== XGBoost Transfer Scoring ===")
    print()
    
    # Load model
    print("Loading model...")
    try:
        model, metadata = load_model_and_metadata()
        print(f"  Model tag: {metadata.get('modelTag')}")
        print(f"  Features: {len(metadata.get('features', []))}")
    except FileNotFoundError as e:
        print(f"ERROR: {e}")
        print("Run train_transfer_xgb.py first.")
        return
    
    feature_cols = metadata.get("features", [])
    label_encoder_classes = metadata.get("label_encoders", {})
    params = metadata.get("params", {})
    cost_per_km = params.get("cost_per_km", 0.1)
    expected_sellthrough = params.get("expected_sellthrough", 0.8)
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    # Load candidates
    print("Loading candidates...")
    candidates, source = load_candidates(db)
    print(f"  Candidates: {len(candidates)} ({source})")
    
    if not candidates:
        print("ERROR: No candidates found.")
        client.close()
        return
    
    # Load reference data
    products = load_products(db)
    locations = load_locations(db)
    print(f"  Products: {len(products)}, Locations: {len(locations)}")
    print()
    
    # Build features
    print("Building features for scoring...")
    X, candidate_info = build_features_for_scoring(
        candidates, products, locations, feature_cols, label_encoder_classes
    )
    print(f"  Feature matrix: {X.shape}")
    
    # Predict
    print("Predicting profit estimates...")
    profit_estimates = model.predict(X)
    
    # Compute additional metrics
    scores = compute_scores(profit_estimates)
    priorities = assign_priority(scores)
    
    # Build recommendations
    print("Building recommendations...")
    recommendations = []
    now = datetime.now(timezone.utc)
    
    for i, info in enumerate(candidate_info):
        quantity = info["quantity"]
        distance = info["distance_km"]
        price = info["product_price"]
        
        # Heuristic calculations for transparency
        revenue_est = quantity * price * expected_sellthrough
        transport_cost = distance * cost_per_km
        
        rec = {
            "candidate_id": info["candidate_id"],
            "productId": info["productId"],
            "fromLocationId": info["fromLocationId"],
            "toLocationId": info["toLocationId"],
            "quantity": int(quantity),
            "distance_km": float(distance),
            "revenue_est": float(revenue_est),
            "transport_cost": float(transport_cost),
            "profit_est": float(profit_estimates[i]),
            "score": float(scores[i]),
            "priority": priorities[i],
            "rules_applied": info["rules_applied"],
            "modelTag": metadata.get("modelTag", "xgb_v1"),
            "approved": False,
            "createdAt": now
        }
        recommendations.append(rec)
    
    # Sort by score descending
    recommendations.sort(key=lambda x: -x["score"])
    
    # Insert recommendations
    print(f"Inserting {len(recommendations)} recommendations...")
    rec_col = db["recommendations"]
    
    for i in range(0, len(recommendations), BATCH_INSERT):
        batch = recommendations[i:i + BATCH_INSERT]
        rec_col.insert_many(batch)
    
    print(f"Done. Inserted {len(recommendations)} recommendations.")
    
    # Save preview
    print(f"\nSaving top 20 preview to {PREVIEW_FILE}...")
    preview = []
    for r in recommendations[:20]:
        preview.append({
            "product_name": next((info["product_name"] for info in candidate_info 
                                 if info["candidate_id"] == r["candidate_id"]), "Unknown"),
            "from_name": next((info["from_name"] for info in candidate_info 
                              if info["candidate_id"] == r["candidate_id"]), "Unknown"),
            "to_name": next((info["to_name"] for info in candidate_info 
                            if info["candidate_id"] == r["candidate_id"]), "Unknown"),
            "quantity": r["quantity"],
            "distance_km": round(r["distance_km"], 1),
            "revenue_est": round(r["revenue_est"], 2),
            "transport_cost": round(r["transport_cost"], 2),
            "profit_est": round(r["profit_est"], 2),
            "score": round(r["score"], 1),
            "priority": r["priority"],
            "rules_applied": r["rules_applied"]
        })
    
    with open(PREVIEW_FILE, "w") as f:
        json.dump({"top_recommendations": preview, "total_count": len(recommendations)}, f, indent=2)
    
    # Print top 10
    print("\n--- Top 10 Recommendations ---")
    for i, p in enumerate(preview[:10], 1):
        print(f"\n{i}. {p['product_name']}")
        print(f"   {p['from_name']} -> {p['to_name']}")
        print(f"   Qty: {p['quantity']}, Distance: {p['distance_km']} km")
        print(f"   Profit: ${p['profit_est']:.2f}, Score: {p['score']:.1f}, Priority: {p['priority']}")
        print(f"   Rules: {p['rules_applied']}")
    
    client.close()
    print("\nDone.")


if __name__ == "__main__":
    main()

