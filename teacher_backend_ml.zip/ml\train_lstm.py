"""
ml/train_lstm.py

Train a simple LSTM to predict next-day units_sold for product-location daily series.

Outputs:
- ml/models/lstm_forecast.pt   (PyTorch model state_dict)
- ml/models/scaler.npy         (numpy array for MinMax scaler params)
- ml/models/metadata.json      (json with list of trained combos and config)

Usage:
    pip install torch pandas numpy scikit-learn
    python ml/train_lstm.py
"""

import os
import json
from pathlib import Path
from collections import defaultdict

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader

# -------------------- CONFIG --------------------
DATA_CSV = Path("ml/data/training_data.csv")
MODELS_DIR = Path("ml/models")
MODELS_DIR.mkdir(parents=True, exist_ok=True)

TOP_K_COMBOS = 200        # number of (product,location) series to train on
WINDOW = 30               # input sequence length (days)
BATCH_SIZE = 128
EPOCHS = 20
LEARNING_RATE = 1e-3
HIDDEN_SIZE = 64
NUM_LAYERS = 2
PATIENCE = 5  # early stopping patience (not mandatory)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)


# -------------------- DATASET --------------------
class SequenceDataset(Dataset):
    def __init__(self, sequences, targets):
        """
        sequences: numpy array (N, seq_len, 1)
        targets: numpy array (N, 1)
        """
        self.X = torch.tensor(sequences, dtype=torch.float32)
        self.y = torch.tensor(targets, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# -------------------- MODEL --------------------
class LSTMForecast(nn.Module):
    def __init__(self, input_size=1, hidden_size=HIDDEN_SIZE, num_layers=NUM_LAYERS):
        super().__init__()
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                            num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, seq_len, input_size)
        out, (hn, cn) = self.lstm(x)  # out: (batch, seq_len, hidden_size)
        # take last time step
        last = out[:, -1, :]
        out = self.fc(last)
        return out.squeeze(1)  # (batch,)


# -------------------- HELPERS --------------------
def pivot_and_fill(df):
    """
    df must have columns: date, productId, locationId, units_sold
    Returns:
      - daily index (sorted)
      - dict with key=(productId,locationId) -> series numpy array aligned to index
    """
    # ensure date is datetime
    df["date"] = pd.to_datetime(df["date"])
    # create a multiindex key
    df["combo"] = df["productId"].astype(str) + "||" + df["locationId"].astype(str)

    # date range full
    min_date = df["date"].min()
    max_date = df["date"].max()
    all_dates = pd.date_range(min_date, max_date, freq="D")

    # aggregate units_sold per day per combo
    grouped = df.groupby(["combo", "date"])["units_sold"].sum().reset_index()
    combos = grouped["combo"].unique()

    combo_series = {}
    for combo in combos:
        s = grouped[grouped["combo"] == combo].set_index("date")["units_sold"]
        s = s.reindex(all_dates, fill_value=0)
        combo_series[combo] = s.values.astype(float)

    return all_dates, combo_series


def build_sequences(series, window):
    """
    series: 1D numpy array
    Return sequences (N, window, 1) and targets (N, 1) where target is next day value
    """
    X = []
    y = []
    L = len(series)
    for i in range(L - window):
        X.append(series[i:i + window])
        y.append(series[i + window])
    X = np.array(X)[:, :, None]  # add feature axis
    y = np.array(y)[:, None]
    return X, y


# -------------------- TRAINING FLOW --------------------
def main():
    assert DATA_CSV.exists(), f"{DATA_CSV} not found."

    print("Loading CSV:", DATA_CSV)
    df = pd.read_csv(DATA_CSV, parse_dates=["date"])
    # keep only necessary columns
    df = df[["date", "productId", "locationId", "units_sold"]].copy()
    df["productId"] = df["productId"].astype(str)
    df["locationId"] = df["locationId"].astype(str)

    # pivot and create series dict
    print("Pivoting and filling missing dates...")
    all_dates, combo_series = pivot_and_fill(df)

    # compute total volume per combo
    combo_volumes = {c: s.sum() for c, s in combo_series.items()}
    combos_sorted = sorted(combo_volumes.items(), key=lambda x: x[1], reverse=True)
    selected_combos = [c for c, _ in combos_sorted[:TOP_K_COMBOS]]
    print(f"Selected top {len(selected_combos)} combos for training.")

    # prepare sequences and global scaler
    all_X = []
    all_y = []
    metadata = {"combos": selected_combos, "window": WINDOW, "dates": [str(all_dates[0]), str(all_dates[-1])]}
    for combo in selected_combos:
        series = combo_series[combo]
        # if series length less than window+1 skip
        if len(series) < WINDOW + 1:
            continue
        X, y = build_sequences(series, WINDOW)
        all_X.append(X)
        all_y.append(y)

    if not all_X:
        raise RuntimeError("No sequences produced. Check window or data length.")

    X = np.concatenate(all_X, axis=0)  # (N, window, 1)
    y = np.concatenate(all_y, axis=0)  # (N, 1)

    print("Total sequences:", X.shape[0])

    # Scale data globally (fit scaler on X flattened + y)
    scaler = MinMaxScaler(feature_range=(0, 1))
    X_flat = X.reshape(-1, 1)
    scaler.fit(np.vstack([X_flat, y.reshape(-1, 1)]))
    X_scaled = scaler.transform(X_flat).reshape(X.shape)
    y_scaled = scaler.transform(y.reshape(-1, 1))

    # train/val split (simple random)
    N = X_scaled.shape[0]
    idx = np.arange(N)
    np.random.shuffle(idx)
    split = int(0.9 * N)
    train_idx, val_idx = idx[:split], idx[split:]

    train_dataset = SequenceDataset(X_scaled[train_idx], y_scaled[train_idx])
    val_dataset = SequenceDataset(X_scaled[val_idx], y_scaled[val_idx])

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=False)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, drop_last=False)

    print(f"Train samples: {len(train_dataset)}, Val samples: {len(val_dataset)}")
    print("Using device:", DEVICE)

    # model
    model = LSTMForecast(input_size=1, hidden_size=HIDDEN_SIZE, num_layers=NUM_LAYERS).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()

    best_val_loss = float("inf")
    epochs_no_improve = 0

    for epoch in range(1, EPOCHS + 1):
        model.train()
        train_losses = []
        for xb, yb in train_loader:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE).squeeze(1)
            optimizer.zero_grad()
            preds = model(xb)
            loss = criterion(preds, yb.squeeze())
            loss.backward()
            optimizer.step()
            train_losses.append(loss.item())

        # validation
        model.eval()
        val_losses = []
        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE).squeeze(1)
                preds = model(xb)
                loss = criterion(preds, yb.squeeze())
                val_losses.append(loss.item())

        train_loss = float(np.mean(train_losses))
        val_loss = float(np.mean(val_losses)) if val_losses else float("nan")

        print(f"Epoch {epoch}/{EPOCHS}  train_loss={train_loss:.6f}  val_loss={val_loss:.6f}")

        # early stopping / save best
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0
            torch.save(model.state_dict(), MODELS_DIR / "lstm_forecast.pt")
            # save scaler and metadata
            np.save(MODELS_DIR / "scaler.npy", np.array([scaler.min_, scaler.scale_], dtype=object), allow_pickle=True)
            with open(MODELS_DIR / "metadata.json", "w") as f:
                json.dump(metadata, f)
            print("Saved best model.")
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= PATIENCE:
                print("Early stopping.")
                break

    print("Training finished. Best val loss:", best_val_loss)
    print("Models and scaler saved to", MODELS_DIR)


if __name__ == "__main__":
    main()
