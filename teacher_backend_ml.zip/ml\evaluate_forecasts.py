# ml/evaluate_forecasts.py
"""
Evaluate forecasts written in the `forecast` collection against actual orders.

Outputs:
 - ml/models/forecast_eval.json  (summary + per-combo metrics)
 - db.collection "forecast_eval" (one document per evaluated forecast)
 - prints overall metrics to console

Usage:
    python ml/evaluate_forecasts.py
"""

import os
import json
from pathlib import Path
from datetime import datetime, timedelta, timezone
from collections import defaultdict

import numpy as np
import pandas as pd
from pymongo import MongoClient
from bson import ObjectId
from dateutil import parser as dateparser
from sklearn.metrics import mean_absolute_error, mean_squared_error

# ---------- Config ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

MODELS_DIR = Path("ml/models")
MODELS_DIR.mkdir(parents=True, exist_ok=True)
# Output file name can be customized based on MODEL_TAG
EVAL_JSON_NAME = os.getenv("EVAL_OUTPUT_FILE", "forecast_eval.json")
EVAL_JSON = MODELS_DIR / EVAL_JSON_NAME

# Optional: only evaluate forecasts for this modelTag (set to None to evaluate all)
MODEL_TAG = os.getenv("EVAL_MODEL_TAG", None)  # e.g., "lstm_v1"

# Minimum horizon length expected
MIN_HORIZON = 1

# ---------- helpers ----------
def safe_mape(y_true, y_pred):
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    # avoid division by zero; only compute where true != 0
    mask = y_true != 0
    if not mask.any():
        return float("nan")
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask]))


def load_forecasts(db, model_tag=None):
    q = {}
    if model_tag:
        q["modelTag"] = model_tag
    # project only essential fields
    cursor = db["forecast"].find(q, {"productId": 1, "locationId": 1, "startDate": 1, "endDate": 1, "horizonDays": 1, "yhat": 1, "modelTag":1})
    return list(cursor)


def fetch_actual_series(db, pid, lid, start_date_str, end_date_str, horizon):
    """
    pid, lid may be ObjectId or string in forecast docs.
    Return an array of length == horizon with daily sum of units_sold from orders collection
    aligned to dates [start_date .. end_date] inclusive.
    """
    # parse dates to midnight UTC
    start_date = dateparser.parse(start_date_str).date()
    end_date = dateparser.parse(end_date_str).date()
    # build date boundaries as datetimes (inclusive start at 00:00, exclusive end +1 day at 00:00)
    dt_start = datetime.combine(start_date, datetime.min.time()).replace(tzinfo=timezone.utc)
    dt_end_excl = (datetime.combine(end_date, datetime.min.time()) + timedelta(days=1)).replace(tzinfo=timezone.utc)

    # Build query
    q = {
        "status": "purchased",
        "timestamp": {"$gte": dt_start, "$lt": dt_end_excl}
    }

    # productId/locationId in orders are stored as ObjectId references; try to use ObjectId if possible
    # allow forecast pid/lid that were stored as string
    try:
        if isinstance(pid, str) and ObjectId.is_valid(pid):
            q["productId"] = ObjectId(pid)
        else:
            q["productId"] = pid
    except Exception:
        q["productId"] = pid

    try:
        if isinstance(lid, str) and ObjectId.is_valid(lid):
            q["locationId"] = ObjectId(lid)
        else:
            q["locationId"] = lid
    except Exception:
        q["locationId"] = lid

    # Aggregate per-day
    pipeline = [
        {"$match": q},
        {
            "$group": {
                "_id": {
                    "$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}
                },
                "units": {"$sum": "$quantity"}
            }
        },
        {"$sort": {"_id": 1}}
    ]
    res = list(db["orders"].aggregate(pipeline))
    # map date->units
    date_to_units = {r["_id"]: r["units"] for r in res}

    # build array of length horizon: start_date + i
    arr = []
    cur = start_date
    for i in range(horizon):
        key = cur.strftime("%Y-%m-%d")
        arr.append(float(date_to_units.get(key, 0.0)))
        cur = cur + timedelta(days=1)

    return np.array(arr, dtype=float)


# ---------- Main ----------
def main():
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]

    print("Loading forecasts from DB...")
    forecasts = load_forecasts(db, MODEL_TAG)
    total_forecasts = len(forecasts)
    print(f"Found {total_forecasts} forecast documents (modelTag={MODEL_TAG})")

    if total_forecasts == 0:
        print("No forecasts found. Exiting.")
        return

    per_combo = []
    overall_preds = []
    overall_trues = []
    missing_count = 0

    for doc in forecasts:
        # read fields
        pid = doc.get("productId")
        lid = doc.get("locationId")
        startDate = doc.get("startDate")
        endDate = doc.get("endDate")
        yhat = doc.get("yhat", [])
        horizon = int(doc.get("horizonDays", len(yhat)))

        if horizon < MIN_HORIZON:
            # skip weird docs
            continue

        # If yhat length doesn't match horizon, adjust horizon to min
        if len(yhat) != horizon:
            horizon = min(horizon, len(yhat))
            yhat = yhat[:horizon]

        # get actuals
        try:
            actual = fetch_actual_series(db, pid, lid, startDate, endDate, horizon)
        except Exception as e:
            # fetch error for this combo; skip
            print(f"Warning: failed to fetch actuals for forecast id={doc.get('_id')} -> {e}")
            missing_count += 1
            continue

        # ensure arrays are same length
        if len(actual) != len(yhat):
            # pad shorter one with zeros or trim
            L = min(len(actual), len(yhat))
            actual = actual[:L]
            yhat = yhat[:L]

        # compute metrics
        mae = float(mean_absolute_error(actual, yhat))
        rmse = float(np.sqrt(mean_squared_error(actual, yhat)))
        mape = float(safe_mape(actual, yhat))

        entry = {
            "forecast_id": str(doc.get("_id")),
            "productId": str(pid),
            "locationId": str(lid),
            "modelTag": doc.get("modelTag"),
            "startDate": startDate,
            "endDate": endDate,
            "horizon": horizon,
            "metrics": {"mae": mae, "rmse": rmse, "mape": mape},
            "yhat": list(map(float, yhat)),
            "actual": list(map(float, actual))
        }

        per_combo.append(entry)

        # extend overall lists
        overall_preds.extend(list(map(float, yhat)))
        overall_trues.extend(list(map(float, actual)))

    # compute overall metrics
    overall_mae = float(mean_absolute_error(overall_trues, overall_preds)) if overall_trues else float("nan")
    overall_rmse = float(np.sqrt(mean_squared_error(overall_trues, overall_preds))) if overall_trues else float("nan")
    overall_mape = float(safe_mape(np.array(overall_trues), np.array(overall_preds))) if overall_trues else float("nan")
    coverage = len(per_combo) / total_forecasts if total_forecasts else 0.0

    summary = {
        "modelTag": MODEL_TAG,
        "total_forecasts": total_forecasts,
        "evaluated_forecasts": len(per_combo),
        "coverage": coverage,
        "overall": {"mae": overall_mae, "rmse": overall_rmse, "mape": overall_mape},
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

    print("Evaluation summary:")
    print(json.dumps(summary, indent=2))

    # Save JSON summary + per-combo (trim per-combo length if huge)
    out = {"summary": summary, "per_combo_count": len(per_combo)}

    # To avoid massive file, keep per-combo top 500 entries; but still store all in DB
    MAX_SAVE = 1000
    out["per_combo_sample"] = per_combo[:MAX_SAVE]
    with open(EVAL_JSON, "w") as f:
        json.dump(out, f, indent=2)

    # write per-combo metrics to Mongo (collection: forecast_eval)
    eval_col = db["forecast_eval"]
    # optional: clear old entries for same modelTag
    try:
        eval_col.delete_many({"modelTag": MODEL_TAG})
    except Exception:
        pass

    docs_to_insert = []
    for e in per_combo:
        docs_to_insert.append({
            "forecast_id": e["forecast_id"],
            "productId": e["productId"],
            "locationId": e["locationId"],
            "modelTag": e["modelTag"],
            "startDate": e["startDate"],
            "endDate": e["endDate"],
            "horizon": e["horizon"],
            "metrics": e["metrics"],
            "generatedAt": datetime.now(timezone.utc)
        })

    if docs_to_insert:
        # insert in batches of 500
        BATCH = 500
        for i in range(0, len(docs_to_insert), BATCH):
            eval_col.insert_many(docs_to_insert[i:i+BATCH])

    print(f"Saved evaluation JSON to {EVAL_JSON}")
    print(f"Wrote {len(docs_to_insert)} docs to forecast_eval collection (modelTag={MODEL_TAG}).")

    client.close()


if __name__ == "__main__":
    main()
