#!/usr/bin/env python3
"""
ml/train_transfer_xgb.py

Train an XGBoost model to predict transfer profitability.

Uses features from candidates + product/location metadata.
If historical transfer_impact exists, uses net_profit as target.
Otherwise, creates heuristic target based on estimated revenue/cost.

Usage:
    python ml/train_transfer_xgb.py

Outputs:
    - ml/models/xgb_transfer.json (model)
    - ml/models/xgb_features.json (feature list + metadata)
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from pymongo import MongoClient
from bson import ObjectId
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import joblib

try:
    import xgboost as xgb
except ImportError:
    print("Installing xgboost...")
    import subprocess
    subprocess.check_call(["pip", "install", "xgboost"])
    import xgboost as xgb

# ---------- CONFIG ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

MODELS_DIR = Path("ml/models")
MODELS_DIR.mkdir(parents=True, exist_ok=True)

MODEL_FILE = MODELS_DIR / "xgb_transfer.json"
FEATURES_FILE = MODELS_DIR / "xgb_features.json"

# Heuristic parameters
COST_PER_KM = float(os.getenv("COST_PER_KM", "0.1"))
EXPECTED_SELLTHROUGH = float(os.getenv("EXPECTED_SELLTHROUGH", "0.8"))
MODEL_TAG = "xgb_v1"


def load_candidates(db):
    """Load merged candidates, fallback to regular candidates."""
    # Try merged collection first
    merged_col = db["transfer_candidates_merged"]
    candidates = list(merged_col.find({}))
    
    if candidates:
        print(f"Loaded {len(candidates)} merged candidates")
        return candidates, "merged"
    
    # Fallback to regular candidates
    candidates_col = db["transfer_candidates"]
    candidates = list(candidates_col.find({}))
    print(f"Loaded {len(candidates)} candidates (not merged)")
    return candidates, "original"


def load_products(db):
    """Load products indexed by ObjectId string."""
    products = {}
    for p in db["products"].find({}, {"_id": 1, "productId": 1, "name": 1, "price": 1, "category": 1}):
        products[str(p["_id"])] = {
            "productId": p.get("productId"),
            "name": p.get("name", "Unknown"),
            "price": float(p.get("price", 0)),
            "category": p.get("category", "Unknown")
        }
    return products


def load_locations(db):
    """Load locations indexed by ObjectId string."""
    locations = {}
    for loc in db["locations"].find({}, {"_id": 1, "locationId": 1, "name": 1, "tier": 1, "city": 1}):
        locations[str(loc["_id"])] = {
            "locationId": loc.get("locationId"),
            "name": loc.get("name", "Unknown"),
            "tier": loc.get("tier", "unknown"),
            "city": loc.get("city", "Unknown")
        }
    return locations


def load_transfer_impact(db):
    """Load historical transfer impact if exists."""
    if "transfer_impact" not in db.list_collection_names():
        return {}
    
    impacts = {}
    for doc in db["transfer_impact"].find({}, {"candidate_id": 1, "net_profit": 1}):
        if doc.get("candidate_id"):
            impacts[str(doc["candidate_id"])] = float(doc.get("net_profit", 0))
    return impacts


def build_features(candidates, products, locations, impacts):
    """
    Build feature matrix from candidates.
    
    Returns:
        X: DataFrame of features
        y: Series of targets
        feature_names: List of feature column names
    """
    records = []
    
    for c in candidates:
        pid = str(c.get("productId", ""))
        from_lid = str(c.get("fromLocationId", ""))
        to_lid = str(c.get("toLocationId", ""))
        
        prod = products.get(pid, {})
        from_loc = locations.get(from_lid, {})
        to_loc = locations.get(to_lid, {})
        
        quantity = float(c.get("quantity", 0))
        distance_km = float(c.get("distance_km", 0))
        stock_source = float(c.get("stock_source", 0))
        stock_target = float(c.get("stock_target", 0))
        forecast_source = float(c.get("forecast_source") or 0)
        forecast_target = float(c.get("forecast_target") or 0)
        sales_rate_source = float(c.get("sales_rate_source", 0))
        sales_rate_target = float(c.get("sales_rate_target", 0))
        
        product_price = prod.get("price", 0)
        category = prod.get("category", "Unknown")
        
        # Rules applied
        rules = c.get("rules_applied", [c.get("rule", "unknown")])
        is_forecast_rule = 1 if "forecast" in rules else 0
        is_demand_rule = 1 if "demand_vs_stock" in rules else 0
        
        # Location tiers
        from_tier = from_loc.get("tier", "unknown")
        to_tier = to_loc.get("tier", "unknown")
        
        # Computed features
        stock_to_sales_source = stock_source / sales_rate_source if sales_rate_source > 0 else 999
        stock_to_sales_target = stock_target / sales_rate_target if sales_rate_target > 0 else 999
        
        # Target: historical profit or heuristic
        candidate_id = str(c.get("_id", ""))
        if candidate_id in impacts:
            target_profit = impacts[candidate_id]
        else:
            # Heuristic target
            revenue_est = quantity * product_price * EXPECTED_SELLTHROUGH
            transport_cost = distance_km * COST_PER_KM
            target_profit = revenue_est - transport_cost
        
        records.append({
            "candidate_id": candidate_id,
            "quantity": quantity,
            "distance_km": distance_km,
            "stock_source": stock_source,
            "stock_target": stock_target,
            "forecast_source": forecast_source,
            "forecast_target": forecast_target,
            "sales_rate_source": sales_rate_source,
            "sales_rate_target": sales_rate_target,
            "stock_to_sales_source": min(stock_to_sales_source, 999),
            "stock_to_sales_target": min(stock_to_sales_target, 999),
            "product_price": product_price,
            "category": category,
            "is_forecast_rule": is_forecast_rule,
            "is_demand_rule": is_demand_rule,
            "from_tier": from_tier,
            "to_tier": to_tier,
            "target_profit": target_profit
        })
    
    df = pd.DataFrame(records)
    
    if df.empty:
        return None, None, []
    
    # Encode categorical variables
    label_encoders = {}
    for col in ["category", "from_tier", "to_tier"]:
        le = LabelEncoder()
        df[col + "_encoded"] = le.fit_transform(df[col].astype(str))
        label_encoders[col] = le
    
    # Define feature columns
    feature_cols = [
        "quantity", "distance_km", "stock_source", "stock_target",
        "forecast_source", "forecast_target", "sales_rate_source", "sales_rate_target",
        "stock_to_sales_source", "stock_to_sales_target", "product_price",
        "category_encoded", "is_forecast_rule", "is_demand_rule",
        "from_tier_encoded", "to_tier_encoded"
    ]
    
    X = df[feature_cols]
    y = df["target_profit"]
    
    return X, y, feature_cols, label_encoders, df


def train_model(X, y):
    """Train XGBoost regressor."""
    # Split data
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print(f"Training samples: {len(X_train)}, Validation samples: {len(X_val)}")
    
    # Train model
    model = xgb.XGBRegressor(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        verbose=False
    )
    
    # Evaluate
    y_pred_train = model.predict(X_train)
    y_pred_val = model.predict(X_val)
    
    metrics = {
        "train": {
            "mae": float(mean_absolute_error(y_train, y_pred_train)),
            "rmse": float(np.sqrt(mean_squared_error(y_train, y_pred_train))),
            "r2": float(r2_score(y_train, y_pred_train))
        },
        "val": {
            "mae": float(mean_absolute_error(y_val, y_pred_val)),
            "rmse": float(np.sqrt(mean_squared_error(y_val, y_pred_val))),
            "r2": float(r2_score(y_val, y_pred_val))
        }
    }
    
    return model, metrics


def main():
    print("=== XGBoost Transfer Model Training ===")
    print()
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    # Load data
    print("Loading data...")
    candidates, source = load_candidates(db)
    
    if not candidates:
        print("ERROR: No candidates found. Run generate_transfer_candidates.py first.")
        client.close()
        return
    
    products = load_products(db)
    print(f"  Products: {len(products)}")
    
    locations = load_locations(db)
    print(f"  Locations: {len(locations)}")
    
    impacts = load_transfer_impact(db)
    print(f"  Historical impacts: {len(impacts)}")
    print()
    
    # Build features
    print("Building features...")
    result = build_features(candidates, products, locations, impacts)
    
    if result[0] is None:
        print("ERROR: Could not build features from candidates.")
        client.close()
        return
    
    X, y, feature_cols, label_encoders, df = result
    print(f"  Feature matrix: {X.shape}")
    print(f"  Target range: {y.min():.2f} to {y.max():.2f}")
    print()
    
    # Train model
    print("Training XGBoost model...")
    model, metrics = train_model(X, y)
    
    print("\n--- Training Metrics ---")
    print(f"Train MAE:  {metrics['train']['mae']:.4f}")
    print(f"Train RMSE: {metrics['train']['rmse']:.4f}")
    print(f"Train R2:   {metrics['train']['r2']:.4f}")
    print(f"Val MAE:    {metrics['val']['mae']:.4f}")
    print(f"Val RMSE:   {metrics['val']['rmse']:.4f}")
    print(f"Val R2:     {metrics['val']['r2']:.4f}")
    
    # Save model
    print(f"\nSaving model to {MODEL_FILE}...")
    model.save_model(str(MODEL_FILE))
    
    # Save feature metadata
    feature_metadata = {
        "modelTag": MODEL_TAG,
        "features": feature_cols,
        "label_encoders": {k: list(v.classes_) for k, v in label_encoders.items()},
        "metrics": metrics,
        "params": {
            "cost_per_km": COST_PER_KM,
            "expected_sellthrough": EXPECTED_SELLTHROUGH
        },
        "training_samples": len(X),
        "candidate_source": source,
        "trained_at": datetime.now(timezone.utc).isoformat()
    }
    
    with open(FEATURES_FILE, "w") as f:
        json.dump(feature_metadata, f, indent=2)
    print(f"Saved feature metadata to {FEATURES_FILE}")
    
    # Feature importance
    print("\n--- Feature Importance (top 10) ---")
    importance = dict(zip(feature_cols, model.feature_importances_))
    sorted_imp = sorted(importance.items(), key=lambda x: -x[1])
    for feat, imp in sorted_imp[:10]:
        print(f"  {feat}: {imp:.4f}")
    
    client.close()
    print("\nDone.")


if __name__ == "__main__":
    main()

