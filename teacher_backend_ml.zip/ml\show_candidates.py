from pymongo import MongoClient

db = MongoClient('mongodb://localhost:27017')['supply-demand']
docs = list(db['transfer_candidates'].find().sort('createdAt', -1).limit(3))

print('=== 3 SAMPLE TRANSFER CANDIDATES ===')
for i, doc in enumerate(docs, 1):
    print(f'\nCandidate {i}:')
    print(f'  productId: {doc.get("productId")}')
    print(f'  fromLocationId: {doc.get("fromLocationId")}')
    print(f'  toLocationId: {doc.get("toLocationId")}')
    print(f'  quantity: {doc.get("quantity", 0):.2f}')
    print(f'  distance_km: {doc.get("distance_km", 0):.2f}')
    print(f'  forecast_source: {doc.get("forecast_source", 0):.4f}')
    print(f'  forecast_target: {doc.get("forecast_target", 0):.4f}')
    print(f'  stock_source: {doc.get("stock_source", 0)}')
    print(f'  stock_target: {doc.get("stock_target", 0)}')

