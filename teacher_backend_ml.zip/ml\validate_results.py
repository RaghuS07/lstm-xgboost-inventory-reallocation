from pymongo import MongoClient
import numpy as np

db = MongoClient('mongodb://localhost:27017')['supply-demand']

print('=== FORECAST VALIDATION (modelTag="lstm_v1_unscaled") ===')
forecasts = list(db['forecast'].find({'modelTag': 'lstm_v1_unscaled'}))
print(f'Total forecasts: {len(forecasts)}')

if forecasts:
    yhat_sums = [sum(f.get('yhat', [])) for f in forecasts]
    print(f'yhat sum - min: {min(yhat_sums):.4f}')
    print(f'yhat sum - mean: {np.mean(yhat_sums):.4f}')
    print(f'yhat sum - max: {max(yhat_sums):.4f}')
    
    # Check if values are in real units (not all < 1)
    all_yhats = []
    for f in forecasts:
        all_yhats.extend(f.get('yhat', []))
    print(f'Individual yhat values - min: {min(all_yhats):.4f}, max: {max(all_yhats):.4f}')
    
    print('\n--- 3 Sample Forecast Documents ---')
    for i, f in enumerate(forecasts[:3], 1):
        print(f'\nForecast {i}:')
        print(f'  productId: {f.get("productId")}')
        print(f'  locationId: {f.get("locationId")}')
        print(f'  startDate: {f.get("startDate")}')
        print(f'  yhat (7 days): {[round(v, 3) for v in f.get("yhat", [])[:7]]}')
        print(f'  yhat_scaled: {[round(v, 5) for v in f.get("yhat_scaled", [])[:7]]}')
        print(f'  modelTag: {f.get("modelTag")}')

print('\n\n=== TRANSFER CANDIDATES VALIDATION ===')
candidates = list(db['transfer_candidates'].find())
print(f'Total transfer candidates: {len(candidates)}')

if candidates:
    print('\n--- 3 Sample Candidate Documents ---')
    for i, c in enumerate(candidates[:3], 1):
        print(f'\nCandidate {i}:')
        print(f'  productId: {c.get("productId")}')
        print(f'  fromLocationId: {c.get("fromLocationId")}')
        print(f'  toLocationId: {c.get("toLocationId")}')
        print(f'  quantity: {c.get("quantity", 0):.2f}')
        print(f'  distance_km: {c.get("distance_km", 0):.2f}')
        print(f'  status: {c.get("status")}')

