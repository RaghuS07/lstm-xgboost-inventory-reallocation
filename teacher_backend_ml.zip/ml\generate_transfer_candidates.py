#!/usr/bin/env python3
"""
ml/generate_transfer_candidates.py

Generate transfer candidates using two rules:
  - Rule A: forecast-based (surplus/deficit from forecast vs stock)
  - Rule B: demand-vs-stock (sales rate analysis)

Usage:
    python ml/generate_transfer_candidates.py [--dry-run]
    
Environment variables:
    FORECAST_MODEL_TAG: Model tag for forecasts (default: lstm_v1_unscaled)
    SALES_WINDOW_DAYS: Days to calculate sales rate (default: 30)
    And other threshold configs...

Outputs:
    - Inserts candidate documents into `transfer_candidates` collection
"""
import os
import sys
import math
import uuid
import argparse
from pathlib import Path
from datetime import datetime, timedelta, timezone
from collections import defaultdict

from pymongo import MongoClient
from bson import ObjectId

# ---------- CONFIG (env-configurable) ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

# Forecast settings
FORECAST_MODEL_TAG = os.getenv("FORECAST_MODEL_TAG", "lstm_v1_unscaled")

# Sales analysis window
SALES_WINDOW_DAYS = int(os.getenv("SALES_WINDOW_DAYS", "30"))

# Rule A (forecast-based) thresholds
MIN_MOVE_THRESHOLD = float(os.getenv("MIN_MOVE_THRESHOLD", "1.0"))
MAX_MOVE_PER_CANDIDATE = float(os.getenv("MAX_MOVE_PER_CANDIDATE", "100.0"))

# Rule B (demand-vs-stock) thresholds - adjusted for actual data ranges
STOCK_HIGH_THRESHOLD = float(os.getenv("STOCK_HIGH_THRESHOLD", "30.0"))  # donor: stock >= this
STOCK_LOW_THRESHOLD = float(os.getenv("STOCK_LOW_THRESHOLD", "5.0"))     # receiver: stock <= this
SALES_HIGH_THRESHOLD = float(os.getenv("SALES_HIGH_THRESHOLD", "0.3"))   # receiver: sales_rate >= this
SALES_LOW_THRESHOLD = float(os.getenv("SALES_LOW_THRESHOLD", "0.1"))     # donor: sales_rate <= this

# Transfer parameters
TARGET_FILL_PERCENT = float(os.getenv("TARGET_FILL_PERCENT", "0.7"))  # Fill receiver to 70% of target
SAFETY_STOCK = float(os.getenv("SAFETY_STOCK", "5.0"))                # Keep safety stock at donor

# Cost estimation
COST_PER_KM = float(os.getenv("COST_PER_KM", "0.1"))

# Batch insert size
BATCH_INSERT = int(os.getenv("BATCH_INSERT", "200"))


# ---------- Haversine ----------
def haversine_km(lat1, lon1, lat2, lon2):
    """Calculate distance between two coordinates in kilometers."""
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# ---------- Data Loaders ----------
def load_locations(db):
    """Load locations with coordinates."""
    locations = {}
    for loc in db["locations"].find({}, {"_id": 1, "locationId": 1, "name": 1, "latitude": 1, "longitude": 1, "tier": 1, "city": 1}):
        lid = str(loc["_id"])
        locations[lid] = {
            "_id": loc["_id"],
            "locationId": loc.get("locationId", lid),
            "name": loc.get("name", "Unknown"),
            "lat": float(loc.get("latitude", 0.0)),
            "lon": float(loc.get("longitude", 0.0)),
            "tier": loc.get("tier", ""),
            "city": loc.get("city", "")
        }
        # Also index by locationId string (e.g., "L001")
        if loc.get("locationId"):
            locations[loc["locationId"]] = locations[lid]
    return locations


def load_products(db):
    """Load products with metadata."""
    products = {}
    for prod in db["products"].find({}, {"_id": 1, "productId": 1, "name": 1, "price": 1, "category": 1}):
        pid = str(prod["_id"])
        products[pid] = {
            "_id": prod["_id"],
            "productId": prod.get("productId", pid),
            "name": prod.get("name", "Unknown"),
            "price": float(prod.get("price", 0.0)),
            "category": prod.get("category", "Unknown")
        }
        if prod.get("productId"):
            products[prod["productId"]] = products[pid]
    return products


def load_stocks(db):
    """Load current stock levels indexed by (productId, locationId) as ObjectId strings."""
    stocks = {}
    for s in db["stocks"].find({}, {"productId": 1, "locationId": 1, "quantity": 1}):
        key = (str(s["productId"]), str(s["locationId"]))
        stocks[key] = float(s.get("quantity", 0))
    return stocks


def load_forecasts(db, model_tag):
    """Load forecasts for the given model tag."""
    forecasts = {}
    query = {"modelTag": model_tag} if model_tag else {}
    for f in db["forecast"].find(query, {"productId": 1, "locationId": 1, "yhat": 1, "horizonDays": 1}):
        pid = f.get("productId")
        lid = f.get("locationId")
        yhat = f.get("yhat", [])
        forecast_sum = float(sum(yhat)) if yhat else 0.0
        forecasts[(str(pid), str(lid))] = {
            "productId": pid,
            "locationId": lid,
            "forecast_sum": forecast_sum,
            "yhat": yhat
        }
    return forecasts


def compute_sales_rates(db, window_days):
    """
    Compute daily sales rate per (productId, locationId) from orders.
    sales_rate = total_quantity_purchased / window_days
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)
    
    pipeline = [
        {"$match": {"status": "purchased", "timestamp": {"$gte": cutoff}}},
        {"$group": {
            "_id": {"productId": "$productId", "locationId": "$locationId"},
            "total_qty": {"$sum": "$quantity"}
        }}
    ]
    
    sales_rates = {}
    for doc in db["orders"].aggregate(pipeline):
        pid = str(doc["_id"]["productId"])
        lid = str(doc["_id"]["locationId"])
        total = float(doc["total_qty"])
        sales_rates[(pid, lid)] = total / window_days
    
    return sales_rates


# ---------- Rule A: Forecast-Based Candidates ----------
def generate_forecast_candidates(forecasts, stocks, products, locations):
    """
    Generate candidates based on forecast surplus/deficit.
    - Surplus: stock > forecast_sum + threshold -> donor
    - Deficit: stock < forecast_sum - threshold -> receiver
    """
    per_product = defaultdict(lambda: {"sources": [], "sinks": []})
    
    for (pid, lid), fdata in forecasts.items():
        forecast_sum = fdata["forecast_sum"]
        stock_qty = stocks.get((pid, lid), 0.0)
        surplus = stock_qty - forecast_sum
        
        # Resolve ObjectIds
        prod_info = products.get(pid, {})
        loc_info = locations.get(lid, {})
        
        if not prod_info.get("_id") or not loc_info.get("_id"):
            continue
        
        item = {
            "productId": pid,
            "productObjId": prod_info["_id"],
            "locationId": lid,
            "locationObjId": loc_info["_id"],
            "forecast_sum": forecast_sum,
            "stock": stock_qty,
            "surplus": surplus,
            "sales_rate": 0.0  # Will be filled later if needed
        }
        
        if surplus >= MIN_MOVE_THRESHOLD:
            per_product[pid]["sources"].append(item)
        elif surplus <= -MIN_MOVE_THRESHOLD:
            per_product[pid]["sinks"].append(item)
    
    candidates = []
    for pid, groups in per_product.items():
        sources = sorted(groups["sources"], key=lambda x: -x["surplus"])
        sinks = sorted(groups["sinks"], key=lambda x: -abs(x["surplus"]))
        
        if not sources or not sinks:
            continue
        
        prod_info = products.get(pid, {})
        
        for sink in sinks:
            deficit = abs(sink["surplus"])
            if deficit < MIN_MOVE_THRESHOLD:
                continue
            
            for source in sources:
                available = source["surplus"]
                if available < MIN_MOVE_THRESHOLD:
                    continue
                
                qty = min(available, deficit, MAX_MOVE_PER_CANDIDATE)
                if qty < MIN_MOVE_THRESHOLD:
                    continue
                
                src_loc = locations.get(source["locationId"], {})
                dst_loc = locations.get(sink["locationId"], {})
                
                distance = haversine_km(
                    src_loc.get("lat", 0), src_loc.get("lon", 0),
                    dst_loc.get("lat", 0), dst_loc.get("lon", 0)
                )
                
                candidates.append({
                    "productId": source["productObjId"],
                    "fromLocationId": source["locationObjId"],
                    "toLocationId": sink["locationObjId"],
                    "quantity": int(qty),
                    "distance_km": float(distance),
                    "forecast_source": source["forecast_sum"],
                    "forecast_target": sink["forecast_sum"],
                    "stock_source": source["stock"],
                    "stock_target": sink["stock"],
                    "sales_rate_source": source.get("sales_rate", 0.0),
                    "sales_rate_target": sink.get("sales_rate", 0.0),
                    "rule": "forecast"
                })
                
                source["surplus"] -= qty
                deficit -= qty
                if deficit < MIN_MOVE_THRESHOLD:
                    break
    
    return candidates


# ---------- Rule B: Demand-vs-Stock Candidates ----------
def generate_demand_vs_stock_candidates(stocks, sales_rates, products, locations):
    """
    Generate candidates based on sales velocity vs stock levels.
    - Donor: high stock + low sales rate
    - Receiver: high sales rate + low stock
    """
    # Group by product
    per_product = defaultdict(lambda: {"donors": [], "receivers": []})
    
    # Get all product-location combinations from stocks
    for (pid, lid), stock_qty in stocks.items():
        sales_rate = sales_rates.get((pid, lid), 0.0)
        
        prod_info = products.get(pid, {})
        loc_info = locations.get(lid, {})
        
        if not prod_info.get("_id") or not loc_info.get("_id"):
            continue
        
        item = {
            "productId": pid,
            "productObjId": prod_info["_id"],
            "locationId": lid,
            "locationObjId": loc_info["_id"],
            "stock": stock_qty,
            "sales_rate": sales_rate
        }
        
        # Donor: high stock AND low sales
        if stock_qty >= STOCK_HIGH_THRESHOLD and sales_rate <= SALES_LOW_THRESHOLD:
            per_product[pid]["donors"].append(item)
        
        # Receiver: high sales AND low stock
        if sales_rate >= SALES_HIGH_THRESHOLD and stock_qty <= STOCK_LOW_THRESHOLD:
            per_product[pid]["receivers"].append(item)
    
    candidates = []
    for pid, groups in per_product.items():
        donors = sorted(groups["donors"], key=lambda x: -x["stock"])  # Highest stock first
        receivers = sorted(groups["receivers"], key=lambda x: -x["sales_rate"])  # Highest demand first
        
        if not donors or not receivers:
            continue
        
        for receiver in receivers:
            # Calculate target stock based on sales rate
            target_stock = receiver["sales_rate"] * SALES_WINDOW_DAYS * TARGET_FILL_PERCENT
            needed = max(0, target_stock - receiver["stock"])
            
            if needed < MIN_MOVE_THRESHOLD:
                continue
            
            for donor in donors:
                available = max(0, donor["stock"] - SAFETY_STOCK)
                if available < MIN_MOVE_THRESHOLD:
                    continue
                
                qty = min(available, needed, MAX_MOVE_PER_CANDIDATE)
                if qty < MIN_MOVE_THRESHOLD:
                    continue
                
                src_loc = locations.get(donor["locationId"], {})
                dst_loc = locations.get(receiver["locationId"], {})
                
                distance = haversine_km(
                    src_loc.get("lat", 0), src_loc.get("lon", 0),
                    dst_loc.get("lat", 0), dst_loc.get("lon", 0)
                )
                
                candidates.append({
                    "productId": donor["productObjId"],
                    "fromLocationId": donor["locationObjId"],
                    "toLocationId": receiver["locationObjId"],
                    "quantity": int(qty),
                    "distance_km": float(distance),
                    "forecast_source": None,
                    "forecast_target": None,
                    "stock_source": donor["stock"],
                    "stock_target": receiver["stock"],
                    "sales_rate_source": donor["sales_rate"],
                    "sales_rate_target": receiver["sales_rate"],
                    "rule": "demand_vs_stock"
                })
                
                donor["stock"] -= qty
                needed -= qty
                if needed < MIN_MOVE_THRESHOLD:
                    break
    
    return candidates


# ---------- Main ----------
def main():
    parser = argparse.ArgumentParser(description="Generate transfer candidates")
    parser.add_argument("--dry-run", action="store_true", help="Print candidates without inserting")
    args = parser.parse_args()
    
    run_id = str(uuid.uuid4())
    print(f"=== Transfer Candidate Generator ===")
    print(f"Run ID: {run_id}")
    print(f"Model Tag: {FORECAST_MODEL_TAG}")
    print(f"Dry Run: {args.dry_run}")
    print()
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    # Load data
    print("Loading data...")
    locations = load_locations(db)
    print(f"  Locations: {len(locations) // 2}")  # Divided by 2 because dual-indexed
    
    products = load_products(db)
    print(f"  Products: {len(products) // 2}")
    
    stocks = load_stocks(db)
    print(f"  Stock entries: {len(stocks)}")
    
    forecasts = load_forecasts(db, FORECAST_MODEL_TAG)
    print(f"  Forecasts: {len(forecasts)}")
    
    sales_rates = compute_sales_rates(db, SALES_WINDOW_DAYS)
    print(f"  Sales rate entries: {len(sales_rates)}")
    print()
    
    # Generate candidates from Rule A (forecast-based)
    print("Generating Rule A (forecast-based) candidates...")
    candidates_a = generate_forecast_candidates(forecasts, stocks, products, locations)
    print(f"  Generated: {len(candidates_a)} candidates")
    
    # Generate candidates from Rule B (demand-vs-stock)
    print("Generating Rule B (demand-vs-stock) candidates...")
    candidates_b = generate_demand_vs_stock_candidates(stocks, sales_rates, products, locations)
    print(f"  Generated: {len(candidates_b)} candidates")
    
    # Combine all candidates
    all_candidates = candidates_a + candidates_b
    print(f"\nTotal candidates: {len(all_candidates)}")
    
    # Add metadata to all candidates
    now = datetime.now(timezone.utc)
    for c in all_candidates:
        c["createdAt"] = now
        c["runId"] = run_id
        c["modelTag"] = FORECAST_MODEL_TAG
        c["metadata"] = {
            "cost_per_km": COST_PER_KM,
            "min_move_threshold": MIN_MOVE_THRESHOLD,
            "sales_window_days": SALES_WINDOW_DAYS
        }
    
    # Print sample candidates
    if all_candidates:
        print("\n--- First 5 Candidates ---")
        for i, c in enumerate(all_candidates[:5], 1):
            print(f"\nCandidate {i} ({c['rule']}):")
            print(f"  productId: {c['productId']}")
            print(f"  from: {c['fromLocationId']} -> to: {c['toLocationId']}")
            print(f"  quantity: {c['quantity']}, distance: {c['distance_km']:.1f} km")
            print(f"  stock_source: {c['stock_source']}, stock_target: {c['stock_target']}")
            print(f"  sales_rate_source: {c.get('sales_rate_source', 0):.2f}, sales_rate_target: {c.get('sales_rate_target', 0):.2f}")
    
    if args.dry_run:
        print("\n[DRY RUN] No candidates inserted.")
        client.close()
        return
    
    # Insert candidates
    if not all_candidates:
        print("\nNo candidates to insert.")
        client.close()
        return
    
    print(f"\nInserting {len(all_candidates)} candidates...")
    candidates_col = db["transfer_candidates"]
    
    for i in range(0, len(all_candidates), BATCH_INSERT):
        batch = all_candidates[i:i + BATCH_INSERT]
        candidates_col.insert_many(batch)
    
    print(f"Done. Inserted {len(all_candidates)} candidates.")
    
    # Summary by rule
    rule_counts = defaultdict(int)
    for c in all_candidates:
        rule_counts[c["rule"]] += 1
    print("\nBy rule:")
    for rule, count in rule_counts.items():
        print(f"  {rule}: {count}")
    
    client.close()


if __name__ == "__main__":
    main()
