const mongoose = require('mongoose');
const TransferExec = require('../models/TransferExec');
const TransferImpact = require('../models/TransferImpact');
const Stock = require('../models/Stock');
const Order = require('../models/Order');
const Product = require('../models/Product');

function isMongoTxNotSupported(err) {
  const msg = (err && (err.message || err.toString())) || '';
  return (
    msg.includes('Transaction numbers are only allowed') ||
    msg.includes('replica set member') ||
    msg.includes('mongos')
  );
}

function utcDayRange(date = new Date()) {
  const start = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), 0, 0, 0, 0));
  const end = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + 1, 0, 0, 0, 0));
  return { start, end };
}

const COST_PER_KM = 0.1;
const IMPACT_WINDOW_DAYS = 14;

async function computeAndUpsertImpactForExec(exec) {
  // Ensure product has price
  const populated = await TransferExec.findById(exec._id).populate('productId', 'name price productId');
  const productPrice = populated?.productId?.price || 0;
  const completedAt = populated?.completedAt || populated?.updatedAt || new Date();

  const windowStart = new Date(completedAt);
  const windowEnd = new Date(completedAt);
  windowEnd.setDate(windowEnd.getDate() + IMPACT_WINDOW_DAYS);

  const preWindowEnd = new Date(completedAt);
  const preWindowStart = new Date(completedAt);
  preWindowStart.setDate(preWindowStart.getDate() - IMPACT_WINDOW_DAYS);

  const salesAfterResult = await Order.aggregate([
    {
      $match: {
        productId: populated.productId._id,
        locationId: populated.toLocationId,
        status: 'purchased',
        timestamp: { $gte: windowStart, $lte: windowEnd }
      }
    },
    { $group: { _id: null, totalUnits: { $sum: '$quantity' } } }
  ]);
  const salesAfter = salesAfterResult[0]?.totalUnits || 0;

  const salesBeforeResult = await Order.aggregate([
    {
      $match: {
        productId: populated.productId._id,
        locationId: populated.toLocationId,
        status: 'purchased',
        timestamp: { $gte: preWindowStart, $lt: preWindowEnd }
      }
    },
    { $group: { _id: null, totalUnits: { $sum: '$quantity' } } }
  ]);
  const salesBefore = salesBeforeResult[0]?.totalUnits || 0;

  // Keep uplift metrics for reference, but "profit (approx)" is based on quantity moved × unit price.
  const upliftUnits = Math.max(0, salesAfter - salesBefore);
  const costUsed = (populated.distanceKm || 0) * COST_PER_KM;
  const upliftRevenue = upliftUnits * productPrice;

  // Per requirement: netProfit is an approximate profit = quantity transferred × product unit price
  const netProfit = (Number(populated.quantity) || 0) * productPrice;

  const now = new Date();

  const impact = await TransferImpact.findOneAndUpdate(
    { transferExecId: populated._id },
    {
      $setOnInsert: { transferExecId: populated._id },
      $set: {
        execId: populated.execId,
        productId: populated.productId._id,
        fromLocationId: populated.fromLocationId,
        toLocationId: populated.toLocationId,
        quantityMoved: populated.quantity,
        distanceKm: populated.distanceKm || 0,
        costPerKm: COST_PER_KM,
        costUsed,
        salesBefore,
        salesAfter,
        upliftUnits,
        productPrice,
        upliftRevenue,
        netProfit,
        windowStart,
        windowEnd,
        preWindowStart,
        preWindowEnd,
        analysisNotes: `Analysis window: ${IMPACT_WINDOW_DAYS} days before/after completion`,
        createdAt: now
      }
    },
    { upsert: true, new: true }
  );

  return impact;
}

// GET /api/transfers/summary
// Returns { transfers_pending, transfers_completed, total_profit_today }
async function getTransfersSummary(req, res) {
  try {
    const completed = await TransferExec.countDocuments({ status: 'completed' });

    const { start, end } = utcDayRange(new Date());
    const profitAgg = await TransferImpact.aggregate([
      { $match: { createdAt: { $gte: start, $lt: end } } },
      { $group: { _id: null, total: { $sum: '$netProfit' } } }
    ]);

    const total_profit_today = profitAgg[0]?.total ?? 0;

    return res.json({
      // Auto-complete flow: we no longer expose "pending" as a meaningful state
      transfers_pending: 0,
      transfers_completed: completed,
      total_profit_today
    });
  } catch (error) {
    console.error('GET /api/transfers/summary error:', error);
    return res.status(500).json({ message: 'Failed to compute transfers summary' });
  }
}

// GET /api/transfers/top
// Returns top 5 completed transfers by netProfit desc with names, qty, profit, date
async function getTopTransfers(req, res) {
  try {
    const top = await TransferImpact.aggregate([
      { $sort: { netProfit: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'transferexecs',
          localField: 'transferExecId',
          foreignField: '_id',
          as: 'exec'
        }
      },
      { $unwind: { path: '$exec', preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: 'products',
          localField: 'productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      { $unwind: { path: '$product', preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: 'locations',
          localField: 'fromLocationId',
          foreignField: '_id',
          as: 'fromLoc'
        }
      },
      { $unwind: { path: '$fromLoc', preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: 'locations',
          localField: 'toLocationId',
          foreignField: '_id',
          as: 'toLoc'
        }
      },
      { $unwind: { path: '$toLoc', preserveNullAndEmptyArrays: true } },
      {
        $project: {
          _id: 0,
          execId: '$execId',
          product: '$product.name',
          from: '$fromLoc.name',
          to: '$toLoc.name',
          quantity: '$quantityMoved',
          profit: '$netProfit',
          date: { $ifNull: ['$exec.completedAt', '$createdAt'] }
        }
      }
    ]);

    return res.json(top);
  } catch (error) {
    console.error('GET /api/transfers/top error:', error);
    return res.status(500).json({ message: 'Failed to fetch top transfers' });
  }
}

// POST /api/transfers/autocomplete-planned
// Auto-complete all historical planned transfers by applying stock moves and marking exec.completedAt.
async function autoCompletePlannedTransfers(req, res) {
  const limit = Math.min(Number(req.query.limit || 500), 2000);

  try {
    const plannedExecs = await TransferExec.find({ status: 'planned' })
      .sort({ approvedAt: 1, createdAt: 1 })
      .limit(limit);

    const results = [];
    let completed = 0;
    let cancelled = 0;
    let skipped = 0;

    for (const exec of plannedExecs) {
      // Defensive: only process truly planned
      if (exec.status !== 'planned') {
        skipped += 1;
        continue;
      }

      const qty = Number(exec.quantity) || 0;
      if (qty < 1) {
        exec.status = 'cancelled';
        exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}auto-complete: invalid qty`;
        await exec.save();
        cancelled += 1;
        results.push({ execId: exec.execId, status: 'cancelled', reason: 'invalid_qty' });
        continue;
      }

      const session = await mongoose.startSession();
      try {
        session.startTransaction();

        // Decrement source stock atomically
        const srcBeforeDoc = await Stock.findOne(
          { productId: exec.productId, locationId: exec.fromLocationId },
          { quantity: 1 }
        ).session(session);
        const dstBeforeDoc = await Stock.findOne(
          { productId: exec.productId, locationId: exec.toLocationId },
          { quantity: 1 }
        ).session(session);

        const src = await Stock.findOneAndUpdate(
          { productId: exec.productId, locationId: exec.fromLocationId, quantity: { $gte: qty } },
          { $inc: { quantity: -qty }, $set: { updatedAt: new Date() } },
          { new: true, session }
        );

        if (!src) {
          exec.status = 'cancelled';
          exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}auto-complete: insufficient stock at source`;
          await exec.save({ session });
          await session.commitTransaction();

          cancelled += 1;
          results.push({ execId: exec.execId, status: 'cancelled', reason: 'insufficient_stock' });
          continue;
        }

        // Increment target stock (upsert if missing)
        await Stock.updateOne(
          { productId: exec.productId, locationId: exec.toLocationId },
          { $inc: { quantity: qty }, $set: { updatedAt: new Date() } },
          { upsert: true, session }
        );

        // Store snapshots
        exec.fromQtyBefore = Number(srcBeforeDoc?.quantity || 0) || 0;
        exec.fromQtyAfter = Number(src.quantity || 0) || 0;
        const toBefore = Number(dstBeforeDoc?.quantity || 0) || 0;
        exec.toQtyBefore = toBefore;
        exec.toQtyAfter = toBefore + qty;

        exec.status = 'completed';
        exec.completedAt = new Date();
        exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}auto-completed`;
        await exec.save({ session });

        await session.commitTransaction();

        completed += 1;
        results.push({ execId: exec.execId, status: 'completed' });
      } catch (err) {
        if (isMongoTxNotSupported(err)) {
          // Fallback (no transactions): same logic, best-effort
          try {
            const srcBeforeDoc = await Stock.findOne(
              { productId: exec.productId, locationId: exec.fromLocationId },
              { quantity: 1 }
            );
            const dstBeforeDoc = await Stock.findOne(
              { productId: exec.productId, locationId: exec.toLocationId },
              { quantity: 1 }
            );

            const src = await Stock.findOneAndUpdate(
              { productId: exec.productId, locationId: exec.fromLocationId, quantity: { $gte: qty } },
              { $inc: { quantity: -qty }, $set: { updatedAt: new Date() } },
              { new: true }
            );

            if (!src) {
              exec.status = 'cancelled';
              exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}auto-complete: insufficient stock at source`;
              await exec.save();

              cancelled += 1;
              results.push({ execId: exec.execId, status: 'cancelled', reason: 'insufficient_stock' });
              continue;
            }

            await Stock.updateOne(
              { productId: exec.productId, locationId: exec.toLocationId },
              { $inc: { quantity: qty }, $set: { updatedAt: new Date() } },
              { upsert: true }
            );

            exec.fromQtyBefore = Number(srcBeforeDoc?.quantity || 0) || 0;
            exec.fromQtyAfter = Number(src.quantity || 0) || 0;
            const toBefore = Number(dstBeforeDoc?.quantity || 0) || 0;
            exec.toQtyBefore = toBefore;
            exec.toQtyAfter = toBefore + qty;

            exec.status = 'completed';
            exec.completedAt = new Date();
            exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}auto-completed`;
            await exec.save();

            completed += 1;
            results.push({ execId: exec.execId, status: 'completed' });
          } catch (fallbackErr) {
            console.error('autoCompletePlannedTransfers fallback error:', fallbackErr);
            results.push({ execId: exec.execId, status: 'error', reason: fallbackErr.message || 'error' });
          }
          continue;
        }

        console.error('autoCompletePlannedTransfers error:', err);
        results.push({ execId: exec.execId, status: 'error', reason: err.message || 'error' });
      } finally {
        try {
          await session.endSession();
        } catch {}
      }
    }

    return res.json({
      success: true,
      processed: plannedExecs.length,
      completed,
      cancelled,
      skipped,
      results
    });
  } catch (error) {
    console.error('POST /api/transfers/autocomplete-planned error:', error);
    return res.status(500).json({ success: false, message: 'Failed to auto-complete planned transfers' });
  }
}

// POST /api/transfers/backfill-impacts
// Computes and upserts impact docs for completed transfers that don't have one yet (or all, if force=1).
async function backfillImpacts(req, res) {
  const limit = Math.min(Number(req.query.limit || 500), 5000);
  const force = String(req.query.force || '0') === '1';

  try {
    const completedExecs = await TransferExec.find({ status: 'completed' })
      .sort({ completedAt: 1, updatedAt: 1 })
      .limit(limit)
      .lean();

    let processed = 0;
    let upserted = 0;
    let skipped = 0;
    const results = [];

    for (const exec of completedExecs) {
      processed += 1;
      try {
        if (!force) {
          const exists = await TransferImpact.findOne({ transferExecId: exec._id }, { _id: 1 }).lean();
          if (exists) {
            skipped += 1;
            continue;
          }
        }

        await computeAndUpsertImpactForExec(exec);
        upserted += 1;
        results.push({ execId: exec.execId, status: 'ok' });
      } catch (e) {
        results.push({ execId: exec.execId, status: 'error', reason: e?.message || 'error' });
      }
    }

    return res.json({
      success: true,
      processed,
      upserted,
      skipped,
      limit,
      force,
      results
    });
  } catch (error) {
    console.error('POST /api/transfers/backfill-impacts error:', error);
    return res.status(500).json({ success: false, message: 'Failed to backfill impacts' });
  }
}

// POST /api/transfers/backfill-snapshots
// Fill toQtyBefore/toQtyAfter (and fromQtyBefore/fromQtyAfter) for completed transfers.
// This is best-effort and uses current stock as an approximation:
//   toAfter ~= current target stock
//   toBefore ~= max(0, toAfter - qtyMoved)
async function backfillSnapshots(req, res) {
  const limit = Math.min(Number(req.query.limit || 5000), 20000);
  const force = String(req.query.force || '0') === '1';

  try {
    const execs = await TransferExec.find({ status: 'completed' })
      .sort({ completedAt: 1, updatedAt: 1 })
      .limit(limit);

    let processed = 0;
    let updated = 0;
    let skipped = 0;
    const results = [];

    for (const exec of execs) {
      processed += 1;

      const hasSnapshots =
        exec.toQtyBefore != null &&
        exec.toQtyAfter != null &&
        exec.fromQtyBefore != null &&
        exec.fromQtyAfter != null;

      if (hasSnapshots && !force) {
        skipped += 1;
        continue;
      }

      const qty = Number(exec.quantity) || 0;
      if (qty < 1) {
        skipped += 1;
        results.push({ execId: exec.execId, status: 'skipped', reason: 'invalid_qty' });
        continue;
      }

      const src = await Stock.findOne(
        { productId: exec.productId, locationId: exec.fromLocationId },
        { quantity: 1 }
      ).lean();
      const dst = await Stock.findOne(
        { productId: exec.productId, locationId: exec.toLocationId },
        { quantity: 1 }
      ).lean();

      const fromAfter = Number(src?.quantity || 0) || 0;
      const toAfter = Number(dst?.quantity || 0) || 0;

      exec.fromQtyAfter = fromAfter;
      exec.fromQtyBefore = fromAfter + qty;
      exec.toQtyAfter = toAfter;
      exec.toQtyBefore = Math.max(0, toAfter - qty);

      exec.notes = `${exec.notes ? exec.notes + ' | ' : ''}snapshots backfilled (approx)`;
      await exec.save();

      updated += 1;
      results.push({ execId: exec.execId, status: 'updated' });
    }

    return res.json({
      success: true,
      processed,
      updated,
      skipped,
      limit,
      force,
      results
    });
  } catch (error) {
    console.error('POST /api/transfers/backfill-snapshots error:', error);
    return res.status(500).json({ success: false, message: 'Failed to backfill snapshots' });
  }
}

module.exports = {
  getTransfersSummary,
  getTopTransfers,
  autoCompletePlannedTransfers,
  backfillImpacts,
  backfillSnapshots
};


