const mongoose = require('mongoose');

/**
 * TransferImpact Model
 * Tracks the business impact of completed transfers
 */
const transferImpactSchema = new mongoose.Schema({
  transferExecId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'TransferExec',
    required: true
  },
  execId: {
    type: String,
    required: true  // Human-readable exec ID (Txxxx)
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  fromLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  toLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  quantityMoved: {
    type: Number,
    required: true
  },
  // Cost calculations
  distanceKm: {
    type: Number,
    default: 0
  },
  costPerKm: {
    type: Number,
    default: 0.1  // Default cost per km
  },
  costUsed: {
    type: Number,
    required: true  // distance_km * cost_per_km
  },
  // Sales impact at target location
  salesBefore: {
    type: Number,
    default: 0  // Units sold in 14 days before transfer
  },
  salesAfter: {
    type: Number,
    default: 0  // Units sold in 14 days after transfer
  },
  upliftUnits: {
    type: Number,
    default: 0  // salesAfter - salesBefore
  },
  // Revenue calculations
  productPrice: {
    type: Number,
    default: 0
  },
  upliftRevenue: {
    type: Number,
    default: 0  // upliftUnits * productPrice
  },
  // Net profit
  netProfit: {
    type: Number,
    default: 0  // upliftRevenue - costUsed
  },
  // Analysis windows
  windowStart: {
    type: Date,
    required: true  // Start of post-transfer analysis window
  },
  windowEnd: {
    type: Date,
    required: true  // End of post-transfer analysis window
  },
  preWindowStart: {
    type: Date  // Start of pre-transfer comparison window
  },
  preWindowEnd: {
    type: Date  // End of pre-transfer comparison window
  },
  // Metadata
  analysisNotes: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Indexes
transferImpactSchema.index({ transferExecId: 1 }, { unique: true });
transferImpactSchema.index({ productId: 1 });
transferImpactSchema.index({ toLocationId: 1 });
transferImpactSchema.index({ netProfit: -1 });
transferImpactSchema.index({ createdAt: -1 });

module.exports = mongoose.model('TransferImpact', transferImpactSchema);

