const Stock = require('../models/Stock');
const Product = require('../models/Product');
const Location = require('../models/Location');

// Get stock for a specific location
const getStockByLocation = async (req, res) => {
  try {
    const { locationId } = req.params;
    
    const stock = await Stock.find({ locationId })
      .populate('productId', 'name category price description')
      .populate('locationId', 'name city address')
      .sort({ 'productId.name': 1 });

    res.json({
      success: true,
      data: stock
    });
  } catch (error) {
    console.error('Get stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch stock'
    });
  }
};

// Get all stock with product and location details
const getAllStock = async (req, res) => {
  try {
    const stock = await Stock.find()
      .populate('productId', 'name category price description')
      .populate('locationId', 'name city address')
      .sort({ 'locationId.name': 1, 'productId.name': 1 });

    res.json({
      success: true,
      data: stock
    });
  } catch (error) {
    console.error('Get all stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch stock'
    });
  }
};

// Update stock quantity
const updateStock = async (req, res) => {
  try {
    const { productId, locationId, quantity } = req.body;

    // Validate that product and location exist
    const product = await Product.findById(productId);
    const location = await Location.findById(locationId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'Location not found'
      });
    }

    // Update or create stock entry
    const stock = await Stock.findOneAndUpdate(
      { productId, locationId },
      { quantity },
      { new: true, upsert: true, runValidators: true }
    ).populate('productId', 'name category price')
     .populate('locationId', 'name city');

    res.json({
      success: true,
      message: 'Stock updated successfully',
      data: stock
    });
  } catch (error) {
    console.error('Update stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update stock'
    });
  }
};

// Get stock summary for dashboard
const getStockSummary = async (req, res) => {
  try {
    console.log('Fetching stock summary...');
    
    // Calculate basic counts
    const totalProducts = await Product.countDocuments();
    const totalLocations = await Location.countDocuments();
    const totalStockEntries = await Stock.countDocuments();
    
    console.log(`Database has ${totalStockEntries} stock entries (${totalProducts} products × ${totalLocations} locations)`);
    
    // ========== STOCK ENTRY LEVEL METRICS ==========
    // Count stock entries (product-location pairs) by stock level
    // This gives actionable insights: "X entries need restocking"
    
    const stockEntryCounts = await Stock.aggregate([
      {
        $group: {
          _id: null,
          outOfStockEntries: {
            $sum: { $cond: [{ $eq: ['$quantity', 0] }, 1, 0] }
          },
          lowStockEntries: {
            $sum: { $cond: [{ $and: [{ $gt: ['$quantity', 0] }, { $lt: ['$quantity', 5] }] }, 1, 0] }
          },
          healthyStockEntries: {
            $sum: { $cond: [{ $gte: ['$quantity', 5] }, 1, 0] }
          },
          totalQuantity: { $sum: '$quantity' }
        }
      }
    ]);

    const entryCounts = stockEntryCounts[0] || {
      outOfStockEntries: 0,
      lowStockEntries: 0,
      healthyStockEntries: 0,
      totalQuantity: 0
    };

    // ========== PRODUCTS WITH STOCKOUTS ==========
    // Count products that have at least one location with zero stock
    const productsWithStockouts = await Stock.aggregate([
      { $match: { quantity: 0 } },
      { $group: { _id: '$productId' } },
      { $count: 'count' }
    ]);
    const productsWithAnyStockout = productsWithStockouts[0]?.count || 0;

    // ========== PRODUCTS WITH LOW STOCK ==========
    // Count products that have at least one location with low stock (1-4)
    const productsWithLowStock = await Stock.aggregate([
      { $match: { quantity: { $gt: 0, $lt: 5 } } },
      { $group: { _id: '$productId' } },
      { $count: 'count' }
    ]);
    const productsWithAnyLowStock = productsWithLowStock[0]?.count || 0;

    // ========== TOTAL INVENTORY VALUE ==========
    const totalValueResult = await Stock.aggregate([
      {
        $lookup: {
          from: 'products',
          localField: 'productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      {
        $unwind: {
          path: '$product',
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $group: {
          _id: null,
          totalValue: {
            $sum: {
              $multiply: [
                { $ifNull: ['$product.price', 0] },
                '$quantity'
              ]
            }
          }
        }
      }
    ]);
    const totalValue = totalValueResult.length > 0 ? totalValueResult[0].totalValue : 0;

    // ========== CATEGORY BREAKDOWN ==========
    const categoryBreakdown = await Stock.aggregate([
      {
        $lookup: {
          from: 'products',
          localField: 'productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      {
        $unwind: {
          path: '$product',
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $group: {
          _id: '$product.category',
          totalQuantity: { $sum: '$quantity' },
          entryCount: { $sum: 1 },
          totalValue: {
            $sum: {
              $multiply: [
                { $ifNull: ['$product.price', 0] },
                '$quantity'
              ]
            }
          }
        }
      },
      { $sort: { totalQuantity: -1 } }
    ]);

    // Find top category
    const topCategory = categoryBreakdown.length > 0 ? categoryBreakdown[0]._id : 'N/A';

    // ========== STOCK FOR DISPLAY (Limited) ==========
    const displayLimit = 1000;
    let stockForDisplay;
    if (totalStockEntries > displayLimit) {
      console.log(`Limiting display stock entries to ${displayLimit} for UI (total: ${totalStockEntries})`);
      stockForDisplay = await Stock.find()
        .populate('productId', 'name category price')
        .populate('locationId', 'name city address')
        .limit(displayLimit)
        .sort({ quantity: 1 }); // Show lowest stock first for actionable insights
    } else {
      stockForDisplay = await Stock.find()
        .populate('productId', 'name category price')
        .populate('locationId', 'name city address')
        .sort({ quantity: 1 });
    }

    console.log('Stock entries for display:', stockForDisplay.length);
    
    // Check for unpopulated references
    const unpopulatedProducts = stockForDisplay.filter(s => !s.productId || typeof s.productId === 'string').length;
    const unpopulatedLocations = stockForDisplay.filter(s => !s.locationId || typeof s.locationId === 'string').length;
    
    if (unpopulatedProducts > 0) {
      console.warn(`⚠️  ${unpopulatedProducts} stock entries have unpopulated productId`);
    }
    if (unpopulatedLocations > 0) {
      console.warn(`⚠️  ${unpopulatedLocations} stock entries have unpopulated locationId`);
    }

    console.log('Stock summary calculated:', {
      totalProducts,
      totalLocations,
      totalStockEntries,
      outOfStockEntries: entryCounts.outOfStockEntries,
      lowStockEntries: entryCounts.lowStockEntries,
      healthyStockEntries: entryCounts.healthyStockEntries,
      productsWithAnyStockout,
      productsWithAnyLowStock,
      totalValue,
      topCategory,
      stockEntriesForDisplay: stockForDisplay.length
    });

    res.json({
      success: true,
      data: {
        // Basic counts
        totalProducts,
        totalLocations,
        totalStockEntries,
        
        // Stock entry level metrics (product-location pairs)
        outOfStockEntries: entryCounts.outOfStockEntries,
        lowStockEntries: entryCounts.lowStockEntries,
        healthyStockEntries: entryCounts.healthyStockEntries,
        
        // Product level metrics
        productsWithAnyStockout,
        productsWithAnyLowStock,
        
        // Totals
        totalQuantity: entryCounts.totalQuantity,
        totalValue,
        
        // Category data
        topCategory,
        categoryBreakdown,
        
        // Display data (limited)
        stockEntriesReturned: stockForDisplay.length,
        stock: stockForDisplay || []
      }
    });
  } catch (error) {
    console.error('Get stock summary error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch stock summary',
      error: error.message
    });
  }
};

module.exports = {
  getStockByLocation,
  getAllStock,
  updateStock,
  getStockSummary
};
