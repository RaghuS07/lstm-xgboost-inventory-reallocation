const express = require('express');
const { authenticateToken, validateApiKey, authorizeRole } = require('../middleware/auth');
const { getTransfersSummary, getTopTransfers, autoCompletePlannedTransfers, backfillImpacts, backfillSnapshots } = require('../controllers/transfersController');

const router = express.Router();

router.use(authenticateToken);
router.use(validateApiKey);
router.use(authorizeRole(['seller', 'manager', 'admin']));

router.get('/summary', getTransfersSummary);
router.get('/top', getTopTransfers);
router.post('/autocomplete-planned', autoCompletePlannedTransfers);
router.post('/backfill-impacts', backfillImpacts);
router.post('/backfill-snapshots', backfillSnapshots);

module.exports = router;


