const express = require('express');
const { authenticateToken, validateApiKey, authorizeRole } = require('../middleware/auth');
const { getStockHealthAlerts, getDemandSurgeAlerts } = require('../controllers/alertsController');

const router = express.Router();

router.use(authenticateToken);
router.use(validateApiKey);
router.use(authorizeRole(['seller', 'manager', 'admin']));

router.get('/stock-health', getStockHealthAlerts);
router.get('/demand-surge', getDemandSurgeAlerts);

module.exports = router;


