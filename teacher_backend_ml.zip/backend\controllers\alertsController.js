const mongoose = require('mongoose');
const Stock = require('../models/Stock');

// GET /api/alerts/stock-health
// Returns up to 50 low/out-of-stock entries with product & location names.
async function getStockHealthAlerts(req, res) {
  try {
    const alerts = await Stock.find({ quantity: { $lte: 4 } })
      .populate('productId', 'name productId')
      .populate('locationId', 'name city locationId')
      .sort({ quantity: 1, updatedAt: -1 })
      .limit(50)
      .lean();

    const mapped = alerts.map((s) => ({
      product: s.productId?.name || 'Unknown',
      location: s.locationId?.name || 'Unknown',
      quantity: s.quantity,
      level: s.quantity === 0 ? 'out_of_stock' : 'low_stock'
    }));

    return res.json(mapped);
  } catch (error) {
    console.error('GET /api/alerts/stock-health error:', error);
    return res.status(500).json({ message: 'Failed to fetch stock health alerts' });
  }
}

// GET /api/alerts/demand-surge
// Demand surge: predicted > 2 * avg(last_14_days_sales)
async function getDemandSurgeAlerts(req, res) {
  try {
    const db = mongoose.connection.db;
    if (!db) {
      return res.status(500).json({ message: 'Database connection not ready' });
    }

    const forecastCol = db.collection('forecast');

    const now = new Date();
    const start14 = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);

    // Default modelTag to latest forecast tag unless explicitly overridden
    const modelTag = (req.query.modelTag || 'lstm_v1_unscaled').toString().trim();
    const match = { modelTag };

    const pipeline = [
      { $match: match },
      // predicted_demand = avg of yhat array (daily predicted average over horizon)
      { $addFields: { predicted_demand: { $avg: '$yhat' } } },
      // Join Product by business productId string -> products.productId
      {
        $lookup: {
          from: 'products',
          let: { pid: '$productId' },
          pipeline: [
            { $match: { $expr: { $eq: ['$productId', '$$pid'] } } },
            { $project: { _id: 1 } }
          ],
          as: 'prod'
        }
      },
      { $unwind: { path: '$prod', preserveNullAndEmptyArrays: false } },
      // Join Location by business locationId string -> locations.locationId
      {
        $lookup: {
          from: 'locations',
          let: { lid: '$locationId' },
          pipeline: [
            { $match: { $expr: { $eq: ['$locationId', '$$lid'] } } },
            { $project: { _id: 1 } }
          ],
          as: 'loc'
        }
      },
      { $unwind: { path: '$loc', preserveNullAndEmptyArrays: false } },
      // Lookup last 14 days purchased orders
      {
        $lookup: {
          from: 'orders',
          let: { productObjId: '$prod._id', locationObjId: '$loc._id' },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ['$status', 'purchased'] },
                    { $eq: ['$productId', '$$productObjId'] },
                    { $eq: ['$locationId', '$$locationObjId'] },
                    { $gte: ['$timestamp', start14] }
                  ]
                }
              }
            },
            { $group: { _id: null, totalQty: { $sum: '$quantity' } } }
          ],
          as: 'hist'
        }
      },
      { $addFields: { historical_total_14d: { $ifNull: [{ $arrayElemAt: ['$hist.totalQty', 0] }, 0] } } },
      { $addFields: { historical_avg: { $divide: ['$historical_total_14d', 14] } } },
      // Define surge condition:
      // - if historical_avg > 0: predicted_demand > 2 * historical_avg
      // - if historical_avg == 0: predicted_demand > 0 (new surge)
      {
        $addFields: {
          surge_ratio: {
            $cond: [
              { $gt: ['$historical_avg', 0] },
              { $divide: ['$predicted_demand', '$historical_avg'] },
              null
            ]
          }
        }
      },
      {
        $match: {
          $expr: {
            $or: [
              {
                $and: [
                  { $gt: ['$historical_avg', 0] },
                  { $gt: ['$predicted_demand', { $multiply: [2, '$historical_avg'] }] }
                ]
              },
              {
                $and: [
                  { $eq: ['$historical_avg', 0] },
                  { $gt: ['$predicted_demand', 0] }
                ]
              }
            ]
          }
        }
      },
      // Sort: real ratios first, then "new surges" with null ratio by predicted demand
      { $sort: { surge_ratio: -1, predicted_demand: -1 } },
      { $limit: 50 },
      {
        $project: {
          _id: 0,
          productId: 1,
          locationId: 1,
          predicted_demand: { $ifNull: ['$predicted_demand', 0] },
          historical_avg: 1,
          surge_ratio: { $ifNull: ['$surge_ratio', 0] }
        }
      }
    ];

    const results = await forecastCol.aggregate(pipeline, { allowDiskUse: true }).toArray();
    return res.json(results);
  } catch (error) {
    console.error('GET /api/alerts/demand-surge error:', error);
    return res.status(500).json({ message: 'Failed to fetch demand surge alerts' });
  }
}

module.exports = {
  getStockHealthAlerts,
  getDemandSurgeAlerts
};


