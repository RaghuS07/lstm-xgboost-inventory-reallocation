const Recommendation = require('../models/Recommendation');
const Product = require('../models/Product');
const Location = require('../models/Location');

// Get all recommendations
const getRecommendations = async (req, res) => {
  try {
  const recommendations = await Recommendation.find()
      .populate('productId', 'name category price')
      .populate('fromLocationId', 'name city latitude longitude')
      .populate('toLocationId', 'name city latitude longitude')
      .sort({ priority: -1, createdAt: -1 });

    res.json({
      success: true,
      // Never return invalid/zero-qty recommendations (filter in-memory to avoid any query operator issues)
      data: recommendations.filter((r) => {
        const qty = Number(r.quantity || 0);
        if (!Number.isFinite(qty) || qty < 1) return false;
        if (String(r.fromLocationId?._id) === String(r.toLocationId?._id)) return false;
        return true;
      })
    });
  } catch (error) {
    console.error('Get recommendations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recommendations'
    });
  }
};

// Get single recommendation
const getRecommendation = async (req, res) => {
  try {
  const recommendation = await Recommendation.findById(req.params.id)
      .populate('productId', 'name category price')
      .populate('fromLocationId', 'name city latitude longitude')
      .populate('toLocationId', 'name city latitude longitude');

    if (!recommendation) {
      return res.status(404).json({
        success: false,
        message: 'Recommendation not found'
      });
    }

    res.json({
      success: true,
      data: recommendation
    });
  } catch (error) {
    console.error('Get recommendation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recommendation'
    });
  }
};

// Approve recommendation - delegates to transferExecController for full workflow
const { createFromRecommendation } = require('./transferExecController');

const approveRecommendation = createFromRecommendation;

// Create recommendation (for testing/admin purposes)
const createRecommendation = async (req, res) => {
  try {
    const { productId, fromLocationId, toLocationId, quantity, priority } = req.body;

    // Validate that product and locations exist
    const product = await Product.findById(productId);
    const fromLocation = await Location.findById(fromLocationId);
    const toLocation = await Location.findById(toLocationId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    if (!fromLocation) {
      return res.status(404).json({
        success: false,
        message: 'From location not found'
      });
    }

    if (!toLocation) {
      return res.status(404).json({
        success: false,
        message: 'To location not found'
      });
    }

    const recommendation = new Recommendation({
      productId,
      fromLocationId,
      toLocationId,
      quantity,
      priority: priority || 'medium'
    });

    await recommendation.save();

    // Populate the recommendation
    await recommendation.populate('productId', 'name category price');
    await recommendation.populate('fromLocationId', 'name city latitude longitude');
    await recommendation.populate('toLocationId', 'name city latitude longitude');

    res.status(201).json({
      success: true,
      message: 'Recommendation created successfully',
      data: recommendation
    });
  } catch (error) {
    console.error('Create recommendation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create recommendation'
    });
  }
};

module.exports = {
  getRecommendations,
  getRecommendation,
  approveRecommendation,
  createRecommendation
};
