"""
Cleanup old forecast and transfer candidate data.
Only deletes:
- forecast docs with modelTag="lstm_v1" (old scaled forecasts)
- transfer_candidates created before the new forecasts (or without modelTag link)
"""
from pymongo import MongoClient
from datetime import datetime, timezone

db = MongoClient('mongodb://localhost:27017')['supply-demand']

print('=== BEFORE CLEANUP ===')
total_forecasts = db['forecast'].count_documents({})
lstm_v1_forecasts = db['forecast'].count_documents({'modelTag': 'lstm_v1'})
lstm_v1_unscaled_forecasts = db['forecast'].count_documents({'modelTag': 'lstm_v1_unscaled'})
total_candidates = db['transfer_candidates'].count_documents({})

print(f'Total forecasts: {total_forecasts}')
print(f'  - lstm_v1 (old scaled): {lstm_v1_forecasts}')
print(f'  - lstm_v1_unscaled (new): {lstm_v1_unscaled_forecasts}')
print(f'Total transfer_candidates: {total_candidates}')

# Delete old lstm_v1 forecasts
print('\n=== DELETING OLD DATA ===')
result1 = db['forecast'].delete_many({'modelTag': 'lstm_v1'})
print(f'Deleted {result1.deleted_count} forecast docs (modelTag="lstm_v1")')

# Delete old transfer_candidates (those created before the new run)
# We'll delete all candidates that were created before our new forecasts
# Since we just ran the new forecast, delete candidates created before today's new run
# Actually, the safest is to delete all candidates NOT linked to the new modelTag
# But transfer_candidates don't have a modelTag field, so we delete the older ones

# Get the oldest createdAt from the new forecasts
new_forecasts = list(db['forecast'].find({'modelTag': 'lstm_v1_unscaled'}, {'generatedAt': 1}).sort('generatedAt', 1).limit(1))
if new_forecasts:
    cutoff_time = new_forecasts[0].get('generatedAt')
    print(f'Cutoff time for candidates: {cutoff_time}')
    
    # Delete candidates created BEFORE the new forecasts were generated
    result2 = db['transfer_candidates'].delete_many({'createdAt': {'$lt': cutoff_time}})
    print(f'Deleted {result2.deleted_count} old transfer_candidates (created before new forecasts)')
else:
    # Fallback: delete all candidates (they were all from old forecasts)
    result2 = db['transfer_candidates'].delete_many({})
    print(f'Deleted {result2.deleted_count} transfer_candidates (fallback: all)')

# Also clean up old forecast_eval entries for lstm_v1
result3 = db['forecast_eval'].delete_many({'modelTag': 'lstm_v1'})
print(f'Deleted {result3.deleted_count} forecast_eval docs (modelTag="lstm_v1")')

print('\n=== AFTER CLEANUP ===')
total_forecasts_after = db['forecast'].count_documents({})
remaining_lstm_v1 = db['forecast'].count_documents({'modelTag': 'lstm_v1'})
remaining_unscaled = db['forecast'].count_documents({'modelTag': 'lstm_v1_unscaled'})
total_candidates_after = db['transfer_candidates'].count_documents({})
total_eval_after = db['forecast_eval'].count_documents({})

print(f'Total forecasts: {total_forecasts_after}')
print(f'  - lstm_v1: {remaining_lstm_v1}')
print(f'  - lstm_v1_unscaled: {remaining_unscaled}')
print(f'Total transfer_candidates: {total_candidates_after}')
print(f'Total forecast_eval: {total_eval_after}')

