const mongoose = require('mongoose');
const Order = require('../models/Order');
const Stock = require('../models/Stock');
const Product = require('../models/Product');
const Location = require('../models/Location');
const { refreshRecommendationsForProduct } = require('../services/recommendationRealtime');

function isTxnNotSupportedError(err) {
  const msg = (err && (err.message || err.toString())) || '';
  return (
    msg.includes('Transaction numbers are only allowed') ||
    msg.includes('replica set member') ||
    msg.includes('mongos')
  );
}

// Order product (direct purchase)
const orderProduct = async (req, res) => {
  const { productId, locationId, quantity } = req.body;
  const userId = req.user.id;

  // Check if product and location exist
  const product = await Product.findById(productId);
  const location = await Location.findById(locationId);

  if (!product) {
    return res.status(404).json({
      success: false,
      message: 'Product not found'
    });
  }

  if (!location) {
    return res.status(404).json({
      success: false,
      message: 'Location not found'
    });
  }

  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 1) {
    return res.status(400).json({
      success: false,
      message: 'Invalid quantity'
    });
  }

  const session = await mongoose.startSession();
  try {
    session.startTransaction();

    // Atomic stock decrement (with txn)
    const updatedStock = await Stock.findOneAndUpdate(
      { productId, locationId, quantity: { $gte: qty } },
      { $inc: { quantity: -qty }, $set: { updatedAt: new Date() } },
      { new: true, session }
    );

    if (!updatedStock) {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: 'Insufficient stock available'
      });
    }

    // Create order directly as purchased (no extra approval step)
    const order = new Order({
      userId,
      productId,
      locationId,
      quantity: qty,
      status: 'purchased'
    });

    await order.save({ session });
    await order.populate('productId', 'name category price');
    await order.populate('locationId', 'name city');

    await session.commitTransaction();

    // Refresh recommendations for this product based on updated stock (best-effort)
    try {
      await refreshRecommendationsForProduct(productId);
    } catch (e) {
      console.warn('[orderProduct] recommendation refresh failed:', e?.message || e);
    }

    res.status(201).json({
      success: true,
      message: 'Product purchased successfully',
      data: order
    });
  } catch (error) {
    // Fallback for standalone MongoDB (no transactions)
    if (isTxnNotSupportedError(error)) {
      try {
        console.warn('[orderProduct] Transactions not supported by MongoDB deployment. Falling back to no-tx flow.');

        const updatedStock = await Stock.findOneAndUpdate(
          { productId, locationId, quantity: { $gte: qty } },
          { $inc: { quantity: -qty }, $set: { updatedAt: new Date() } },
          { new: true }
        );

        if (!updatedStock) {
          return res.status(400).json({
            success: false,
            message: 'Insufficient stock available'
          });
        }

        const order = new Order({
          userId,
          productId,
          locationId,
          quantity: qty,
          status: 'purchased'
        });

        try {
          await order.save();
        } catch (saveErr) {
          // rollback stock on order save failure
          await Stock.updateOne(
            { productId, locationId },
            { $inc: { quantity: qty }, $set: { updatedAt: new Date() } }
          );
          throw saveErr;
        }

        await order.populate('productId', 'name category price');
        await order.populate('locationId', 'name city');

        // Refresh recommendations for this product based on updated stock (best-effort)
        try {
          await refreshRecommendationsForProduct(productId);
        } catch (e) {
          console.warn('[orderProduct] recommendation refresh failed (fallback):', e?.message || e);
        }

        return res.status(201).json({
          success: true,
          message: 'Product purchased successfully',
          data: order
        });
      } catch (fallbackErr) {
        console.error('Order product (fallback) error:', fallbackErr);
        return res.status(500).json({
          success: false,
          message: 'Failed to purchase product'
        });
      }
    }

    console.error('Order product error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to purchase product'
    });
  } finally {
    try {
      await session.endSession();
    } catch {}
  }
};

// Purchase product (convert reservation to purchase)
const purchaseProduct = async (req, res) => {
  try {
    const { orderId } = req.params;
    const userId = req.user.id;

    // Find the order
    const order = await Order.findOne({ _id: orderId, userId });
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    if (order.status !== 'ordered' && order.status !== 'reserved') {
      return res.status(400).json({
        success: false,
        message: 'Order must be in an ordered status to purchase'
      });
    }

    // Stock is decremented at order time in our flow. Do NOT decrement again here.

    // Update order status
    order.status = 'purchased';
    await order.save();

    // Populate the order with product and location details
    await order.populate('productId', 'name category price');
    await order.populate('locationId', 'name city');

    res.json({
      success: true,
      message: 'Product purchased successfully',
      data: order
    });
  } catch (error) {
    console.error('Purchase product error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to purchase product'
    });
  }
};

// Get user orders
const getUserOrders = async (req, res) => {
  try {
    const { userId } = req.params;
    const requestingUserId = req.user.id;

    // Users can only view their own orders (unless admin)
    if (requestingUserId !== userId && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const orders = await Order.find({ userId })
      .populate('productId', 'name category price')
      .populate('locationId', 'name city')
      .sort({ timestamp: -1 });

    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    console.error('Get user orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch orders'
    });
  }
};

// Cancel order
const cancelOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const userId = req.user.id;

    const order = await Order.findOne({ _id: orderId, userId });
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    if (order.status === 'purchased') {
      return res.status(400).json({
        success: false,
        message: 'Cannot cancel a purchased order'
      });
    }

    // If the order was already deducted from stock (legacy 'ordered' flow), restore it on cancel.
    if (order.status === 'ordered' || order.status === 'reserved') {
      await Stock.updateOne(
        { productId: order.productId, locationId: order.locationId },
        { $inc: { quantity: order.quantity }, $set: { updatedAt: new Date() } }
      );
    }

    order.status = 'cancelled';
    await order.save();

    res.json({
      success: true,
      message: 'Order cancelled successfully',
      data: order
    });
  } catch (error) {
    console.error('Cancel order error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to cancel order'
    });
  }
};

module.exports = {
  orderProduct,
  purchaseProduct,
  getUserOrders,
  cancelOrder
};
