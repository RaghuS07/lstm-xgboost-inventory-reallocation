"""
ml/run_lstm_forecast.py

Autoregressive LSTM forecasting runner.

Preconditions:
- ml/models/lstm_forecast.pt exists (state_dict saved by training)
- ml/models/metadata.json exists (keys: combos list, window, dates)
- ml/models/scaler.npy exists (saved [min_, scale_] from training)
- ml/data/training_data.csv exists (same CSV used for training)

Usage:
    python ml/run_lstm_forecast.py
"""
import os
import json
from pathlib import Path
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
from bson import ObjectId
from pymongo import MongoClient
import torch
import torch.nn as nn

# ---------- Config ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

DATA_CSV = Path("ml/data/training_data.csv")
MODELS_DIR = Path("ml/models")
MODEL_FILE = MODELS_DIR / "lstm_forecast.pt"
METADATA_FILE = MODELS_DIR / "metadata.json"
SCALER_FILE = MODELS_DIR / "scaler.npy"

HORIZON = 7              # days to forecast
BATCH_INSERT = 200       # number of forecast docs per insert_many
MODEL_TAG = "lstm_v1_unscaled"  # New model tag for unscaled predictions
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# LSTM model class must match training
class LSTMForecast(nn.Module):
    def __init__(self, input_size=1, hidden_size=64, num_layers=2):
        super().__init__()
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                            num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        out, _ = self.lstm(x)
        last = out[:, -1, :]
        out = self.fc(last)
        return out.squeeze(1)


# ---------- Helpers for scaler ----------
def load_scaler_params(path: Path):
    """
    scaler.npy was saved as numpy array([min_, scale_], dtype=object)
    where min_ and scale_ are arrays from sklearn MinMaxScaler.
    
    sklearn MinMaxScaler with feature_range=(0,1):
      transform: X_scaled = X * scale_ + min_
      inverse:   X = (X_scaled - min_) / scale_
    
    Returns transform and inverse functions.
    """
    arr = np.load(path, allow_pickle=True)
    min_val = float(np.array(arr[0]).ravel()[0])
    scale_val = float(np.array(arr[1]).ravel()[0])
    
    print(f"[Scaler] min_={min_val:.6f}, scale_={scale_val:.6f}")
    
    # Compute data range for verification
    # For feature_range=(0,1): min_ = -data_min * scale_, scale_ = 1/(data_max - data_min)
    # So: data_min = -min_ / scale_, data_range = 1/scale_
    data_min = -min_val / scale_val if scale_val != 0 else 0
    data_range = 1 / scale_val if scale_val != 0 else 1
    print(f"[Scaler] Inferred data_min={data_min:.2f}, data_range={data_range:.2f}")
    
    def transform(X):
        """Transform raw values to scaled [0,1] range."""
        X = np.array(X, dtype=float)
        return X * scale_val + min_val
    
    def inverse(X_scaled):
        """Inverse transform scaled values back to original units."""
        X_scaled = np.array(X_scaled, dtype=float)
        if scale_val == 0:
            return X_scaled
        return (X_scaled - min_val) / scale_val
    
    return transform, inverse


# ---------- Data pivot utility ----------
def pivot_and_fill(df):
    """
    df: DataFrame with columns date, productId, locationId, units_sold
    returns:
      all_dates (DatetimeIndex),
      combo_series dict: key -> 1D numpy array (float)
    """
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df["productId"] = df["productId"].astype(str)
    df["locationId"] = df["locationId"].astype(str)
    df["combo"] = df["productId"] + "||" + df["locationId"]

    min_date = df["date"].min()
    max_date = df["date"].max()
    all_dates = pd.date_range(min_date, max_date, freq="D")

    grouped = df.groupby(["combo", "date"])["units_sold"].sum().reset_index()
    combos = grouped["combo"].unique()

    combo_series = {}
    for combo in combos:
        s = grouped[grouped["combo"] == combo].set_index("date")["units_sold"]
        s = s.reindex(all_dates, fill_value=0)
        combo_series[combo] = s.values.astype(float)

    return all_dates, combo_series


# ---------- Forecast generation ----------
def generate_forecasts():
    assert MODEL_FILE.exists(), f"{MODEL_FILE} not found."
    assert METADATA_FILE.exists(), f"{METADATA_FILE} not found."
    assert SCALER_FILE.exists(), f"{SCALER_FILE} not found."
    assert DATA_CSV.exists(), f"{DATA_CSV} not found."

    print(f"Model file: {MODEL_FILE}")
    print(f"Metadata file: {METADATA_FILE}")
    print(f"Scaler file: {SCALER_FILE}")
    print(f"Data CSV: {DATA_CSV}")
    print()

    # load metadata & scaler
    with open(METADATA_FILE, "r") as f:
        metadata = json.load(f)
    combos = metadata.get("combos", [])
    window = int(metadata.get("window", 30))
    print(f"Loaded metadata: {len(combos)} combos, window={window}")

    transform_fn, inverse_fn = load_scaler_params(SCALER_FILE)
    
    # Verify inverse transform with a test value
    test_scaled = 0.5
    test_unscaled = inverse_fn(np.array([[test_scaled]]))[0, 0]
    print(f"[Test] inverse(0.5) = {test_unscaled:.2f}")
    print()

    # load training CSV and pivot series
    df = pd.read_csv(DATA_CSV, parse_dates=["date"])
    _, combo_series = pivot_and_fill(df)
    print(f"Loaded {len(combo_series)} combo series from CSV")

    # load model
    model = LSTMForecast(input_size=1, hidden_size=64, num_layers=2).to(DEVICE)
    state = torch.load(MODEL_FILE, map_location=DEVICE, weights_only=True)
    model.load_state_dict(state)
    model.eval()
    print(f"Loaded model to {DEVICE}")

    # connect to mongo
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    forecast_col = db["forecast"]

    # optional: create an index for forecast collection
    try:
        forecast_col.create_index([("productId", 1), ("locationId", 1), ("startDate", 1), ("modelTag", 1)])
    except Exception:
        pass

    docs_batch = []
    total_written = 0
    sample_doc = None

    for combo in combos:
        if combo not in combo_series:
            continue
        series = combo_series[combo]
        if len(series) < window:
            continue

        # pick last `window` days as input
        last_window = series[-window:].astype(float)

        # scale input
        X_in = transform_fn(last_window.reshape(-1, 1)).reshape(1, window, 1).astype(np.float32)

        preds_unscaled = []
        preds_scaled = []
        Xcur = X_in.copy()  # shape (1, window, 1)

        # autoregressive HORIZON steps
        for step in range(HORIZON):
            xt = torch.tensor(Xcur, dtype=torch.float32).to(DEVICE)
            with torch.no_grad():
                y_scaled = model(xt)  # (batch,) - scaled prediction
            y_scaled_np = y_scaled.cpu().numpy().reshape(-1, 1)
            y_scaled_val = float(y_scaled_np[0, 0])
            
            # inverse scale to get actual units
            y_unscaled = inverse_fn(y_scaled_np)[0, 0]
            
            # ensure non-negative
            if y_unscaled < 0:
                y_unscaled = 0.0
            
            preds_unscaled.append(float(y_unscaled))
            preds_scaled.append(y_scaled_val)

            # append predicted (scaled) value to Xcur for next step
            y_scaled_for_input = np.array([[[y_scaled_val]]], dtype=np.float32)
            # roll window left and append
            Xcur = np.concatenate([Xcur[:, 1:, :], y_scaled_for_input], axis=1)

        # parse productId and locationId
        try:
            pid_str, lid_str = combo.split("||")
            # Keep as strings (matching existing forecast format)
            pid = pid_str
            lid = lid_str
        except Exception:
            pid, lid = combo, combo

        # compute start and end dates for forecast
        last_date = df["date"].max().date()
        start_date = (last_date + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
        end_date = (last_date + pd.Timedelta(days=HORIZON)).strftime("%Y-%m-%d")

        doc = {
            "productId": pid,
            "locationId": lid,
            "startDate": start_date,
            "endDate": end_date,
            "horizonDays": HORIZON,
            "yhat": preds_unscaled,           # Unscaled predictions (actual units)
            "yhat_scaled": preds_scaled,      # Scaled predictions for traceability
            "modelTag": MODEL_TAG,
            "generatedAt": datetime.now(timezone.utc)
        }

        if sample_doc is None:
            sample_doc = doc.copy()

        docs_batch.append(doc)

        if len(docs_batch) >= BATCH_INSERT:
            forecast_col.insert_many(docs_batch)
            total_written += len(docs_batch)
            print(f"Wrote {total_written} forecasts...")
            docs_batch = []

    # final flush
    if docs_batch:
        forecast_col.insert_many(docs_batch)
        total_written += len(docs_batch)
        print(f"Wrote {total_written} forecasts (final).")

    client.close()
    
    print()
    print(f"Done. Total forecasts written: {total_written}")
    print(f"Model tag: {MODEL_TAG}")
    
    if sample_doc:
        print()
        print("Sample forecast document:")
        print(f"  productId: {sample_doc['productId']}")
        print(f"  locationId: {sample_doc['locationId']}")
        print(f"  startDate: {sample_doc['startDate']}")
        print(f"  endDate: {sample_doc['endDate']}")
        print(f"  yhat (unscaled, first 7): {[round(v, 2) for v in sample_doc['yhat'][:7]]}")
        print(f"  yhat_scaled (first 7): {[round(v, 4) for v in sample_doc['yhat_scaled'][:7]]}")


if __name__ == "__main__":
    generate_forecasts()
