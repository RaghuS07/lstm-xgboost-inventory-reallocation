const jwt = require('jsonwebtoken');
const User = require('../models/User');
const config = require('../config');

// Generate business userId: U0001, U0002, ...
async function generateUserId() {
  const count = await User.countDocuments();
  return "U" + String(count + 1).padStart(4, "0");
}

// ========================= REGISTER =========================
const register = async (req, res) => {
  try {
    console.log("[REGISTER] Incoming body:", req.body);

    const { email, password, role } = req.body;

    // Validate required fields
    if (!email || !password || !role) {
      return res.status(400).json({
        success: false,
        message: "Email, password, and role are required"
      });
    }

    // Normalize role to match enum in schema
    const roleNorm = role.toLowerCase();

    // Check if role is valid
    const validRoles = ['buyer', 'seller'];
    if (!validRoles.includes(roleNorm)) {
      return res.status(400).json({
        success: false,
        message: "Invalid role supplied"
      });
    }

    // Check if user already exists
    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: "User already exists with this email"
      });
    }

    // Generate userId like U0001
    const userId = await generateUserId();

    // Create & save user
    const user = new User({
      userId,
      email,
      passwordHash: password, // password will be hashed by pre-save hook
      role: roleNorm
    });

    await user.save();

    // Create JWT
    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      config.JWT_SECRET,
      { expiresIn: "24h" }
    );

    return res.status(201).json({
      success: true,
      message: "User registered successfully",
      data: {
        user: {
          id: user._id,
          userId: user.userId,
          email: user.email,
          role: user.role,
          createdAt: user.createdAt
        },
        token
      }
    });

  } catch (err) {
    console.error("Registration error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error during registration",
      error: err.message // helpful for debugging
    });
  }
};

// ========================= LOGIN =========================
const login = async (req, res) => {
  try {
    console.log("[LOGIN] body:", req.body);

    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required"
      });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const valid = await user.comparePassword(password);
    if (!valid) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      config.JWT_SECRET,
      { expiresIn: "24h" }
    );

    return res.json({
      success: true,
      message: "Login successful",
      data: {
        user: {
          id: user._id,
          userId: user.userId,
          email: user.email,
          role: user.role,
          createdAt: user.createdAt
        },
        token
      }
    });

  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error during login",
      error: err.message
    });
  }
};

module.exports = { register, login };
