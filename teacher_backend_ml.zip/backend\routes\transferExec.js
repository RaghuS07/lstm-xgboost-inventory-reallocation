const express = require('express');
const {
  getTransferExecs,
  getTransferExec,
  completeTransfer,
  calculateImpact
} = require('../controllers/transferExecController');
const { authenticateToken, validateApiKey, authorizeRole } = require('../middleware/auth');

const router = express.Router();

// Apply authentication and API key validation to all routes
router.use(authenticateToken);
router.use(validateApiKey);

/**
 * Transfer Execution Routes
 * 
 * GET  /api/transfer-exec           - List all transfer executions
 * GET  /api/transfer-exec/:id       - Get single execution
 * POST /api/transfer-exec/:id/complete - Complete a transfer (updates stock)
 * POST /api/transfer-exec/:id/impact   - Calculate impact after completion
 */

// List all transfer executions
router.get('/', getTransferExecs);

// Get single transfer execution
router.get('/:id', getTransferExec);

// Complete a transfer (seller/manager/admin only)
router.post('/:id/complete', 
  authorizeRole(['seller', 'manager', 'admin']), 
  completeTransfer
);

// Calculate impact (seller/manager/admin only)
router.post('/:id/impact', 
  authorizeRole(['seller', 'manager', 'admin']), 
  calculateImpact
);

module.exports = router;

