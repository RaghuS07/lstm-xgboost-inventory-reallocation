#!/usr/bin/env python3
"""
ml/evaluate_recommendations.py

Evaluate and summarize the generated recommendations.

Usage:
    python ml/evaluate_recommendations.py

Outputs:
    - Prints summary statistics
    - Saves ml/models/recommendations_summary.json
"""
import os
import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import numpy as np
from pymongo import MongoClient
from bson import ObjectId

# ---------- CONFIG ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

MODELS_DIR = Path("ml/models")
SUMMARY_FILE = MODELS_DIR / "recommendations_summary.json"


def load_products(db):
    """Load products indexed by ObjectId string."""
    products = {}
    for p in db["products"].find({}, {"_id": 1, "productId": 1, "name": 1, "category": 1}):
        products[str(p["_id"])] = {
            "productId": p.get("productId"),
            "name": p.get("name", "Unknown"),
            "category": p.get("category", "Unknown")
        }
    return products


def load_locations(db):
    """Load locations indexed by ObjectId string."""
    locations = {}
    for loc in db["locations"].find({}, {"_id": 1, "locationId": 1, "name": 1, "city": 1}):
        locations[str(loc["_id"])] = {
            "locationId": loc.get("locationId"),
            "name": loc.get("name", "Unknown"),
            "city": loc.get("city", "Unknown")
        }
    return locations


def main():
    print("=== Recommendations Evaluation ===")
    print()
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    # Load counts
    print("--- Collection Counts ---")
    candidates_total = db["transfer_candidates"].count_documents({})
    candidates_merged = db["transfer_candidates_merged"].count_documents({})
    recommendations_total = db["recommendations"].count_documents({})
    
    print(f"transfer_candidates: {candidates_total}")
    print(f"transfer_candidates_merged: {candidates_merged}")
    print(f"recommendations: {recommendations_total}")
    print()
    
    if recommendations_total == 0:
        print("No recommendations found. Run the pipeline first.")
        client.close()
        return
    
    # Load recommendations
    recommendations = list(db["recommendations"].find().sort("score", -1))
    
    # Load reference data
    products = load_products(db)
    locations = load_locations(db)
    
    # Compute statistics
    profit_estimates = [r.get("profit_est", 0) for r in recommendations]
    distances = [r.get("distance_km", 0) for r in recommendations]
    quantities = [r.get("quantity", 0) for r in recommendations]
    scores = [r.get("score", 0) for r in recommendations]
    
    # Rule distribution
    rule_counts = defaultdict(int)
    for r in recommendations:
        rules = r.get("rules_applied", ["unknown"])
        for rule in rules:
            rule_counts[rule] += 1
    
    # Priority distribution
    priority_counts = defaultdict(int)
    for r in recommendations:
        priority_counts[r.get("priority", "unknown")] += 1
    
    print("--- Summary Statistics ---")
    print(f"Total recommendations: {len(recommendations)}")
    print()
    print(f"Profit Estimate:")
    print(f"  Mean:   ${np.mean(profit_estimates):.2f}")
    print(f"  Median: ${np.median(profit_estimates):.2f}")
    print(f"  Min:    ${np.min(profit_estimates):.2f}")
    print(f"  Max:    ${np.max(profit_estimates):.2f}")
    print()
    print(f"Distance (km):")
    print(f"  Mean:   {np.mean(distances):.1f}")
    print(f"  Median: {np.median(distances):.1f}")
    print()
    print(f"Quantity:")
    print(f"  Mean:   {np.mean(quantities):.1f}")
    print(f"  Total:  {sum(quantities)}")
    print()
    print(f"Score:")
    print(f"  Mean:   {np.mean(scores):.1f}")
    print(f"  Median: {np.median(scores):.1f}")
    print()
    
    print("--- Distribution by Rule ---")
    for rule, count in sorted(rule_counts.items()):
        print(f"  {rule}: {count}")
    print()
    
    print("--- Distribution by Priority ---")
    for priority in ["high", "medium", "low", "very_low"]:
        print(f"  {priority}: {priority_counts.get(priority, 0)}")
    print()
    
    # Top 5 recommendations
    print("--- Top 5 Recommendations ---")
    for i, r in enumerate(recommendations[:5], 1):
        pid = str(r.get("productId", ""))
        from_lid = str(r.get("fromLocationId", ""))
        to_lid = str(r.get("toLocationId", ""))
        
        prod = products.get(pid, {})
        from_loc = locations.get(from_lid, {})
        to_loc = locations.get(to_lid, {})
        
        print(f"\n{i}. {prod.get('name', 'Unknown')}")
        print(f"   From: {from_loc.get('name', 'Unknown')} -> To: {to_loc.get('name', 'Unknown')}")
        print(f"   Quantity: {r.get('quantity', 0)}")
        print(f"   Profit Est: ${r.get('profit_est', 0):.2f}")
        print(f"   Transport Cost: ${r.get('transport_cost', 0):.2f}")
        print(f"   Score: {r.get('score', 0):.1f}")
        print(f"   Rules: {r.get('rules_applied', [])}")
    
    # Save summary
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "counts": {
            "transfer_candidates": candidates_total,
            "transfer_candidates_merged": candidates_merged,
            "recommendations": recommendations_total
        },
        "statistics": {
            "profit_est": {
                "mean": float(np.mean(profit_estimates)),
                "median": float(np.median(profit_estimates)),
                "min": float(np.min(profit_estimates)),
                "max": float(np.max(profit_estimates))
            },
            "distance_km": {
                "mean": float(np.mean(distances)),
                "median": float(np.median(distances))
            },
            "quantity": {
                "mean": float(np.mean(quantities)),
                "total": int(sum(quantities))
            },
            "score": {
                "mean": float(np.mean(scores)),
                "median": float(np.median(scores))
            }
        },
        "distribution": {
            "by_rule": dict(rule_counts),
            "by_priority": dict(priority_counts)
        }
    }
    
    with open(SUMMARY_FILE, "w") as f:
        json.dump(summary, f, indent=2)
    
    print(f"\nSaved summary to {SUMMARY_FILE}")
    
    client.close()
    print("\nDone.")


if __name__ == "__main__":
    main()

