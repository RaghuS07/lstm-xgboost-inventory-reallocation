const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  fromLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  toLocationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'very_low'],
    default: 'medium'
  },
  approved: {
    type: Boolean,
    default: false
  },
  approvedAt: {
    type: Date
  },
  // Additional fields from ML pipeline
  distance_km: {
    type: Number
  },
  revenue_est: {
    type: Number
  },
  transport_cost: {
    type: Number
  },
  profit_est: {
    type: Number
  },
  score: {
    type: Number
  },
  rules_applied: [{
    type: String
  }],
  modelTag: {
    type: String
  },
  candidate_id: {
    type: mongoose.Schema.Types.ObjectId
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Recommendation', recommendationSchema);
