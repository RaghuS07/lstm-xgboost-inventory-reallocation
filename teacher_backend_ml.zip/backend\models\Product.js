// models/Product.js
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  productId: {                       // Optional - for backward compatibility with existing data
    type: String,
    required: false,
    unique: false,  // Allow duplicates if not set
    sparse: true,   // Only enforce uniqueness when field exists
    trim: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  category: {
    type: String,
    required: true,
    trim: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  description: {
    type: String,
    trim: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

productSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Product', productSchema);
