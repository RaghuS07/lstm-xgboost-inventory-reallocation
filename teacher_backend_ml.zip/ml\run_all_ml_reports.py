#!/usr/bin/env python3
"""
Generate all ML outputs for the project: metrics ("accuracy") + graphs for:
  - LSTM demand forecasting (from `forecast` collection)
  - XGBoost transfer profitability scoring (from transfer candidates)
  - Recommendation distribution / ranking diagnostics

Outputs are saved to:
  ml/models/reports/<timestamp>/

Optional end-to-end pipeline (rebuild data/models):
  --run-pipeline  runs:
    extract_training_data.py -> train_lstm.py -> run_lstm_forecast.py
    generate_transfer_candidates.py -> merge_candidates.py
    train_transfer_xgb.py -> run_transfer_xgb.py
    evaluate_forecasts.py -> evaluate_recommendations.py

Notes on "accuracy":
  - Forecasting is regression; we report MAE/RMSE/MAPE and two intuitive accuracies:
      ACC_±1 = fraction where |error| <= 1 unit
      ACC_±20% = fraction where |error| <= max(1, 0.2 * actual)
  - XGB scoring is regression; we report MAE/RMSE/R2 on a *heuristic* profit target
    consistent with the training pipeline, plus ranking metrics NDCG@K and Spearman.
"""

from __future__ import annotations

import os
import json
import math
import argparse
import subprocess
from pathlib import Path
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pymongo import MongoClient
from bson import ObjectId
from dateutil import parser as dateparser
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

try:
    import xgboost as xgb
except Exception:
    xgb = None


# -------------------- Config --------------------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

FORECAST_MODEL_TAG = os.getenv("FORECAST_MODEL_TAG", "lstm_v1_unscaled")
EXPECTED_SELLTHROUGH = float(os.getenv("EXPECTED_SELLTHROUGH", "0.8"))
COST_PER_KM = float(os.getenv("COST_PER_KM", "0.1"))

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = PROJECT_ROOT / "ml" / "models"
REPORTS_DIR = MODELS_DIR / "reports"


# -------------------- Small helpers --------------------
def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_now_iso() -> str:
    return utc_now().isoformat()


def mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def save_json(path: Path, obj: Any) -> None:
    mkdir(path.parent)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def run_step(cmd: List[str]) -> None:
    print(f"\n[run] {' '.join(cmd)}")
    subprocess.check_call(cmd, cwd=str(PROJECT_ROOT))


def safe_mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    mask = y_true != 0
    if not mask.any():
        return float("nan")
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])))


def acc_within_abs(y_true: np.ndarray, y_pred: np.ndarray, tol_abs: float) -> float:
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    if len(y_true) == 0:
        return float("nan")
    return float(np.mean(np.abs(y_pred - y_true) <= tol_abs))


def acc_within_pct(y_true: np.ndarray, y_pred: np.ndarray, pct: float, min_abs: float = 1.0) -> float:
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    if len(y_true) == 0:
        return float("nan")
    tol = np.maximum(min_abs, np.abs(y_true) * pct)
    return float(np.mean(np.abs(y_pred - y_true) <= tol))


def ndcg_at_k(y_true: np.ndarray, y_score: np.ndarray, k: int = 10) -> float:
    """
    NDCG@K with non-negative relevance.
    If y_true contains negatives, shift it to be >= 0.
    """
    y_true = np.array(y_true, dtype=float)
    y_score = np.array(y_score, dtype=float)
    if len(y_true) == 0:
        return float("nan")

    rel = y_true.copy()
    min_rel = float(np.nanmin(rel))
    if math.isfinite(min_rel) and min_rel < 0:
        rel = rel - min_rel

    order = np.argsort(-y_score)[: min(k, len(y_score))]
    rel_sorted = rel[order]

    # Use linear gain (rel) to avoid numerical overflow for large relevance values.
    discounts = 1.0 / np.log2(np.arange(2, len(rel_sorted) + 2))
    dcg = float(np.sum(rel_sorted * discounts))

    ideal = np.sort(rel)[::-1][: len(rel_sorted)]
    idcg = float(np.sum(ideal * discounts))
    return float(dcg / idcg) if idcg > 0 else float("nan")


def spearman_corr(a: np.ndarray, b: np.ndarray) -> float:
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    if len(a) < 2:
        return float("nan")
    ra = pd.Series(a).rank(method="average").to_numpy()
    rb = pd.Series(b).rank(method="average").to_numpy()
    return float(np.corrcoef(ra, rb)[0, 1])


def precision_at_k(y_true: np.ndarray, y_score: np.ndarray, k: int = 10) -> float:
    """
    Precision@K defined as overlap between top-K predicted and top-K true indices.
    """
    n = len(y_true)
    if n == 0:
        return float("nan")
    k = min(k, n)
    top_true = set(np.argsort(-y_true)[:k].tolist())
    top_pred = set(np.argsort(-y_score)[:k].tolist())
    return float(len(top_true & top_pred) / k) if k > 0 else float("nan")


# -------------------- Mongo helpers --------------------
def mongo() -> Tuple[MongoClient, Any]:
    client = MongoClient(MONGO_URI)
    return client, client[DB_NAME]


def build_id_resolution_maps(db) -> Tuple[Dict[str, ObjectId], Dict[str, ObjectId]]:
    """
    Map business ids (Product.productId / Location.locationId) to ObjectId.
    Used when forecasts were written with business ids rather than ObjectIds.
    """
    prod_map: Dict[str, ObjectId] = {}
    loc_map: Dict[str, ObjectId] = {}

    for p in db["products"].find({}, {"_id": 1, "productId": 1}):
        if p.get("productId"):
            prod_map[str(p["productId"])] = p["_id"]
    for l in db["locations"].find({}, {"_id": 1, "locationId": 1}):
        if l.get("locationId"):
            loc_map[str(l["locationId"])] = l["_id"]
    return prod_map, loc_map


def resolve_mongo_id(maybe_id: Any, biz_map: Dict[str, ObjectId]) -> Optional[ObjectId]:
    """
    Resolve either:
      - ObjectId already
      - string ObjectId hex
      - business id via map
    """
    if isinstance(maybe_id, ObjectId):
        return maybe_id
    if isinstance(maybe_id, str):
        if ObjectId.is_valid(maybe_id):
            return ObjectId(maybe_id)
        if maybe_id in biz_map:
            return biz_map[maybe_id]
    return None


def fetch_actual_series(db, pid: Any, lid: Any, start_date_str: str, end_date_str: str, horizon: int,
                        prod_biz_map: Dict[str, ObjectId], loc_biz_map: Dict[str, ObjectId]) -> Optional[np.ndarray]:
    """
    Return an array of length == horizon with daily sum of purchased quantity from orders,
    aligned to dates [start_date .. start_date+horizon-1].
    """
    pid_oid = resolve_mongo_id(pid, prod_biz_map)
    lid_oid = resolve_mongo_id(lid, loc_biz_map)
    if pid_oid is None or lid_oid is None:
        return None

    start_date = dateparser.parse(start_date_str).date()
    end_date = dateparser.parse(end_date_str).date()

    dt_start = datetime.combine(start_date, datetime.min.time()).replace(tzinfo=timezone.utc)
    dt_end_excl = (datetime.combine(end_date, datetime.min.time()) + timedelta(days=1)).replace(tzinfo=timezone.utc)

    q = {
        "status": "purchased",
        "timestamp": {"$gte": dt_start, "$lt": dt_end_excl},
        "productId": pid_oid,
        "locationId": lid_oid,
    }

    pipeline = [
        {"$match": q},
        {"$group": {"_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}}, "units": {"$sum": "$quantity"}}},
        {"$sort": {"_id": 1}},
    ]
    res = list(db["orders"].aggregate(pipeline))
    date_to_units = {r["_id"]: float(r["units"]) for r in res}

    arr = []
    cur = start_date
    for _ in range(horizon):
        key = cur.strftime("%Y-%m-%d")
        arr.append(float(date_to_units.get(key, 0.0)))
        cur = cur + timedelta(days=1)
    return np.array(arr, dtype=float)


# -------------------- LSTM forecast evaluation + plots --------------------
def evaluate_forecasts_with_plots(
    db,
    out_dir: Path,
    model_tag: Optional[str],
    limit_forecasts: Optional[int],
    sample_series_plots: int = 6,
) -> Dict[str, Any]:
    mkdir(out_dir)

    prod_biz_map, loc_biz_map = build_id_resolution_maps(db)

    q = {"modelTag": model_tag} if model_tag else {}
    cursor = db["forecast"].find(
        q,
        {
            "productId": 1,
            "locationId": 1,
            "startDate": 1,
            "endDate": 1,
            "horizonDays": 1,
            "yhat": 1,
            "modelTag": 1,
        },
    )
    forecasts = list(cursor)
    if limit_forecasts is not None:
        forecasts = forecasts[:limit_forecasts]

    if not forecasts:
        return {"modelTag": model_tag, "error": "No forecasts found", "generated_at": utc_now_iso()}

    per_doc: List[Dict[str, Any]] = []
    overall_true: List[float] = []
    overall_pred: List[float] = []
    per_h_step_abs_err: List[np.ndarray] = []

    series_examples: List[Dict[str, Any]] = []

    ok = 0
    for doc in forecasts:
        pid = doc.get("productId")
        lid = doc.get("locationId")
        yhat = doc.get("yhat") or []
        horizon = int(doc.get("horizonDays") or len(yhat) or 0)
        if horizon <= 0:
            continue
        if len(yhat) != horizon:
            horizon = min(horizon, len(yhat))
            yhat = yhat[:horizon]

        actual = fetch_actual_series(
            db=db,
            pid=pid,
            lid=lid,
            start_date_str=doc.get("startDate"),
            end_date_str=doc.get("endDate"),
            horizon=horizon,
            prod_biz_map=prod_biz_map,
            loc_biz_map=loc_biz_map,
        )
        if actual is None:
            continue

        yhat_np = np.array(yhat, dtype=float)
        if len(actual) != len(yhat_np):
            L = min(len(actual), len(yhat_np))
            actual = actual[:L]
            yhat_np = yhat_np[:L]

        ae = np.abs(actual - yhat_np)
        per_h_step_abs_err.append(ae)

        mae = float(mean_absolute_error(actual, yhat_np))
        rmse = float(np.sqrt(mean_squared_error(actual, yhat_np)))
        mape = safe_mape(actual, yhat_np)

        per_doc.append(
            {
                "forecast_id": str(doc.get("_id")),
                "productId": str(pid),
                "locationId": str(lid),
                "modelTag": doc.get("modelTag"),
                "startDate": doc.get("startDate"),
                "endDate": doc.get("endDate"),
                "horizon": int(len(yhat_np)),
                "metrics": {"mae": mae, "rmse": rmse, "mape": mape},
                "yhat": yhat_np.tolist(),
                "actual": actual.tolist(),
            }
        )

        overall_true.extend(actual.tolist())
        overall_pred.extend(yhat_np.tolist())
        ok += 1

        # capture a few series for plots (first N)
        if len(series_examples) < sample_series_plots:
            series_examples.append(
                {
                    "label": f"{str(pid)} @ {str(lid)}",
                    "yhat": yhat_np.tolist(),
                    "actual": actual.tolist(),
                    "startDate": doc.get("startDate"),
                }
            )

    overall_true_np = np.array(overall_true, dtype=float)
    overall_pred_np = np.array(overall_pred, dtype=float)
    zero_rate = float(np.mean(overall_true_np == 0.0)) if ok else float("nan")
    nonzero_mask = overall_true_np != 0.0
    mape_nonzero = safe_mape(overall_true_np, overall_pred_np) if ok else float("nan")
    wmape = (
        float(np.sum(np.abs(overall_true_np - overall_pred_np)) / np.sum(np.abs(overall_true_np)))
        if ok and float(np.sum(np.abs(overall_true_np))) > 0
        else float("nan")
    )

    summary = {
        "modelTag": model_tag,
        "forecasts_seen": len(forecasts),
        "forecasts_evaluated": ok,
        "overall": {
            "mae": float(mean_absolute_error(overall_true_np, overall_pred_np)) if ok else float("nan"),
            "rmse": float(np.sqrt(mean_squared_error(overall_true_np, overall_pred_np))) if ok else float("nan"),
            "mape": mape_nonzero,  # defined only over non-zero actuals
            "wmape": wmape,
            "zero_actual_rate": zero_rate,
            "acc_abs_1": acc_within_abs(overall_true_np, overall_pred_np, 1.0) if ok else float("nan"),
            "acc_pct_20": acc_within_pct(overall_true_np, overall_pred_np, 0.20, min_abs=1.0) if ok else float("nan"),
        },
        "generated_at": utc_now_iso(),
    }

    save_json(out_dir / "lstm_forecast_report.json", {"summary": summary, "per_forecast_sample": per_doc[:2000]})

    # ---- Plots ----
    sns.set_theme(style="whitegrid")

    # 1) True vs Pred scatter
    plt.figure(figsize=(7, 6))
    n = len(overall_true_np)
    if n > 12000:
        idx = np.random.choice(n, 12000, replace=False)
        x = overall_true_np[idx]
        y = overall_pred_np[idx]
    else:
        x, y = overall_true_np, overall_pred_np

    plt.scatter(x, y, s=8, alpha=0.25)
    lim = float(max(1.0, np.nanpercentile(np.concatenate([x, y]), 99))) if len(x) else 1.0
    plt.plot([0, lim], [0, lim], color="black", linewidth=1)
    plt.xlim(0, lim)
    plt.ylim(0, lim)
    plt.title(f"LSTM forecasts: actual vs predicted ({model_tag})")
    plt.xlabel("Actual units sold")
    plt.ylabel("Predicted units sold")
    plt.tight_layout()
    plt.savefig(out_dir / "lstm_actual_vs_pred.png", dpi=170)
    plt.close()

    # 2) Residual histogram
    resid = overall_pred_np - overall_true_np
    plt.figure(figsize=(7, 4))
    sns.histplot(resid, bins=60, kde=True)
    plt.title(f"LSTM residuals (pred - actual) ({model_tag})")
    plt.xlabel("Residual")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(out_dir / "lstm_residuals_hist.png", dpi=170)
    plt.close()

    # 3) MAE by horizon step
    if per_h_step_abs_err:
        max_h = max(len(a) for a in per_h_step_abs_err)
        step_mae = []
        for i in range(max_h):
            vals = [a[i] for a in per_h_step_abs_err if len(a) > i]
            step_mae.append(float(np.mean(vals)) if vals else float("nan"))

        plt.figure(figsize=(7, 4))
        plt.plot(range(1, max_h + 1), step_mae, marker="o")
        plt.title(f"LSTM MAE by horizon step ({model_tag})")
        plt.xlabel("Horizon day")
        plt.ylabel("MAE")
        plt.tight_layout()
        plt.savefig(out_dir / "lstm_mae_by_horizon.png", dpi=170)
        plt.close()

    # 4) Example forecast series
    if series_examples:
        cols = 2
        rows = int(math.ceil(len(series_examples) / cols))
        plt.figure(figsize=(10, 3.2 * rows))
        for i, ex in enumerate(series_examples, 1):
            ax = plt.subplot(rows, cols, i)
            xs = np.arange(1, len(ex["yhat"]) + 1)
            ax.plot(xs, ex["actual"], label="actual", marker="o")
            ax.plot(xs, ex["yhat"], label="pred", marker="o")
            ax.set_title(ex["label"])
            ax.set_xlabel("Horizon day")
            ax.set_ylabel("Units")
            ax.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "lstm_sample_series.png", dpi=170)
        plt.close()

    return summary


# -------------------- XGBoost evaluation + plots --------------------
def load_products_locations(db) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    products = {}
    for p in db["products"].find({}, {"_id": 1, "price": 1, "category": 1}):
        products[str(p["_id"])] = {"price": float(p.get("price", 0.0)), "category": str(p.get("category", "Unknown"))}

    locations = {}
    for loc in db["locations"].find({}, {"_id": 1, "tier": 1}):
        locations[str(loc["_id"])] = {"tier": str(loc.get("tier", "unknown"))}
    return products, locations


def build_xgb_dataset_from_candidates(
    db,
    cost_per_km: float = COST_PER_KM,
    expected_sellthrough: float = EXPECTED_SELLTHROUGH,
) -> Tuple[pd.DataFrame, pd.Series]:
    # Prefer merged candidates
    candidates = list(db["transfer_candidates_merged"].find({}))
    if not candidates:
        candidates = list(db["transfer_candidates"].find({}))

    products, locations = load_products_locations(db)

    rows = []
    for c in candidates:
        pid = str(c.get("productId", ""))
        from_lid = str(c.get("fromLocationId", ""))
        to_lid = str(c.get("toLocationId", ""))

        quantity = float(c.get("quantity", 0) or 0)
        distance_km = float(c.get("distance_km", 0) or 0)
        stock_source = float(c.get("stock_source", 0) or 0)
        stock_target = float(c.get("stock_target", 0) or 0)
        forecast_source = float(c.get("forecast_source") or 0)
        forecast_target = float(c.get("forecast_target") or 0)
        sales_rate_source = float(c.get("sales_rate_source", 0) or 0)
        sales_rate_target = float(c.get("sales_rate_target", 0) or 0)

        prod = products.get(pid, {})
        from_loc = locations.get(from_lid, {})
        to_loc = locations.get(to_lid, {})

        product_price = float(prod.get("price", 0.0))
        category = str(prod.get("category", "Unknown"))
        from_tier = str(from_loc.get("tier", "unknown"))
        to_tier = str(to_loc.get("tier", "unknown"))

        rules = c.get("rules_applied") or [c.get("rule", "unknown")]
        is_forecast_rule = 1 if any("forecast" in str(r) for r in rules) else 0
        is_demand_rule = 1 if any("demand_vs_stock" in str(r) for r in rules) else 0

        stock_to_sales_source = stock_source / sales_rate_source if sales_rate_source > 0 else 999.0
        stock_to_sales_target = stock_target / sales_rate_target if sales_rate_target > 0 else 999.0

        # Heuristic target (aligned with ml/train_transfer_xgb.py behavior when no impacts)
        revenue_est = quantity * product_price * expected_sellthrough
        transport_cost = distance_km * cost_per_km
        target_profit = revenue_est - transport_cost

        rows.append(
            dict(
                quantity=quantity,
                distance_km=distance_km,
                stock_source=stock_source,
                stock_target=stock_target,
                forecast_source=forecast_source,
                forecast_target=forecast_target,
                sales_rate_source=sales_rate_source,
                sales_rate_target=sales_rate_target,
                stock_to_sales_source=min(stock_to_sales_source, 999.0),
                stock_to_sales_target=min(stock_to_sales_target, 999.0),
                product_price=product_price,
                category=category,
                from_tier=from_tier,
                to_tier=to_tier,
                is_forecast_rule=is_forecast_rule,
                is_demand_rule=is_demand_rule,
                target_profit=target_profit,
            )
        )

    df = pd.DataFrame(rows)
    if df.empty:
        return df, pd.Series([], dtype=float)

    # Keep raw categoricals for now; encoding is handled in evaluate_xgb_with_plots()
    # using the saved LabelEncoder classes from ml/models/xgb_features.json.
    feature_cols = [
        "quantity",
        "distance_km",
        "stock_source",
        "stock_target",
        "forecast_source",
        "forecast_target",
        "sales_rate_source",
        "sales_rate_target",
        "stock_to_sales_source",
        "stock_to_sales_target",
        "product_price",
        "category",
        "is_forecast_rule",
        "is_demand_rule",
        "from_tier",
        "to_tier",
    ]
    X = df[feature_cols].copy()
    y = df["target_profit"].astype(float).copy()
    return X, y


def evaluate_xgb_with_plots(
    db,
    out_dir: Path,
    train_if_missing: bool,
    sample_points: int = 15000,
) -> Dict[str, Any]:
    mkdir(out_dir)

    if xgb is None:
        raise RuntimeError("xgboost is not installed. Install via: python -m pip install xgboost")

    model_path = MODELS_DIR / "xgb_transfer.json"
    features_path = MODELS_DIR / "xgb_features.json"

    X_raw, y = build_xgb_dataset_from_candidates(db)
    if X_raw.empty:
        return {"error": "No transfer candidates found", "generated_at": utc_now_iso()}

    model = xgb.XGBRegressor()
    loaded = False
    if model_path.exists():
        try:
            model.load_model(str(model_path))
            loaded = True
        except Exception:
            loaded = False

    # Build the exact feature matrix expected by the trained model (including encoded categoricals)
    meta: Dict[str, Any] = {}
    if features_path.exists():
        with open(features_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

    expected_features = meta.get("features") or []
    encoder_classes = meta.get("label_encoders") or {}

    def _safe_encode(value: Any, classes: List[str]) -> int:
        s = str(value)
        try:
            return int(classes.index(s))
        except ValueError:
            return 0

    X_use = X_raw.copy()
    # Add encoded columns if model expects them
    if "category_encoded" in expected_features:
        X_use["category_encoded"] = X_use["category"].apply(lambda v: _safe_encode(v, encoder_classes.get("category", [])))
    if "from_tier_encoded" in expected_features:
        X_use["from_tier_encoded"] = X_use["from_tier"].apply(lambda v: _safe_encode(v, encoder_classes.get("from_tier", [])))
    if "to_tier_encoded" in expected_features:
        X_use["to_tier_encoded"] = X_use["to_tier"].apply(lambda v: _safe_encode(v, encoder_classes.get("to_tier", [])))

    # Drop raw categorical columns if the trained model doesn't include them
    drop_cols = []
    for raw_col in ["category", "from_tier", "to_tier"]:
        if raw_col not in expected_features and raw_col in X_use.columns:
            drop_cols.append(raw_col)
    if drop_cols:
        X_use = X_use.drop(columns=drop_cols)

    # Finally, align to the saved feature list if present
    if expected_features:
        missing = [c for c in expected_features if c not in X_use.columns]
        if missing:
            # If we can't align, fall back to training a quick model for reporting
            if not train_if_missing:
                return {
                    "error": f"Feature alignment failed; missing columns: {missing}. Re-run with --train-xgb-if-missing",
                    "generated_at": utc_now_iso(),
                }
        else:
            X_use = X_use[expected_features].copy()

    if not loaded:
        if not train_if_missing:
            return {
                "error": "XGB model not found. Re-run with --run-pipeline or --train-xgb-if-missing",
                "generated_at": utc_now_iso(),
            }
        # quick local fit just for report (heuristic target)
        X_train, X_val, y_train, y_val = train_test_split(X_use, y, test_size=0.2, random_state=42)
        model = xgb.XGBRegressor(
            n_estimators=250,
            max_depth=6,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1,
        )
        model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)

    y_pred = model.predict(X_use)

    metrics = {
        "mae": float(mean_absolute_error(y, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y, y_pred))),
        "r2": float(r2_score(y, y_pred)),
        "ndcg@10": ndcg_at_k(y.to_numpy(), y_pred, k=10),
        "ndcg@25": ndcg_at_k(y.to_numpy(), y_pred, k=25),
        "precision@10": precision_at_k(y.to_numpy(), y_pred, k=10),
        "precision@25": precision_at_k(y.to_numpy(), y_pred, k=25),
        "spearman": spearman_corr(y.to_numpy(), y_pred),
    }

    feature_importance_top = None
    try:
        importances = model.feature_importances_
        feat_names = list(X_use.columns)
        pairs = sorted(zip(feat_names, [float(x) for x in importances]), key=lambda t: -t[1])
        feature_importance_top = pairs[:10]
    except Exception:
        feature_importance_top = None

    report = {
        "target_definition": "heuristic_profit = quantity * product_price * expected_sellthrough - distance_km * cost_per_km",
        "expected_sellthrough": EXPECTED_SELLTHROUGH,
        "cost_per_km": COST_PER_KM,
        "samples": int(len(X_use)),
        "metrics": metrics,
        "feature_importance_top10": feature_importance_top,
        "generated_at": utc_now_iso(),
    }
    save_json(out_dir / "xgb_transfer_report.json", report)

    sns.set_theme(style="whitegrid")

    # Pred vs target scatter (sample)
    n = len(y)
    if n > sample_points:
        idx = np.random.choice(n, sample_points, replace=False)
        yt = y.to_numpy()[idx]
        yp = y_pred[idx]
    else:
        yt = y.to_numpy()
        yp = y_pred

    plt.figure(figsize=(7, 6))
    plt.scatter(yt, yp, s=8, alpha=0.25)
    lo = float(np.nanpercentile(np.concatenate([yt, yp]), 1))
    hi = float(np.nanpercentile(np.concatenate([yt, yp]), 99))
    plt.plot([lo, hi], [lo, hi], color="black", linewidth=1)
    plt.title("XGBoost: target profit vs predicted profit")
    plt.xlabel("Target profit (heuristic)")
    plt.ylabel("Predicted profit")
    plt.tight_layout()
    plt.savefig(out_dir / "xgb_target_vs_pred.png", dpi=170)
    plt.close()

    # Residuals
    resid = y_pred - y.to_numpy()
    plt.figure(figsize=(7, 4))
    sns.histplot(resid, bins=60, kde=True)
    plt.title("XGBoost residuals (pred - target)")
    plt.xlabel("Residual")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(out_dir / "xgb_residuals_hist.png", dpi=170)
    plt.close()

    # Feature importance (if available)
    try:
        importances = model.feature_importances_
        feat_names = list(X_use.columns)
        imp_df = (
            pd.DataFrame({"feature": feat_names, "importance": importances})
            .sort_values("importance", ascending=False)
            .head(15)
        )
        plt.figure(figsize=(8, 5))
        sns.barplot(data=imp_df, x="importance", y="feature")
        plt.title("XGBoost feature importance (top 15)")
        plt.tight_layout()
        plt.savefig(out_dir / "xgb_feature_importance.png", dpi=170)
        plt.close()
    except Exception:
        pass

    return report


# -------------------- Recommendation distribution plots --------------------
def recommendations_report(db, out_dir: Path, limit: int = 50000) -> Dict[str, Any]:
    mkdir(out_dir)

    recs = list(
        db["recommendations"]
        .find({}, {"priority": 1, "score": 1, "profit_est": 1, "quantity": 1, "distance_km": 1, "modelTag": 1, "createdAt": 1})
        .limit(limit)
    )
    if not recs:
        return {"error": "No recommendations found", "generated_at": utc_now_iso()}

    df = pd.DataFrame(recs)
    for col in ["score", "profit_est", "quantity", "distance_km"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    by_priority = (
        df["priority"].fillna("unknown").astype(str).value_counts().to_dict()
        if "priority" in df.columns
        else {}
    )

    summary = {
        "count": int(len(df)),
        "by_priority": by_priority,
        "score": {
            "mean": float(df["score"].mean()) if "score" in df.columns else None,
            "p50": float(df["score"].median()) if "score" in df.columns else None,
        },
        "profit_est": {
            "mean": float(df["profit_est"].mean()) if "profit_est" in df.columns else None,
            "p50": float(df["profit_est"].median()) if "profit_est" in df.columns else None,
        },
        "generated_at": utc_now_iso(),
    }
    save_json(out_dir / "recommendations_report.json", summary)

    sns.set_theme(style="whitegrid")

    if "priority" in df.columns:
        plt.figure(figsize=(6, 4))
        order = ["high", "medium", "low", "very_low", "unknown"]
        counts = df["priority"].fillna("unknown").astype(str).value_counts()
        plot_df = pd.DataFrame({"priority": counts.index, "count": counts.values})
        plot_df["priority"] = pd.Categorical(plot_df["priority"], categories=order, ordered=True)
        plot_df = plot_df.sort_values("priority")
        sns.barplot(data=plot_df, x="priority", y="count")
        plt.title("Recommendations by priority")
        plt.tight_layout()
        plt.savefig(out_dir / "recs_by_priority.png", dpi=170)
        plt.close()

    if "score" in df.columns:
        plt.figure(figsize=(7, 4))
        sns.histplot(df["score"].dropna(), bins=60, kde=True)
        plt.title("Recommendation score distribution")
        plt.tight_layout()
        plt.savefig(out_dir / "recs_score_hist.png", dpi=170)
        plt.close()

    if "profit_est" in df.columns:
        plt.figure(figsize=(7, 4))
        sns.histplot(df["profit_est"].dropna(), bins=60, kde=True)
        plt.title("Recommendation profit_est distribution")
        plt.tight_layout()
        plt.savefig(out_dir / "recs_profit_hist.png", dpi=170)
        plt.close()

    return summary


# -------------------- Pipeline runner --------------------
def run_pipeline_steps(run_pipeline: bool) -> None:
    if not run_pipeline:
        return
    run_step(["python", "ml/extract_training_data.py"])
    run_step(["python", "ml/train_lstm.py"])
    run_step(["python", "ml/run_lstm_forecast.py"])
    run_step(["python", "ml/generate_transfer_candidates.py"])
    run_step(["python", "ml/merge_candidates.py"])
    run_step(["python", "ml/train_transfer_xgb.py"])
    run_step(["python", "ml/run_transfer_xgb.py"])
    run_step(["python", "ml/evaluate_forecasts.py"])
    run_step(["python", "ml/evaluate_recommendations.py"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-pipeline", action="store_true", help="Run existing ml/*.py pipeline scripts before reporting")
    ap.add_argument("--forecast-model-tag", default=FORECAST_MODEL_TAG)
    ap.add_argument("--limit-forecasts", type=int, default=None, help="Limit number of forecast docs evaluated")
    ap.add_argument("--train-xgb-if-missing", action="store_true", help="Train a quick XGB model if xgb_transfer.json is missing")
    args = ap.parse_args()

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = REPORTS_DIR / ts
    mkdir(out_dir)

    print(f"[info] Mongo: {MONGO_URI}  DB: {DB_NAME}")
    print(f"[info] Forecast modelTag: {args.forecast_model_tag}")
    print(f"[info] Reports dir: {out_dir}")

    run_pipeline_steps(args.run_pipeline)

    client, db = mongo()
    try:
        lstm_summary = evaluate_forecasts_with_plots(
            db=db,
            out_dir=out_dir,
            model_tag=args.forecast_model_tag,
            limit_forecasts=args.limit_forecasts,
        )
        xgb_report = evaluate_xgb_with_plots(
            db=db,
            out_dir=out_dir,
            train_if_missing=args.train_xgb_if_missing,
        )
        recs_report = recommendations_report(db=db, out_dir=out_dir)

        final = {
            "generated_at": utc_now_iso(),
            "reports_dir": str(out_dir),
            "lstm": lstm_summary,
            "xgb": xgb_report,
            "recommendations": recs_report,
            "files": sorted([p.name for p in out_dir.glob("*")]),
        }
        save_json(out_dir / "RUN_SUMMARY.json", final)

        print("\n[done] Generated files:")
        for name in final["files"]:
            print(f"  - {name}")
        print("\nOpen:", out_dir)
    finally:
        client.close()


if __name__ == "__main__":
    main()


