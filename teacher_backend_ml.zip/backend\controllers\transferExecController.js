const mongoose = require('mongoose');
const TransferExec = require('../models/TransferExec');
const TransferImpact = require('../models/TransferImpact');
const Recommendation = require('../models/Recommendation');
const Stock = require('../models/Stock');
const Product = require('../models/Product');
const Location = require('../models/Location');
const Order = require('../models/Order');

// Constants
const COST_PER_KM = 0.1;
const IMPACT_WINDOW_DAYS = 14;

/**
 * Get all transfer executions
 */
const getTransferExecs = async (req, res) => {
  try {
    const { status, limit = 100 } = req.query;
    
    const query = {};
    if (status) {
      query.status = status;
    }
    
    const executions = await TransferExec.find(query)
      .populate('productId', 'name category price productId')
      .populate('fromLocationId', 'name city locationId')
      .populate('toLocationId', 'name city locationId')
      .populate('approvedBy', 'email')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));
    
    res.json({
      success: true,
      data: executions,
      count: executions.length
    });
  } catch (error) {
    console.error('Get transfer execs error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch transfer executions'
    });
  }
};

/**
 * Get single transfer execution by ID
 */
const getTransferExec = async (req, res) => {
  try {
    const { id } = req.params;
    
    const exec = await TransferExec.findById(id)
      .populate('productId', 'name category price productId')
      .populate('fromLocationId', 'name city locationId latitude longitude')
      .populate('toLocationId', 'name city locationId latitude longitude')
      .populate('approvedBy', 'email');
    
    if (!exec) {
      return res.status(404).json({
        success: false,
        message: 'Transfer execution not found'
      });
    }
    
    res.json({
      success: true,
      data: exec
    });
  } catch (error) {
    console.error('Get transfer exec error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch transfer execution'
    });
  }
};

/**
 * Create transfer execution from recommendation payload
 * This function accepts the payload directly and creates the execution
 */
function isMongoTxNotSupported(err) {
  const msg = String((err && err.message) || '');
  return (
    /Transaction numbers are only allowed/i.test(msg) ||
    /replica set member or mongos/i.test(msg) ||
    /transactions?.*only allowed.*replica set/i.test(msg)
  );
}

async function createFromRecommendationNoTx(req, res) {
  try {
    const { id } = req.params;
    const { productId, fromLocationId, toLocationId, quantity } = req.body || {};

    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid recommendation ID format' });
    }

    const recommendation = await Recommendation.findById(id);
    if (!recommendation) {
      return res.status(404).json({ success: false, message: 'Recommendation not found' });
    }
    if (recommendation.approved) {
      return res.status(400).json({ success: false, message: 'Recommendation already approved' });
    }

    const finalProductId = (productId ?? recommendation.productId);
    const finalFromLocId = (fromLocationId ?? recommendation.fromLocationId);
    const finalToLocId = (toLocationId ?? recommendation.toLocationId);
    const finalQty = (quantity ?? recommendation.quantity);

    if (!finalProductId || !finalFromLocId || !finalToLocId || finalQty == null) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: productId, fromLocationId, toLocationId, quantity'
      });
    }
    if (!Number.isFinite(Number(finalQty)) || Number(finalQty) < 1) {
      return res.status(400).json({
        success: false,
        message: 'Invalid quantity. Must be an integer >= 1'
      });
    }

    if (
      !mongoose.Types.ObjectId.isValid(finalProductId) ||
      !mongoose.Types.ObjectId.isValid(finalFromLocId) ||
      !mongoose.Types.ObjectId.isValid(finalToLocId)
    ) {
      return res.status(400).json({ success: false, message: 'Invalid ObjectId format in payload' });
    }

    const userId = req.user.id || req.user._id;

    const sourceStock = await Stock.findOne({
      productId: finalProductId,
      locationId: finalFromLocId
    });

    if (!sourceStock || sourceStock.quantity < finalQty) {
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source location. Available: ${sourceStock?.quantity || 0}, Required: ${finalQty}`
      });
    }

    let distanceKm = recommendation.distance_km || 0;
    if (!distanceKm) {
      const fromLoc = await Location.findById(finalFromLocId).lean();
      const toLoc = await Location.findById(finalToLocId).lean();
      if (fromLoc && toLoc && fromLoc.latitude && toLoc.latitude) {
        distanceKm = haversineKm(
          fromLoc.latitude,
          fromLoc.longitude,
          toLoc.latitude,
          toLoc.longitude
        );
      }
    }

    const execId = await TransferExec.generateExecId();

    const transferExec = new TransferExec({
      execId,
      recommendationId: recommendation._id,
      candidateId: recommendation.candidate_id,
      productId: finalProductId,
      fromLocationId: finalFromLocId,
      toLocationId: finalToLocId,
      quantity: Number(finalQty),
      status: 'completed',
      approvedAt: new Date(),
      approvedBy: userId || null,
      estimatedCost: distanceKm * COST_PER_KM,
      distanceKm,
      completedAt: new Date()
    });

    // Immediately execute stock move (no-tx best effort)
    const src = await Stock.findOne({ productId: finalProductId, locationId: finalFromLocId });
    if (!src || src.quantity < finalQty) {
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source location. Available: ${src?.quantity || 0}, Required: ${finalQty}`
      });
    }
    const dst = await Stock.findOne({ productId: finalProductId, locationId: finalToLocId });

    const fromBefore = Number(src.quantity) || 0;
    const toBefore = Number(dst?.quantity || 0) || 0;

    src.quantity -= Number(finalQty);
    await src.save();
    if (dst) {
      dst.quantity += Number(finalQty);
      await dst.save();
    } else {
      await new Stock({
        productId: finalProductId,
        locationId: finalToLocId,
        quantity: Number(finalQty)
      }).save();
    }

    // Store before/after snapshots for UI
    transferExec.fromQtyBefore = fromBefore;
    transferExec.fromQtyAfter = Number(src.quantity) || 0;
    transferExec.toQtyBefore = toBefore;
    transferExec.toQtyAfter = toBefore + Number(finalQty);

    await transferExec.save();
    recommendation.approved = true;
    recommendation.approvedAt = new Date();
    await recommendation.save();

    // Auto-calculate impact (best-effort)
    try {
      const execForImpact = await TransferExec.findById(transferExec._id).populate('productId', 'name price productId');
      await computeAndUpsertImpact(execForImpact);
    } catch (e) {
      console.warn('[approve->impact] auto impact failed (no-tx):', e?.message || e);
    }

    return res.json({
      success: true,
      message: 'Recommendation approved',
      execId
    });
  } catch (error) {
    console.error('Create from recommendation (no-tx) error:', error);
    const isDev = (process.env.NODE_ENV || 'development') === 'development';
    return res.status(500).json({
      success: false,
      message: 'Failed to approve recommendation',
      error: isDev ? error.message : undefined
    });
  }
}

const createFromRecommendation = async (req, res) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();
    
    const { id } = req.params;
    const { productId, fromLocationId, toLocationId, quantity } = req.body;
    
    // Validate user is authenticated
    if (!req.user) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }
    
    // Validate ObjectId format
    if (!mongoose.Types.ObjectId.isValid(id)) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: 'Invalid recommendation ID format'
      });
    }
    
    // Find recommendation
    const recommendation = await Recommendation.findById(id).session(session);
    
    if (!recommendation) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(404).json({
        success: false,
        message: 'Recommendation not found'
      });
    }
    
    if (recommendation.approved) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: 'Recommendation already approved'
      });
    }
    
    // If any payload field missing, fallback to recommendation document
    const finalProductId = (productId ?? (recommendation ? recommendation.productId : undefined));
    const finalFromLocId = (fromLocationId ?? (recommendation ? recommendation.fromLocationId : undefined));
    const finalToLocId   = (toLocationId ?? (recommendation ? recommendation.toLocationId : undefined));
    const finalQty       = (quantity ?? (recommendation ? recommendation.quantity : undefined));

    // Validate required fields
    if (!finalProductId || !finalFromLocId || !finalToLocId || finalQty == null) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: productId, fromLocationId, toLocationId, quantity'
      });
    }
    if (!Number.isFinite(Number(finalQty)) || Number(finalQty) < 1) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: 'Invalid quantity. Must be an integer >= 1'
      });
    }

    // Validate ObjectIds now
    if (!mongoose.Types.ObjectId.isValid(finalProductId) ||
        !mongoose.Types.ObjectId.isValid(finalFromLocId) ||
        !mongoose.Types.ObjectId.isValid(finalToLocId)) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: 'Invalid ObjectId format in payload'
      });
    }

    // Use parsed values below...
    const userId = req.user.id || req.user._id;

    // Validate stock availability at source
    const sourceStock = await Stock.findOne({
      productId: finalProductId,
      locationId: finalFromLocId
    }).session(session);

    if (!sourceStock || sourceStock.quantity < finalQty) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source location. Available: ${sourceStock?.quantity || 0}, Required: ${finalQty}`
      });
    }

    // Calculate distance ...
    let distanceKm = recommendation.distance_km || 0;
    if (!distanceKm) {
      const fromLoc = await Location.findById(finalFromLocId).lean();
      const toLoc = await Location.findById(finalToLocId).lean();
      if (fromLoc && toLoc && fromLoc.latitude && toLoc.latitude) {
        distanceKm = haversineKm(
          fromLoc.latitude, fromLoc.longitude,
          toLoc.latitude, toLoc.longitude
        );
      }
    }

    // Generate execId ...
    let execId;
    try {
      execId = await TransferExec.generateExecId();
    } catch (execIdError) {
      await session.abortTransaction();
      await session.endSession();
      console.error('Error generating execId:', execIdError);
      return res.status(500).json({
        success: false,
        message: 'Failed to generate execution ID'
      });
    }

    // Create transferExec
    const transferExec = new TransferExec({
      execId,
      recommendationId: recommendation._id,
      candidateId: recommendation.candidate_id,
      productId: finalProductId,
      fromLocationId: finalFromLocId,
      toLocationId: finalToLocId,
      quantity: Number(finalQty),
      status: 'completed',
      approvedAt: new Date(),
      approvedBy: userId || null,
      estimatedCost: distanceKm * COST_PER_KM,
      distanceKm,
      completedAt: new Date()
    });
    
    await transferExec.save({ session });

    // Immediately execute stock move inside the same transaction
    const src = await Stock.findOne({ productId: finalProductId, locationId: finalFromLocId }).session(session);
    if (!src || src.quantity < finalQty) {
      await session.abortTransaction();
      await session.endSession();
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source location. Available: ${src?.quantity || 0}, Required: ${finalQty}`
      });
    }
    const dst = await Stock.findOne({ productId: finalProductId, locationId: finalToLocId }).session(session);

    const fromBefore = Number(src.quantity) || 0;
    const toBefore = Number(dst?.quantity || 0) || 0;

    src.quantity -= Number(finalQty);
    await src.save({ session });
    if (dst) {
      dst.quantity += Number(finalQty);
      await dst.save({ session });
    } else {
      await new Stock({
        productId: finalProductId,
        locationId: finalToLocId,
        quantity: Number(finalQty)
      }).save({ session });
    }

    // Store before/after snapshots for UI
    transferExec.fromQtyBefore = fromBefore;
    transferExec.fromQtyAfter = Number(src.quantity) || 0;
    transferExec.toQtyBefore = toBefore;
    transferExec.toQtyAfter = toBefore + Number(finalQty);
    await transferExec.save({ session });
    
    // Mark recommendation as approved
    recommendation.approved = true;
    recommendation.approvedAt = new Date();
    await recommendation.save({ session });
    
    await session.commitTransaction();

    // Auto-calculate impact (best-effort, outside transaction)
    try {
      const execForImpact = await TransferExec.findById(transferExec._id).populate('productId', 'name price productId');
      await computeAndUpsertImpact(execForImpact);
    } catch (e) {
      console.warn('[approve->impact] auto impact failed:', e?.message || e);
    }

    res.json({
      success: true,
      message: 'Recommendation approved',
      execId: execId
    });
  } catch (error) {
    // If MongoDB isn't running as a replica set, transactions aren't supported.
    // Fall back to non-transactional writes so local dev works, while preserving
    // transaction safety when replica sets are enabled.
    // NOTE: abortTransaction itself can throw the same "transactions not supported" error,
    // so we must decide on fallback BEFORE attempting to abort.
    if (isMongoTxNotSupported(error)) {
      console.warn('[createFromRecommendation] Transactions not supported by MongoDB deployment. Falling back to no-tx flow.');
      return await createFromRecommendationNoTx(req, res);
    }

    if (session.inTransaction()) {
      try {
        await session.abortTransaction();
      } catch (abortErr) {
        // If abort fails due to unsupported transactions, fall back as well.
        if (isMongoTxNotSupported(abortErr)) {
          console.warn('[createFromRecommendation] abortTransaction failed due to unsupported transactions. Falling back to no-tx flow.');
          return await createFromRecommendationNoTx(req, res);
        }
      }
    }

    console.error('Create from recommendation error:', error);
    console.error('Error stack:', error.stack);
    const isDev = (process.env.NODE_ENV || 'development') === 'development';
    res.status(500).json({
      success: false,
      message: 'Failed to approve recommendation',
      error: isDev ? error.message : undefined
    });
  } finally {
    await session.endSession();
  }
};

/**
 * Approve a recommendation and create transfer execution
 * POST /api/recommendations/:id/approve
 * @deprecated - Use createFromRecommendation instead
 */
const approveRecommendation = async (req, res) => {
  // Backward compatibility: delegate to the new handler.
  return createFromRecommendation(req, res);
};

/**
 * Complete a transfer execution - updates stock levels
 * POST /api/transfer-exec/:id/complete
 */
async function completeTransferNoTx(req, res) {
  try {
    const { id } = req.params;

    const exec = await TransferExec.findById(id);
    if (!exec) {
      return res.status(404).json({ success: false, message: 'Transfer execution not found' });
    }

    if (exec.status === 'completed') {
      return res.status(400).json({ success: false, message: 'Transfer already completed' });
    }

    if (exec.status === 'cancelled') {
      return res.status(400).json({ success: false, message: 'Cannot complete a cancelled transfer' });
    }

    const sourceStock = await Stock.findOne({
      productId: exec.productId,
      locationId: exec.fromLocationId
    });

    if (!sourceStock || sourceStock.quantity < exec.quantity) {
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source. Available: ${sourceStock?.quantity || 0}, Required: ${exec.quantity}`
      });
    }

    const fromBefore = Number(sourceStock.quantity) || 0;
    sourceStock.quantity -= exec.quantity;
    sourceStock.updatedAt = new Date();
    await sourceStock.save();

    let targetStock = await Stock.findOne({
      productId: exec.productId,
      locationId: exec.toLocationId
    });

    const toBefore = Number(targetStock?.quantity || 0) || 0;
    if (targetStock) {
      targetStock.quantity += exec.quantity;
      targetStock.updatedAt = new Date();
      await targetStock.save();
    } else {
      targetStock = new Stock({
        productId: exec.productId,
        locationId: exec.toLocationId,
        quantity: exec.quantity
      });
      await targetStock.save();
    }

    exec.fromQtyBefore = fromBefore;
    exec.fromQtyAfter = Number(sourceStock.quantity) || 0;
    exec.toQtyBefore = toBefore;
    exec.toQtyAfter = toBefore + Number(exec.quantity || 0);

    exec.status = 'completed';
    exec.completedAt = new Date();
    await exec.save();

    // Auto-calculate impact (best-effort)
    let impact = null;
    try {
      const execForImpact = await TransferExec.findById(exec._id).populate('productId', 'name price productId');
      impact = await computeAndUpsertImpact(execForImpact);
    } catch (e) {
      console.warn('[completeTransferNoTx] auto impact failed:', e?.message || e);
    }

    return res.json({
      success: true,
      message: 'Transfer completed successfully. Stock updated.',
      data: exec,
      impact,
      stockUpdate: {
        source: { locationId: exec.fromLocationId, newQuantity: sourceStock.quantity },
        target: { locationId: exec.toLocationId, newQuantity: targetStock.quantity }
      }
    });
  } catch (error) {
    console.error('Complete transfer (no-tx) error:', error);
    const isDev = (process.env.NODE_ENV || 'development') === 'development';
    return res.status(500).json({
      success: false,
      message: 'Failed to complete transfer',
      error: isDev ? error.message : undefined
    });
  }
}

const completeTransfer = async (req, res) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();
    const { id } = req.params;
    
    // Find transfer execution
    const exec = await TransferExec.findById(id).session(session);
    
    if (!exec) {
      await session.abortTransaction();
      return res.status(404).json({
        success: false,
        message: 'Transfer execution not found'
      });
    }
    
    if (exec.status === 'completed') {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: 'Transfer already completed'
      });
    }
    
    if (exec.status === 'cancelled') {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: 'Cannot complete a cancelled transfer'
      });
    }
    
    // Validate source stock
    const sourceStock = await Stock.findOne({
      productId: exec.productId,
      locationId: exec.fromLocationId
    }).session(session);
    
    if (!sourceStock || sourceStock.quantity < exec.quantity) {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: `Insufficient stock at source. Available: ${sourceStock?.quantity || 0}, Required: ${exec.quantity}`
      });
    }
    
    // Decrement source stock
    const fromBefore = Number(sourceStock.quantity) || 0;
    sourceStock.quantity -= exec.quantity;
    sourceStock.updatedAt = new Date();
    await sourceStock.save({ session });
    
    // Increment or create target stock
    let targetStock = await Stock.findOne({
      productId: exec.productId,
      locationId: exec.toLocationId
    }).session(session);

    const toBefore = Number(targetStock?.quantity || 0) || 0;
    
    if (targetStock) {
      targetStock.quantity += exec.quantity;
      targetStock.updatedAt = new Date();
      await targetStock.save({ session });
    } else {
      targetStock = new Stock({
        productId: exec.productId,
        locationId: exec.toLocationId,
        quantity: exec.quantity
      });
      await targetStock.save({ session });
    }

    exec.fromQtyBefore = fromBefore;
    exec.fromQtyAfter = Number(sourceStock.quantity) || 0;
    exec.toQtyBefore = toBefore;
    exec.toQtyAfter = toBefore + Number(exec.quantity || 0);
    
    // Update execution status
    exec.status = 'completed';
    exec.completedAt = new Date();
    await exec.save({ session });
    
    await session.commitTransaction();
    
    // Populate for response
    await exec.populate('productId', 'name category price productId');
    await exec.populate('fromLocationId', 'name city locationId');
    await exec.populate('toLocationId', 'name city locationId');

    // Auto-calculate impact (best-effort)
    let impact = null;
    try {
      const execForImpact = await TransferExec.findById(exec._id).populate('productId', 'name price productId');
      impact = await computeAndUpsertImpact(execForImpact);
    } catch (e) {
      console.warn('[completeTransfer] auto impact failed:', e?.message || e);
    }
    
    res.json({
      success: true,
      message: 'Transfer completed successfully. Stock updated.',
      data: exec,
      impact,
      stockUpdate: {
        source: {
          locationId: exec.fromLocationId._id,
          newQuantity: sourceStock.quantity
        },
        target: {
          locationId: exec.toLocationId._id,
          newQuantity: targetStock.quantity
        }
      }
    });
  } catch (error) {
    if (isMongoTxNotSupported(error)) {
      console.warn('[completeTransfer] Transactions not supported by MongoDB deployment. Falling back to no-tx flow.');
      return await completeTransferNoTx(req, res);
    }

    try {
      if (session.inTransaction()) {
        await session.abortTransaction();
      }
    } catch (abortErr) {
      if (isMongoTxNotSupported(abortErr)) {
        console.warn('[completeTransfer] abortTransaction failed due to unsupported transactions. Falling back to no-tx flow.');
        return await completeTransferNoTx(req, res);
      }
    }

    console.error('Complete transfer error:', error);
    const isDev = (process.env.NODE_ENV || 'development') === 'development';
    res.status(500).json({
      success: false,
      message: 'Failed to complete transfer',
      error: isDev ? error.message : undefined
    });
  } finally {
    await session.endSession();
  }
};

/**
 * Calculate and store transfer impact
 * POST /api/transfer-exec/:id/impact
 */
const calculateImpact = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Find transfer execution
    const exec = await TransferExec.findById(id)
      .populate('productId', 'name price productId');
    
    if (!exec) {
      return res.status(404).json({
        success: false,
        message: 'Transfer execution not found'
      });
    }
    
    if (exec.status !== 'completed') {
      return res.status(400).json({
        success: false,
        message: 'Impact can only be calculated for completed transfers'
      });
    }
    
    const impact = await computeAndUpsertImpact(exec);
    
    // Populate for response
    await impact.populate('productId', 'name category price productId');
    await impact.populate('fromLocationId', 'name city locationId');
    await impact.populate('toLocationId', 'name city locationId');
    
    res.status(200).json({
      success: true,
      message: 'Transfer impact calculated/updated successfully',
      data: impact
    });
  } catch (error) {
    console.error('Calculate impact error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to calculate transfer impact'
    });
  }
};

/**
 * Compute impact numbers for an exec and upsert into transfer_impact.
 * We upsert (instead of "insert once") so the impact can improve over time as new orders come in.
 * Also sets `createdAt` to "now" on every run so Transfers Summary "profit today" can reflect updates.
 */
async function computeAndUpsertImpact(exec) {
  const completedAt = exec.completedAt || exec.updatedAt || new Date();
  const productPrice = exec.productId?.price || 0;

  const windowStart = new Date(completedAt);
  const windowEnd = new Date(completedAt);
  windowEnd.setDate(windowEnd.getDate() + IMPACT_WINDOW_DAYS);

  const preWindowEnd = new Date(completedAt);
  const preWindowStart = new Date(completedAt);
  preWindowStart.setDate(preWindowStart.getDate() - IMPACT_WINDOW_DAYS);

  const salesAfterResult = await Order.aggregate([
    {
      $match: {
        productId: exec.productId._id,
        locationId: exec.toLocationId,
        status: 'purchased',
        timestamp: { $gte: windowStart, $lte: windowEnd }
      }
    },
    { $group: { _id: null, totalUnits: { $sum: '$quantity' } } }
  ]);
  const salesAfter = salesAfterResult[0]?.totalUnits || 0;

  const salesBeforeResult = await Order.aggregate([
    {
      $match: {
        productId: exec.productId._id,
        locationId: exec.toLocationId,
        status: 'purchased',
        timestamp: { $gte: preWindowStart, $lt: preWindowEnd }
      }
    },
    { $group: { _id: null, totalUnits: { $sum: '$quantity' } } }
  ]);
  const salesBefore = salesBeforeResult[0]?.totalUnits || 0;

  // Keep uplift metrics for reference, but "profit (approx)" is based on quantity moved × unit price.
  const upliftUnits = Math.max(0, salesAfter - salesBefore);
  const costUsed = (exec.distanceKm || 0) * COST_PER_KM;
  const upliftRevenue = upliftUnits * productPrice;

  // Per requirement: netProfit is an approximate profit = quantity transferred × product unit price
  const netProfit = (Number(exec.quantity) || 0) * productPrice;

  const now = new Date();

  const impact = await TransferImpact.findOneAndUpdate(
    { transferExecId: exec._id },
    {
      $setOnInsert: {
        transferExecId: exec._id
      },
      $set: {
        execId: exec.execId,
        productId: exec.productId._id,
        fromLocationId: exec.fromLocationId,
        toLocationId: exec.toLocationId,
        quantityMoved: exec.quantity,
        distanceKm: exec.distanceKm || 0,
        costPerKm: COST_PER_KM,
        costUsed,
        salesBefore,
        salesAfter,
        upliftUnits,
        productPrice,
        upliftRevenue,
        netProfit,
        windowStart,
        windowEnd,
        preWindowStart,
        preWindowEnd,
        analysisNotes: `Analysis window: ${IMPACT_WINDOW_DAYS} days before/after completion`,
        createdAt: now
      }
    },
    { upsert: true, new: true }
  );

  return impact;
}

/**
 * Get all transfer impacts
 */
const getTransferImpacts = async (req, res) => {
  try {
    const { limit = 100 } = req.query;
    
    const impacts = await TransferImpact.find()
      .populate('productId', 'name category price productId')
      .populate('fromLocationId', 'name city locationId')
      .populate('toLocationId', 'name city locationId')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));
    
    // Calculate summary statistics
    const totalCost = impacts.reduce((sum, i) => sum + i.costUsed, 0);
    const totalRevenue = impacts.reduce((sum, i) => sum + i.upliftRevenue, 0);
    const totalProfit = impacts.reduce((sum, i) => sum + i.netProfit, 0);
    const avgProfit = impacts.length > 0 ? totalProfit / impacts.length : 0;
    
    res.json({
      success: true,
      data: impacts,
      count: impacts.length,
      summary: {
        totalCost: Math.round(totalCost * 100) / 100,
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        totalProfit: Math.round(totalProfit * 100) / 100,
        avgProfit: Math.round(avgProfit * 100) / 100
      }
    });
  } catch (error) {
    console.error('Get transfer impacts error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch transfer impacts'
    });
  }
};

/**
 * Get single transfer impact
 */
const getTransferImpact = async (req, res) => {
  try {
    const { id } = req.params;
    
    const impact = await TransferImpact.findById(id)
      .populate('productId', 'name category price productId')
      .populate('fromLocationId', 'name city locationId')
      .populate('toLocationId', 'name city locationId');
    
    if (!impact) {
      return res.status(404).json({
        success: false,
        message: 'Transfer impact not found'
      });
    }
    
    res.json({
      success: true,
      data: impact
    });
  } catch (error) {
    console.error('Get transfer impact error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch transfer impact'
    });
  }
};

// Haversine formula helper
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371.0;
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const dphi = toRad(lat2 - lat1);
  const dlambda = toRad(lon2 - lon1);
  const a = Math.sin(dphi / 2) ** 2 + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dlambda / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function toRad(deg) {
  return deg * Math.PI / 180;
}

module.exports = {
  getTransferExecs,
  getTransferExec,
  approveRecommendation,
  createFromRecommendation,
  completeTransfer,
  calculateImpact,
  getTransferImpacts,
  getTransferImpact
};

