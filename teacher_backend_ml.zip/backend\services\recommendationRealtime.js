const mongoose = require('mongoose');
const Recommendation = require('../models/Recommendation');
const Product = require('../models/Product');
const Location = require('../models/Location');
const Stock = require('../models/Stock');

const COST_PER_KM = 0.1;
const DEFAULT_MODEL_TAG = process.env.FORECAST_MODEL_TAG || 'lstm_v1_unscaled';
const REALTIME_MODEL_TAG = 'realtime_v1';
const MIN_MOVE_UNITS = 1;
const MIN_TARGET_STOCK = 5; // keep at least 5 units where demand exists

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371.0;
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const dphi = toRad(lat2 - lat1);
  const dlambda = toRad(lon2 - lon1);
  const a = Math.sin(dphi / 2) ** 2 + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dlambda / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function safeSum(arr) {
  if (!Array.isArray(arr)) return 0;
  return arr.reduce((s, v) => s + (Number(v) || 0), 0);
}

function computePriority({ qty, profit }) {
  if (!Number.isFinite(profit) || profit <= 0) return 'very_low';
  if (qty >= 50) return 'high';
  if (qty >= 20) return 'medium';
  return 'low';
}

/**
 * Refresh "realtime" recommendations for ONE product based on current stock and forecast.
 * This is lightweight enough to run on each buyer purchase for that product.
 */
async function refreshRecommendationsForProduct(productObjectId) {
  const product = await Product.findById(productObjectId, { _id: 1, productId: 1, price: 1 }).lean();
  if (!product) return { skipped: true, reason: 'product_not_found' };
  if (!product.productId) return { skipped: true, reason: 'product_missing_productId_string' };

  const db = mongoose.connection.db;
  if (!db) return { skipped: true, reason: 'db_not_ready' };

  const forecastCol = db.collection('forecast');
  const ordersCol = db.collection('orders');

  // Prefer the configured modelTag, but fall back to any forecast if none found.
  let forecastDocs = await forecastCol
    .find({ productId: product.productId, modelTag: DEFAULT_MODEL_TAG }, { projection: { locationId: 1, yhat: 1, startDate: 1, modelTag: 1 } })
    .toArray();

  if (!forecastDocs.length) {
    forecastDocs = await forecastCol
      .find({ productId: product.productId }, { projection: { locationId: 1, yhat: 1, startDate: 1, modelTag: 1 } })
      .toArray();
  }

  // If we have no forecast at all for this product, fall back to recent sales demand (last 14 days).
  let useSalesFallback = false;
  if (!forecastDocs.length) {
    useSalesFallback = true;
  }

  // Pick the latest forecast per locationId (string) by startDate.
  const byLoc = new Map();
  if (!useSalesFallback) {
    for (const f of forecastDocs) {
      const locCode = String(f.locationId || '').trim();
      if (!locCode) continue;
      const cur = byLoc.get(locCode);
      const curStart = cur?.startDate ? Date.parse(cur.startDate) : -Infinity;
      const nextStart = f?.startDate ? Date.parse(f.startDate) : -Infinity;
      if (!cur || nextStart >= curStart) byLoc.set(locCode, f);
    }
  }

  // When using sales fallback, we can consider all known locations (filtered later by stocks).
  const locationCodes = useSalesFallback ? null : Array.from(byLoc.keys());
  if (!useSalesFallback && (!locationCodes || !locationCodes.length)) {
    return { skipped: true, reason: 'no_location_codes_in_forecast' };
  }

  // Avoid $in operators (some environments sanitize/strip $-operators in queries).
  // Locations table is tiny (100), so fetch all and filter in-memory.
  const allLocations = await Location.find(
    {},
    { _id: 1, locationId: 1, name: 1, city: 1, latitude: 1, longitude: 1 }
  ).lean();
  const locations = useSalesFallback
    ? allLocations.filter((l) => l.locationId)
    : allLocations.filter((l) => l.locationId && new Set(locationCodes).has(String(l.locationId)));
  const locByCode = new Map(locations.map((l) => [String(l.locationId), l]));
  if (!locations.length) return { skipped: true, reason: 'no_locations_mapped' };

  // Stock per product across all locations (max 100 docs) and map by locationId ObjectId.
  const stocks = await Stock.find({ productId: product._id }, { locationId: 1, quantity: 1 }).lean();

  const stockByLocId = new Map(stocks.map((s) => [String(s.locationId), Number(s.quantity) || 0]));
  const stockLocIdSet = new Set(stocks.map((s) => String(s.locationId)));

  // Build sales avg/day per location (only if forecast missing)
  const salesAvgByLocId = new Map();
  if (useSalesFallback) {
    const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
    const salesAgg = await ordersCol
      .aggregate([
        { $match: { status: 'purchased', productId: product._id, timestamp: { $gte: since } } },
        { $group: { _id: '$locationId', total: { $sum: '$quantity' } } }
      ])
      .toArray();
    for (const row of salesAgg) {
      const avg = (Number(row.total) || 0) / 14;
      salesAvgByLocId.set(String(row._id), avg);
    }
  }

  // Build surplus/deficit lists based on stock vs forecast sum.
  const sources = [];
  const sinks = [];

  const iterableLocs = useSalesFallback ? locations : locationCodes.map((c) => locByCode.get(c)).filter(Boolean);

  for (const loc of iterableLocs) {
    // Only consider locations that actually have a stock row for this product.
    if (!stockLocIdSet.has(String(loc._id))) continue;

    const locCode = String(loc.locationId);
    const forecast = useSalesFallback ? null : byLoc.get(locCode);

    if (!loc) continue;
    // Demand proxy:
    // - Prefer forecast avg/day * 7-day cover
    // - Fallback to sales avg/day * 7-day cover (last 14 days)
    const forecastAvg =
      !useSalesFallback && Array.isArray(forecast?.yhat) && forecast.yhat.length
        ? safeSum(forecast.yhat) / forecast.yhat.length
        : 0;
    const salesAvg = useSalesFallback ? (salesAvgByLocId.get(String(loc._id)) || 0) : 0;
    const demandAvg = useSalesFallback ? salesAvg : forecastAvg;
    const requiredCover = demandAvg > 0 ? Math.max(MIN_TARGET_STOCK, Math.ceil(demandAvg * 7)) : 0;
    const stockQty = stockByLocId.get(String(loc._id)) ?? 0;
    const surplus = stockQty - requiredCover;

    const item = {
      loc,
      forecastSum: requiredCover,
      stockQty,
      surplus
    };

    if (surplus >= MIN_MOVE_UNITS) sources.push(item);
    else if (surplus <= -MIN_MOVE_UNITS) sinks.push(item);
  }

  sources.sort((a, b) => b.surplus - a.surplus);
  sinks.sort((a, b) => Math.abs(b.surplus) - Math.abs(a.surplus));

  const planned = [];
  for (const sink of sinks) {
    let deficit = Math.abs(sink.surplus);
    for (const src of sources) {
      if (deficit < MIN_MOVE_UNITS) break;
      if (src.surplus < MIN_MOVE_UNITS) continue;
      if (String(src.loc._id) === String(sink.loc._id)) continue;

      const move = Math.floor(Math.min(src.surplus, deficit));
      if (move < MIN_MOVE_UNITS) continue;

      planned.push({ from: src.loc, to: sink.loc, qty: move });
      src.surplus -= move;
      deficit -= move;
    }
  }

  // Upsert realtime recs and delete stale ones for this product.
  const existingRealtime = await Recommendation.find(
    { productId: product._id, modelTag: REALTIME_MODEL_TAG, approved: false },
    { _id: 1, fromLocationId: 1, toLocationId: 1 }
  ).lean();

  const keepKeys = new Set(planned.map((p) => `${p.from._id}=>${p.to._id}`));
  const staleIds = existingRealtime
    .filter((r) => !keepKeys.has(`${r.fromLocationId}=>${r.toLocationId}`))
    .map((r) => r._id);

  // Avoid $in: delete stale docs one-by-one (stale set is small).
  for (const id of staleIds) {
    await Recommendation.deleteOne({ _id: id });
  }

  for (const p of planned) {
    const lat1 = Number(p.from.latitude) || 0;
    const lon1 = Number(p.from.longitude) || 0;
    const lat2 = Number(p.to.latitude) || 0;
    const lon2 = Number(p.to.longitude) || 0;
    const distanceKm = lat1 && lon1 && lat2 && lon2 ? haversineKm(lat1, lon1, lat2, lon2) : 0;

    const revenue_est = (Number(product.price) || 0) * p.qty;
    const transport_cost = distanceKm * COST_PER_KM * p.qty;
    const profit_est = revenue_est - transport_cost;
    const priority = computePriority({ qty: p.qty, profit: profit_est });

    await Recommendation.findOneAndUpdate(
      {
        productId: product._id,
        fromLocationId: p.from._id,
        toLocationId: p.to._id,
        approved: false,
        modelTag: REALTIME_MODEL_TAG
      },
      {
        $setOnInsert: { createdAt: new Date() },
        $set: {
          quantity: p.qty,
          priority,
          distance_km: distanceKm,
          revenue_est,
          transport_cost,
          profit_est,
          score: profit_est,
          rules_applied: ['realtime_refresh'],
          modelTag: REALTIME_MODEL_TAG
        }
      },
      { upsert: true, new: true }
    );
  }

  return { success: true, createdOrUpdated: planned.length, removed: staleIds.length };
}

module.exports = {
  refreshRecommendationsForProduct,
  REALTIME_MODEL_TAG
};


