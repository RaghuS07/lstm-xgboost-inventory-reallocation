const express = require('express');
const {
  getTransferImpacts,
  getTransferImpact
} = require('../controllers/transferExecController');
const { authenticateToken, validateApiKey } = require('../middleware/auth');

const router = express.Router();

// Apply authentication and API key validation to all routes
router.use(authenticateToken);
router.use(validateApiKey);

/**
 * Transfer Impact Routes
 * 
 * GET  /api/transfer-impact      - List all transfer impacts
 * GET  /api/transfer-impact/:id  - Get single impact
 */

// List all transfer impacts
router.get('/', getTransferImpacts);

// Get single transfer impact
router.get('/:id', getTransferImpact);

module.exports = router;

