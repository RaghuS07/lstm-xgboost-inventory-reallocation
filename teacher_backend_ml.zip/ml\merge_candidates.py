#!/usr/bin/env python3
"""
ml/merge_candidates.py

Merge and deduplicate transfer candidates.

Deduplicates by (productId, fromLocationId, toLocationId) and merges:
  - Sums quantities (or takes max based on strategy)
  - Combines rules into rules_applied array
  - Merges metadata

Usage:
    python ml/merge_candidates.py [--run-id <uuid>] [--merge-strategy sum|max]

Outputs:
    - Writes merged candidates to `transfer_candidates_merged` collection
    - Marks original candidates as merged=true
"""
import os
import argparse
from datetime import datetime, timedelta, timezone
from collections import defaultdict

from pymongo import MongoClient
from bson import ObjectId

# ---------- CONFIG ----------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")
MERGE_WINDOW_HOURS = int(os.getenv("MERGE_WINDOW_HOURS", "24"))


def stringify_key(pid, from_lid, to_lid):
    """Create a unique string key for deduplication."""
    return f"{str(pid)}|{str(from_lid)}|{str(to_lid)}"


def merge_candidates(candidates, strategy="sum"):
    """
    Merge duplicate candidates by (productId, fromLocationId, toLocationId).
    
    Args:
        candidates: List of candidate documents
        strategy: "sum" to sum quantities, "max" to take maximum
    
    Returns:
        List of merged candidate documents
    """
    grouped = defaultdict(list)
    
    for c in candidates:
        key = stringify_key(c["productId"], c["fromLocationId"], c["toLocationId"])
        grouped[key].append(c)
    
    merged = []
    for key, group in grouped.items():
        if len(group) == 1:
            # No merge needed, but still format consistently
            c = group[0]
            merged_doc = {
                "productId": c["productId"],
                "fromLocationId": c["fromLocationId"],
                "toLocationId": c["toLocationId"],
                "quantity": c["quantity"],
                "distance_km": c["distance_km"],
                "forecast_source": c.get("forecast_source"),
                "forecast_target": c.get("forecast_target"),
                "stock_source": c.get("stock_source", 0),
                "stock_target": c.get("stock_target", 0),
                "sales_rate_source": c.get("sales_rate_source", 0),
                "sales_rate_target": c.get("sales_rate_target", 0),
                "rules_applied": [c.get("rule", "unknown")],
                "original_ids": [c["_id"]],
                "modelTag": c.get("modelTag"),
                "runId": c.get("runId"),
                "metadata": c.get("metadata", {}),
                "mergedAt": datetime.now(timezone.utc),
                "merge_count": 1
            }
            merged.append(merged_doc)
        else:
            # Merge multiple candidates
            quantities = [c["quantity"] for c in group]
            if strategy == "sum":
                merged_qty = sum(quantities)
            else:  # max
                merged_qty = max(quantities)
            
            # Take first candidate as base
            base = group[0]
            
            # Collect all rules
            rules = list(set(c.get("rule", "unknown") for c in group))
            
            # Collect all original IDs
            original_ids = [c["_id"] for c in group]
            
            # Merge metadata
            merged_metadata = {}
            for c in group:
                if c.get("metadata"):
                    merged_metadata.update(c["metadata"])
            
            # Take averages for numeric fields where it makes sense
            stock_source = sum(c.get("stock_source", 0) for c in group) / len(group)
            stock_target = sum(c.get("stock_target", 0) for c in group) / len(group)
            sales_rate_source = sum(c.get("sales_rate_source", 0) for c in group) / len(group)
            sales_rate_target = sum(c.get("sales_rate_target", 0) for c in group) / len(group)
            
            # Take first non-null forecast values
            forecast_source = next((c.get("forecast_source") for c in group if c.get("forecast_source") is not None), None)
            forecast_target = next((c.get("forecast_target") for c in group if c.get("forecast_target") is not None), None)
            
            merged_doc = {
                "productId": base["productId"],
                "fromLocationId": base["fromLocationId"],
                "toLocationId": base["toLocationId"],
                "quantity": int(merged_qty),
                "distance_km": base["distance_km"],
                "forecast_source": forecast_source,
                "forecast_target": forecast_target,
                "stock_source": stock_source,
                "stock_target": stock_target,
                "sales_rate_source": sales_rate_source,
                "sales_rate_target": sales_rate_target,
                "rules_applied": rules,
                "original_ids": original_ids,
                "modelTag": base.get("modelTag"),
                "runId": base.get("runId"),
                "metadata": merged_metadata,
                "mergedAt": datetime.now(timezone.utc),
                "merge_count": len(group)
            }
            merged.append(merged_doc)
    
    return merged


def main():
    parser = argparse.ArgumentParser(description="Merge transfer candidates")
    parser.add_argument("--run-id", help="Specific run ID to merge")
    parser.add_argument("--merge-strategy", choices=["sum", "max"], default="sum", 
                        help="Strategy for merging quantities")
    args = parser.parse_args()
    
    print("=== Transfer Candidate Merger ===")
    print(f"Merge strategy: {args.merge_strategy}")
    print()
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    candidates_col = db["transfer_candidates"]
    merged_col = db["transfer_candidates_merged"]
    
    # Build query
    query = {}
    if args.run_id:
        query["runId"] = args.run_id
        print(f"Filtering by runId: {args.run_id}")
    else:
        # Default: merge candidates from last 24 hours
        cutoff = datetime.now(timezone.utc) - timedelta(hours=MERGE_WINDOW_HOURS)
        query["createdAt"] = {"$gte": cutoff}
        print(f"Filtering by time: last {MERGE_WINDOW_HOURS} hours")
    
    # Exclude already merged candidates
    query["merged"] = {"$ne": True}
    
    # Load candidates
    candidates = list(candidates_col.find(query))
    original_count = len(candidates)
    print(f"Found {original_count} candidates to merge")
    
    if original_count == 0:
        print("No candidates to merge.")
        client.close()
        return
    
    # Merge
    merged_docs = merge_candidates(candidates, strategy=args.merge_strategy)
    merged_count = len(merged_docs)
    
    print(f"Merged into {merged_count} unique candidates")
    print(f"Reduction: {original_count} -> {merged_count} ({original_count - merged_count} duplicates removed)")
    
    # Insert merged candidates
    if merged_docs:
        result = merged_col.insert_many(merged_docs)
        inserted_ids = {str(oid): oid for oid in result.inserted_ids}
        
        # Build mapping from original_id to merged_id
        original_to_merged = {}
        for i, doc in enumerate(merged_docs):
            merged_id = result.inserted_ids[i]
            for orig_id in doc["original_ids"]:
                original_to_merged[str(orig_id)] = merged_id
        
        # Mark original candidates as merged
        for c in candidates:
            merged_id = original_to_merged.get(str(c["_id"]))
            if merged_id:
                candidates_col.update_one(
                    {"_id": c["_id"]},
                    {"$set": {"merged": True, "merged_into": merged_id}}
                )
        
        print(f"Inserted {len(merged_docs)} docs into transfer_candidates_merged")
        print(f"Marked {original_count} original candidates as merged")
    
    # Print summary
    print("\n--- Merge Summary ---")
    multi_rule_count = sum(1 for d in merged_docs if len(d.get("rules_applied", [])) > 1)
    print(f"Candidates with multiple rules: {multi_rule_count}")
    
    # Rule breakdown
    rule_counts = defaultdict(int)
    for d in merged_docs:
        for rule in d.get("rules_applied", ["unknown"]):
            rule_counts[rule] += 1
    print("Rules applied:")
    for rule, count in rule_counts.items():
        print(f"  {rule}: {count}")
    
    client.close()
    print("\nDone.")


if __name__ == "__main__":
    main()

