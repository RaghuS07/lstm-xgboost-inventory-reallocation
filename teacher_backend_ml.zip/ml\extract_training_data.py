"""
Extract Training Data for LSTM Demand Forecasting

This script connects to MongoDB and extracts order data, aggregating it into
a daily time-series dataset suitable for LSTM model training.

Output columns:
- date (YYYY-MM-DD)
- productId (business id or Mongo _id as string)
- locationId (Mongo _id as string)
- units_sold (sum of quantity per day)
- category (from products collection)
- tier (from locations collection, if present)

Usage:
    python ml/extract_training_data.py

Output:
    ml/data/training_data.csv
"""

import os
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd
from pymongo import MongoClient

# ---------------------- CONFIG ----------------------

# MongoDB connection settings (same as backend)
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("MONGO_DB_NAME", "supply-demand")

# Output file path
OUTPUT_DIR = Path(__file__).parent / "data"
OUTPUT_FILE = OUTPUT_DIR / "training_data.csv"

# Only include completed orders (purchased)
VALID_ORDER_STATUSES = ["purchased"]


# ---------------------- MAIN LOGIC ----------------------

def connect_to_mongodb():
    """Establish connection to MongoDB and return database handle."""
    print("[*] Connecting to MongoDB...")
    print(f"    URI: {MONGO_URI}")
    print(f"    Database: {DB_NAME}")
    
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    
    # Test connection
    try:
        client.admin.command('ping')
        print("[+] Connected to MongoDB successfully!\n")
    except Exception as e:
        print(f"[!] Failed to connect to MongoDB: {e}")
        sys.exit(1)
    
    return client, db


def load_products(db) -> dict:
    """
    Load products collection and create lookup dictionaries.
    
    Returns:
        dict: Mapping from MongoDB _id (ObjectId) to product info
              {_id: {'productId': str, 'category': str}}
    """
    print("[*] Loading products...")
    products_col = db["products"]
    
    products = list(products_col.find({}, {
        "_id": 1,
        "productId": 1,
        "name": 1,
        "category": 1
    }))
    
    if not products:
        print("[!] No products found in database!")
        sys.exit(1)
    
    # Create lookup: MongoDB _id -> {productId, category}
    product_lookup = {}
    for p in products:
        mongo_id = str(p["_id"])
        product_lookup[mongo_id] = {
            # Use business productId if available, otherwise use MongoDB _id
            "productId": p.get("productId") or mongo_id,
            "category": p.get("category", "Unknown")
        }
    
    print(f"    Loaded {len(product_lookup)} products")
    return product_lookup


def load_locations(db) -> dict:
    """
    Load locations collection and create lookup dictionary.
    
    Returns:
        dict: Mapping from MongoDB _id (ObjectId) to location info
              {_id: {'locationId': str, 'tier': str}}
    """
    print("[*] Loading locations...")
    locations_col = db["locations"]
    
    locations = list(locations_col.find({}, {
        "_id": 1,
        "locationId": 1,
        "name": 1,
        "city": 1,
        "tier": 1
    }))
    
    if not locations:
        print("[!] No locations found in database!")
        sys.exit(1)
    
    # Create lookup: MongoDB _id -> {locationId, tier}
    location_lookup = {}
    for loc in locations:
        mongo_id = str(loc["_id"])
        location_lookup[mongo_id] = {
            # Use business locationId if available, otherwise use MongoDB _id
            "locationId": loc.get("locationId") or mongo_id,
            "tier": loc.get("tier", "")
        }
    
    print(f"    Loaded {len(location_lookup)} locations")
    return location_lookup


def load_orders(db) -> list:
    """
    Load orders from MongoDB.
    
    Returns:
        list: List of order documents
    """
    print("[*] Loading orders...")
    orders_col = db["orders"]
    
    # Build query to filter valid orders
    query = {}
    if VALID_ORDER_STATUSES:
        query["status"] = {"$in": VALID_ORDER_STATUSES}
    
    # Count total orders matching query
    total_count = orders_col.count_documents(query)
    print(f"    Found {total_count:,} orders with status in {VALID_ORDER_STATUSES}")
    
    if total_count == 0:
        print("[!] No orders found with the specified status!")
        print("    Make sure you have run seed_orders.py first.")
        sys.exit(1)
    
    # Load orders with required fields
    orders = list(orders_col.find(query, {
        "_id": 0,
        "productId": 1,
        "locationId": 1,
        "quantity": 1,
        "timestamp": 1,
        "status": 1
    }))
    
    print(f"    Loaded {len(orders):,} orders")
    return orders


def aggregate_daily_sales(orders: list, product_lookup: dict, location_lookup: dict) -> pd.DataFrame:
    """
    Aggregate orders into daily time-series dataset.
    
    Args:
        orders: List of order documents from MongoDB
        product_lookup: Product info lookup dictionary
        location_lookup: Location info lookup dictionary
    
    Returns:
        DataFrame with columns: date, productId, locationId, units_sold, category, tier
    """
    print("\n[*] Aggregating orders into daily time-series...")
    
    # Prepare data for DataFrame
    records = []
    skipped_orders = 0
    
    for order in orders:
        # Get MongoDB ObjectIds as strings
        product_mongo_id = str(order.get("productId", ""))
        location_mongo_id = str(order.get("locationId", ""))
        
        # Skip if product or location not found in lookups
        if product_mongo_id not in product_lookup:
            skipped_orders += 1
            continue
        if location_mongo_id not in location_lookup:
            skipped_orders += 1
            continue
        
        # Get product and location info
        product_info = product_lookup[product_mongo_id]
        location_info = location_lookup[location_mongo_id]
        
        # Extract date from timestamp
        timestamp = order.get("timestamp")
        if timestamp is None:
            skipped_orders += 1
            continue
        
        # Handle both datetime objects and strings
        if isinstance(timestamp, str):
            try:
                timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            except ValueError:
                skipped_orders += 1
                continue
        
        date_str = timestamp.strftime("%Y-%m-%d")
        
        records.append({
            "date": date_str,
            "productId": product_info["productId"],
            "locationId": location_info["locationId"],
            "quantity": order.get("quantity", 0),
            "category": product_info["category"],
            "tier": location_info["tier"]
        })
    
    if skipped_orders > 0:
        print(f"    [!] Skipped {skipped_orders:,} orders due to missing references")
    
    # Create DataFrame
    df = pd.DataFrame(records)
    
    if df.empty:
        print("[!] No valid order data to aggregate!")
        sys.exit(1)
    
    print(f"    Created {len(df):,} raw records")
    
    # Aggregate: sum quantity per (date, productId, locationId)
    # Keep category and tier (they're constant for each productId/locationId)
    aggregated = df.groupby(
        ["date", "productId", "locationId", "category", "tier"],
        as_index=False
    ).agg({
        "quantity": "sum"
    }).rename(columns={"quantity": "units_sold"})
    
    # Sort by date, productId, locationId
    aggregated = aggregated.sort_values(
        ["date", "productId", "locationId"]
    ).reset_index(drop=True)
    
    # Reorder columns
    aggregated = aggregated[[
        "date", "productId", "locationId", "units_sold", "category", "tier"
    ]]
    
    print(f"    Aggregated into {len(aggregated):,} rows (unique date + product + location combinations)")
    
    return aggregated


def print_dataset_summary(df: pd.DataFrame):
    """Print summary statistics of the dataset."""
    print("\n" + "=" * 60)
    print("DATASET SUMMARY")
    print("=" * 60)
    
    print(f"\nShape: {df.shape[0]:,} rows x {df.shape[1]} columns")
    
    print(f"\nDate Range:")
    print(f"    From: {df['date'].min()}")
    print(f"    To:   {df['date'].max()}")
    
    n_days = df['date'].nunique()
    print(f"    Unique days: {n_days}")
    
    print(f"\nProducts: {df['productId'].nunique()}")
    print(f"Locations: {df['locationId'].nunique()}")
    
    print(f"\nCategories:")
    category_counts = df.groupby('category')['units_sold'].sum().sort_values(ascending=False)
    for cat, total in category_counts.head(10).items():
        print(f"    {cat}: {total:,.0f} units")
    
    if df['tier'].notna().any() and (df['tier'] != '').any():
        print(f"\nTiers:")
        tier_counts = df[df['tier'] != ''].groupby('tier')['units_sold'].sum().sort_values(ascending=False)
        for tier, total in tier_counts.items():
            print(f"    {tier}: {total:,.0f} units")
    
    print(f"\nUnits Sold Statistics:")
    print(f"    Total:   {df['units_sold'].sum():,.0f}")
    print(f"    Mean:    {df['units_sold'].mean():.2f}")
    print(f"    Median:  {df['units_sold'].median():.2f}")
    print(f"    Max:     {df['units_sold'].max():,.0f}")
    print(f"    Min:     {df['units_sold'].min():,.0f}")
    
    print("\n" + "=" * 60)


def save_to_csv(df: pd.DataFrame, output_path: Path):
    """Save DataFrame to CSV file."""
    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Save to CSV
    df.to_csv(output_path, index=False)
    
    # Get file size
    file_size = output_path.stat().st_size
    if file_size > 1024 * 1024:
        size_str = f"{file_size / (1024 * 1024):.2f} MB"
    else:
        size_str = f"{file_size / 1024:.2f} KB"
    
    print(f"\n[+] Saved to: {output_path}")
    print(f"    File size: {size_str}")


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("LSTM Training Data Extraction")
    print("=" * 60 + "\n")
    
    # Connect to MongoDB
    client, db = connect_to_mongodb()
    
    try:
        # Load reference data
        product_lookup = load_products(db)
        location_lookup = load_locations(db)
        
        # Load orders
        orders = load_orders(db)
        
        # Aggregate into daily time-series
        df = aggregate_daily_sales(orders, product_lookup, location_lookup)
        
        # Print summary
        print_dataset_summary(df)
        
        # Save to CSV
        save_to_csv(df, OUTPUT_FILE)
        
        print("\n[+] Training data extraction complete!")
        print(f"    Output: {OUTPUT_FILE}")
        print("\n    Next step: Use this data to train the LSTM model.")
        
    finally:
        client.close()
        print("\n[*] MongoDB connection closed.")


if __name__ == "__main__":
    main()

