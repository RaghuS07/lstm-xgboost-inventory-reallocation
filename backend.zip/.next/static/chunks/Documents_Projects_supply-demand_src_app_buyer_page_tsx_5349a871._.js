(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_Projects_supply-demand_src_a41bfa93._.js",
  "static/chunks/ed3ff_7635d08b._.js"
],
    source: "dynamic"
});
