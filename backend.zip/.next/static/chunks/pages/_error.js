__turbopack_load_page_chunks__("/_error", [
  "static/chunks/ed3ff_next_dist_compiled_next-devtools_index_8e80629e.js",
  "static/chunks/ed3ff_next_dist_compiled_a917e4dc._.js",
  "static/chunks/ed3ff_next_dist_shared_lib_ecfcf663._.js",
  "static/chunks/ed3ff_next_dist_client_3dc9ea70._.js",
  "static/chunks/ed3ff_next_dist_175f83fa._.js",
  "static/chunks/ed3ff_next_error_d548f001.js",
  "static/chunks/[next]_entry_page-loader_ts_c3b4bdda._.js",
  "static/chunks/ed3ff_react-dom_57661f7b._.js",
  "static/chunks/ed3ff_4400562f._.js",
  "static/chunks/[root-of-the-server]__5e084032._.js",
  "static/chunks/Documents_Projects_supply-demand_pages__error_2da965e7._.js",
  "static/chunks/turbopack-Documents_Projects_supply-demand_pages__error_5e639902._.js"
])
