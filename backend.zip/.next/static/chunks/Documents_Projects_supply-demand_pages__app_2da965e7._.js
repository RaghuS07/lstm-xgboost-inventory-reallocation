(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ed3ff_next_dist_compiled_next-devtools_index_8e80629e.js",
  "static/chunks/ed3ff_next_dist_compiled_a917e4dc._.js",
  "static/chunks/ed3ff_next_dist_shared_lib_c9459402._.js",
  "static/chunks/ed3ff_next_dist_client_3dc9ea70._.js",
  "static/chunks/ed3ff_next_dist_15cca38c._.js",
  "static/chunks/ed3ff_next_app_761166da.js",
  "static/chunks/[next]_entry_page-loader_ts_7560b7b3._.js",
  "static/chunks/ed3ff_react-dom_57661f7b._.js",
  "static/chunks/ed3ff_4400562f._.js",
  "static/chunks/[root-of-the-server]__a017553f._.js"
],
    source: "entry"
});
