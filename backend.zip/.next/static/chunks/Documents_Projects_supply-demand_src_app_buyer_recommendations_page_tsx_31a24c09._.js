(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_Projects_supply-demand_src_app_buyer_recommendations_page_tsx_1e83a3ac._.js"
],
    source: "dynamic"
});
