(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ed3ff_7635d08b._.js",
  "static/chunks/Documents_Projects_supply-demand_src_b8b2517c._.js"
],
    source: "dynamic"
});
