(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/Projects/supply-demand/src/config/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// API Configuration
__turbopack_context__.s([
    "API_CONFIG",
    ()=>API_CONFIG,
    "API_KEYS",
    ()=>API_KEYS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/Projects/supply-demand/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_CONFIG = {
    BASE_URL: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5001',
    API_KEY: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_KEY || 'buyer_api_key_789',
    TIMEOUT: 10000
};
const API_KEYS = {
    ADMIN: 'admin_api_key_123',
    SELLER: 'seller_api_key_456',
    BUYER: 'buyer_api_key_789',
    SAMPLE: 'sample_api_key_123'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/Projects/supply-demand/src/utils/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Projects/supply-demand/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$config$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Projects/supply-demand/src/config/api.js [app-client] (ecmascript)");
;
;
// API configuration
const API_BASE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$config$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_CONFIG"].BASE_URL;
const API_KEY = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$config$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_CONFIG"].API_KEY;
// Create axios instance with default config
const API = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'x-api-key': API_KEY,
        'Content-Type': 'application/json'
    }
});
// Add request interceptor to include auth token
API.interceptors.request.use((config)=>{
    // Only access localStorage on client side
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem('authToken');
        if (token) {
            config.headers.Authorization = "Bearer ".concat(token);
        }
    }
    return config;
});
// Add response interceptor for error handling
API.interceptors.response.use((response)=>response, (error)=>{
    var _error_response;
    // Only redirect if we're not on the login page and it's a 401 error
    if ("object" !== 'undefined' && ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) === 401 && window.location.pathname !== '/') {
        // Token expired or invalid
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        window.location.href = '/';
    }
    return Promise.reject(error);
});
const api = {
    // Authentication
    login: async (email, password)=>{
        try {
            const response = await API.post('/api/auth/login', {
                email,
                password
            });
            if (response.data.success && "object" !== 'undefined') {
                localStorage.setItem('authToken', response.data.data.token);
                localStorage.setItem('user', JSON.stringify(response.data.data.user));
            }
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Login failed'
            };
        }
    },
    register: async (email, password, role)=>{
        try {
            const response = await API.post('/api/auth/register', {
                email,
                password,
                role
            });
            if (response.data.success && "object" !== 'undefined') {
                localStorage.setItem('authToken', response.data.data.token);
                localStorage.setItem('user', JSON.stringify(response.data.data.user));
            }
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Registration failed'
            };
        }
    },
    // Products
    getProducts: async function() {
        let searchTerm = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
        try {
            const response = await API.get("/api/products".concat(searchTerm ? "?search=".concat(searchTerm) : ''));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch products'
            };
        }
    },
    getProduct: async (productId)=>{
        try {
            const response = await API.get("/api/products/".concat(productId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch product'
            };
        }
    },
    // Seller operations
    getSellerDashboard: async ()=>{
        try {
            const [stockResponse, recommendationsResponse] = await Promise.all([
                API.get('/api/stock/summary'),
                API.get('/api/recommendations')
            ]);
            return {
                success: true,
                data: {
                    ...stockResponse.data.data,
                    recommendations: recommendationsResponse.data.data
                }
            };
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch dashboard data'
            };
        }
    },
    getRecommendations: async ()=>{
        try {
            const response = await API.get('/api/recommendations');
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch recommendations'
            };
        }
    },
    // Product Management
    addProduct: async (productData)=>{
        try {
            const response = await API.post('/api/products', productData);
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to add product'
            };
        }
    },
    updateProduct: async (productId, productData)=>{
        try {
            const response = await API.put("/api/products/".concat(productId), productData);
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to update product'
            };
        }
    },
    deleteProduct: async (productId)=>{
        try {
            const response = await API.delete("/api/products/".concat(productId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to delete product'
            };
        }
    },
    // Stock Management
    getStockByLocation: async (locationId)=>{
        try {
            const response = await API.get("/api/stock/location/".concat(locationId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch stock'
            };
        }
    },
    getAllStock: async ()=>{
        try {
            const response = await API.get('/api/stock/all');
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch all stock'
            };
        }
    },
    getStockSummary: async ()=>{
        try {
            const response = await API.get('/api/stock/summary');
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch stock summary'
            };
        }
    },
    updateStock: async (productId, locationId, quantity)=>{
        try {
            const response = await API.put('/api/stock', {
                productId,
                locationId,
                quantity
            });
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to update stock'
            };
        }
    },
    // Orders
    orderProduct: async (productId, locationId, quantity)=>{
        try {
            const response = await API.post('/api/orders/order', {
                productId,
                locationId,
                quantity
            });
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to order product'
            };
        }
    },
    purchaseProduct: async (orderId)=>{
        try {
            const response = await API.post("/api/orders/purchase/".concat(orderId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to purchase product'
            };
        }
    },
    getUserOrders: async (userId)=>{
        try {
            const response = await API.get("/api/orders/user/".concat(userId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch orders'
            };
        }
    },
    cancelOrder: async (orderId)=>{
        try {
            const response = await API.put("/api/orders/cancel/".concat(orderId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to cancel order'
            };
        }
    },
    // Recommendations
    approveTransfer: async (recommendationId)=>{
        try {
            const response = await API.post("/api/recommendations/".concat(recommendationId, "/approve"));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to approve transfer'
            };
        }
    },
    // Locations
    getLocations: async ()=>{
        try {
            const response = await API.get('/api/locations');
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to fetch locations'
            };
        }
    },
    createLocation: async (locationData)=>{
        try {
            const response = await API.post('/api/locations', locationData);
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to create location'
            };
        }
    },
    updateLocation: async (locationId, locationData)=>{
        try {
            const response = await API.put("/api/locations/".concat(locationId), locationData);
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to update location'
            };
        }
    },
    deleteLocation: async (locationId)=>{
        try {
            const response = await API.delete("/api/locations/".concat(locationId));
            return response.data;
        } catch (error) {
            var _error_response_data, _error_response;
            return {
                success: false,
                message: ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.message) || 'Failed to delete location'
            };
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BuyerRecsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Projects/supply-demand/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Projects/supply-demand/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$utils$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/Projects/supply-demand/src/utils/api.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function BuyerRecsPage() {
    _s();
    const [recs, setRecs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BuyerRecsPage.useEffect": ()=>{
            const load = {
                "BuyerRecsPage.useEffect.load": async ()=>{
                    const r = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$utils$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].getRecommendations();
                    if (r.success) setRecs(r.data);
                }
            }["BuyerRecsPage.useEffect.load"];
            load();
        }
    }["BuyerRecsPage.useEffect"], []);
    const reserve = async (productId, locationId)=>{
        await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$src$2f$utils$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].reserveProduct(productId, locationId, 1);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
        children: recs.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border rounded-xl p-4 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-semibold",
                        children: r.productId.name
                    }, void 0, false, {
                        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                        lineNumber: 27,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-gray-500",
                        children: r.productId.category
                    }, void 0, false, {
                        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-gray-900 font-semibold",
                        children: [
                            "$",
                            r.productId.price.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                        lineNumber: 29,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-sm text-gray-700",
                        children: [
                            "Suggested Location: ",
                            r.toLocationId.name,
                            ", ",
                            r.toLocationId.city
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                        lineNumber: 30,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 flex gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Projects$2f$supply$2d$demand$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>reserve(r.productId._id, r.toLocationId._id),
                            className: "px-3 py-1 rounded-md text-sm bg-blue-600 text-white",
                            children: "Reserve"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this)
                ]
            }, r._id, true, {
                fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/Documents/Projects/supply-demand/src/app/buyer/recommendations/page.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_s(BuyerRecsPage, "OKBh7XB18wzPmVuw4/ujtsqba2E=");
_c = BuyerRecsPage;
var _c;
__turbopack_context__.k.register(_c, "BuyerRecsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Documents_Projects_supply-demand_src_9471a753._.js.map