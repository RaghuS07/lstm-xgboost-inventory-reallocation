(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_Projects_supply-demand_src_app_buyer_page_tsx_46127796._.js"
],
    source: "dynamic"
});
