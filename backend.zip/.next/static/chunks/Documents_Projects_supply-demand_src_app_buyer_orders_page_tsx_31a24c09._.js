(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_Projects_supply-demand_src_app_buyer_orders_page_tsx_5934073a._.js"
],
    source: "dynamic"
});
