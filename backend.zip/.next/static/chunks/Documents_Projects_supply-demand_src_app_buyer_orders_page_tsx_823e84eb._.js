(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ed3ff_743ed778._.js",
  "static/chunks/Documents_Projects_supply-demand_src_cdc1d96a._.js"
],
    source: "dynamic"
});
