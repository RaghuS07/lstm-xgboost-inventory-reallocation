(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_46c374b5._.js",
  "static/chunks/ed3ff_next_dist_compiled_react-dom_b7c23b61._.js",
  "static/chunks/ed3ff_next_dist_compiled_next-devtools_index_fe745015.js",
  "static/chunks/ed3ff_next_dist_compiled_e665721c._.js",
  "static/chunks/ed3ff_next_dist_client_4a0184d5._.js",
  "static/chunks/ed3ff_next_dist_591ba5a8._.js",
  "static/chunks/ed3ff_@swc_helpers_cjs_64024c4a._.js"
],
    source: "entry"
});
