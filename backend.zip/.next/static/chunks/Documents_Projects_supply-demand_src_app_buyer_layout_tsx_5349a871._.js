(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ed3ff_2034ec19._.js",
  "static/chunks/Documents_Projects_supply-demand_src_bfce71ee._.js"
],
    source: "dynamic"
});
