var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/ed3ff_d321dd3e._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/Documents/Projects/supply-demand/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Documents/Projects/supply-demand/node_modules/next/document.js [ssr] (ecmascript)").exports
