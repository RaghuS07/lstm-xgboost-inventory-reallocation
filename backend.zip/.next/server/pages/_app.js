var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__65b38341._.js")
R.m("[project]/Documents/Projects/supply-demand/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Documents/Projects/supply-demand/node_modules/next/app.js [ssr] (ecmascript)").exports
